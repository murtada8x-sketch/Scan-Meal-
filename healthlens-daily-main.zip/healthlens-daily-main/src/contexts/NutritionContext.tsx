import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { Meal, Recipe, UserProfile, DailyLog, FastingSession, TabType, PartialMeal, FavoriteProduct } from '@/types/nutrition';
import { defaultProfile, defaultRecipes, sampleMeals } from '@/data/nutrition-data';
import { toast } from 'sonner';

type Language = 'ar' | 'en' | 'es' | 'de' | 'fr';

interface NutritionContextType {
  // Navigation
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  
  // User Profile
  profile: UserProfile;
  updateProfile: (updates: Partial<UserProfile>) => void;
  
  // Meals
  meals: Meal[];
  addMeal: (meal: Meal) => void;
  removeMeal: (id: string) => void;
  updateMeal: (id: string, updates: Partial<Meal>) => void;
  
  // Partial meals (incomplete products)
  partialMeals: PartialMeal[];
  addPartialMeal: (meal: PartialMeal) => void;
  consumePartialMeal: (id: string, portion: number) => void;
  removePartialMeal: (id: string) => void;
  
  // Favorites
  favoriteProducts: FavoriteProduct[];
  addFavorite: (product: FavoriteProduct) => void;
  removeFavorite: (id: string) => void;
  
  // Recipes
  recipes: Recipe[];
  addRecipe: (recipe: Recipe) => void;
  removeRecipe: (id: string) => void;
  
  // Water
  waterIntake: number;
  addWater: (amount: number) => void;
  
  // Steps
  steps: number;
  addSteps: (count: number) => void;
  
  // Fasting
  fastingSession: FastingSession | null;
  startFasting: (hours: number) => void;
  stopFasting: () => void;
  
  // Daily Totals
  dailyTotals: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    sugar: number;
    salt: number;
  };
  
  // Language
  language: Language;
  setLanguage: (lang: Language) => void;
  
  // Translation helper
  t: (key: string) => string;
  
  // Daily logs history
  dailyLogs: DailyLog[];
  
  // Notifications
  waterRemindersEnabled: boolean;
  setWaterRemindersEnabled: (enabled: boolean) => void;
  stressRemindersEnabled: boolean;
  setStressRemindersEnabled: (enabled: boolean) => void;
  
  // Backup
  exportData: () => string;
  importData: (data: string) => boolean;
  
  // Compliance days
  complianceDays: number;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    home: 'Home',
    reports: 'Reports',
    scan: 'Scan',
    recipes: 'Recipes',
    profile: 'Profile',
    water: 'Water',
    protein: 'Protein',
    carbs: 'Carbs',
    fat: 'Fat',
    calories: 'Calories',
    steps: 'Steps',
    fasting: 'Fasting',
    startFasting: 'Start Fasting',
    stopFasting: 'Stop Fasting',
    fastingComplete: 'Fasting Complete!',
    fastingCompleteMsg: 'Great job! You completed your fast.',
    scanFood: 'Scan Food',
    scanBarcode: 'Scan Barcode',
    addManually: 'Add Manually',
    savedRecipes: 'Saved Recipes',
    addRecipe: 'Add Recipe',
    recentHistory: 'Recent History',
    viewAll: 'View All',
    healthyFoodLevel: 'Healthy Food Level',
    unhealthy: 'Unhealthy',
    veryHealthy: 'Very Healthy',
    dailyWaterNeeds: 'Daily Water Needs',
    proteinNeeds: 'Protein Needs',
    weight: 'Weight',
    height: 'Height',
    age: 'Age',
    activityLevel: 'Activity Level',
    language: 'Language',
    sleepTime: 'Sleep Time',
    sleepStart: 'Sleep Start',
    sleepEnd: 'Sleep End',
    customFastingHours: 'Custom Fasting Hours',
    waterCupSize: 'Water Cup Size',
    bmi: 'BMI',
    tips: 'Important Tips',
    myAccount: 'My Account',
    logout: 'Logout',
    upgrade: 'Upgrade to Premium',
    unlockFeatures: 'Unlock all features',
    thisWeek: 'This Week',
    lastWeek: 'Last Week',
    overview: 'Overview',
    vitamins: 'Vitamins',
    aminoAcids: 'Amino Acids',
    hydration: 'Hydration',
    compliance: 'Compliance',
    waterReminder: 'Time to drink water!',
    waterReminderMsg: 'Stay hydrated for better health.',
    sugarLimit: 'Sugar Limit',
    saltLimit: 'Salt Limit',
    warning: 'Warning',
    highSugar: 'High sugar intake detected!',
    highSalt: 'High salt intake detected!',
    quarter: 'Quarter',
    half: 'Half',
    full: 'Full',
    add: 'Add',
    cancel: 'Cancel',
    confirm: 'Confirm',
    delete: 'Delete',
    edit: 'Edit',
    save: 'Save',
    search: 'Search',
    noResults: 'No results found',
    loading: 'Loading...',
    analyzing: 'Analyzing...',
    confidence: 'Confidence',
    wrongFood: 'Wrong Food?',
    retake: 'Retake',
    scanAgain: 'Scan Again',
    addToLog: 'Add to Daily Log',
    quantity: 'Quantity',
    grams: 'grams',
    servingSize: 'Serving Size',
    nutritionInfo: 'Nutrition Info',
    breathingExercise: 'Breathing Exercise',
    inhale: 'Inhale',
    exhale: 'Exhale',
    hold: 'Hold',
    fastingStages: 'Fasting Stages',
    bloodSugarRise: 'Blood sugar rising',
    fatBurning: 'Fat burning begins',
    ketosis: 'Ketosis',
    autophagy: 'Autophagy begins',
    notifications: 'Notifications',
    backup: 'Backup & Sync',
    exportData: 'Export Data',
    importData: 'Import Data',
    dataExported: 'Data exported successfully',
    dataImported: 'Data imported successfully',
    invalidData: 'Invalid data format',
    nameEditable: 'Nutrition values are correct but name may differ. You can edit it.',
    editName: 'Edit Name',
    products: 'Products',
    harmfulFoods: 'Harmful Foods',
    favoriteProducts: 'Favorite Products',
    addToFavorites: 'Add to Favorites',
    measurementTip: 'Use a measuring spoon for accurate results',
    cancerWarning: 'May increase cancer risk if consumed excessively',
  },
  ar: {
    home: 'الرئيسية',
    reports: 'التقارير',
    scan: 'مسح',
    recipes: 'الوصفات',
    profile: 'الملف',
    water: 'الماء',
    protein: 'بروتين',
    carbs: 'كارب',
    fat: 'دهون',
    calories: 'سعرات',
    steps: 'خطوات',
    fasting: 'الصيام',
    startFasting: 'بدء الصيام',
    stopFasting: 'إيقاف الصيام',
    fastingComplete: 'انتهى الصيام!',
    fastingCompleteMsg: 'أحسنت! لقد أكملت فترة الصيام',
    scanFood: 'مسح الطعام',
    scanBarcode: 'مسح الباركود',
    addManually: 'إضافة يدوية',
    savedRecipes: 'الوصفات المحفوظة',
    addRecipe: 'إضافة وصفة',
    recentHistory: 'السجل الأخير',
    viewAll: 'عرض الكل',
    healthyFoodLevel: 'مستوى الغذاء الصحي',
    unhealthy: 'غير صحي',
    veryHealthy: 'صحي جداً',
    dailyWaterNeeds: 'احتياجات الماء اليومية',
    proteinNeeds: 'احتياجات البروتين',
    weight: 'الوزن',
    height: 'الطول',
    age: 'العمر',
    activityLevel: 'مستوى النشاط',
    language: 'اللغة',
    sleepTime: 'وقت النوم',
    sleepStart: 'بداية النوم',
    sleepEnd: 'نهاية النوم',
    customFastingHours: 'ساعات الصيام المخصصة',
    waterCupSize: 'حجم كوب الماء',
    bmi: 'مؤشر كتلة الجسم',
    tips: 'نصائح مهمة',
    myAccount: 'حسابي',
    logout: 'خروج',
    upgrade: 'ترقية إلى بريميوم',
    unlockFeatures: 'افتح جميع الميزات',
    thisWeek: 'هذا الأسبوع',
    lastWeek: 'الأسبوع الماضي',
    overview: 'نظرة عامة',
    vitamins: 'فيتامينات',
    aminoAcids: 'أحماض أمينية',
    hydration: 'الماء',
    compliance: 'أيام الالتزام',
    waterReminder: 'حان وقت شرب الماء!',
    waterReminderMsg: 'حافظ على ترطيب جسمك لصحة أفضل.',
    sugarLimit: 'حد السكر',
    saltLimit: 'حد الملح',
    warning: 'تحذير',
    highSugar: 'تم الكشف عن استهلاك عالي للسكر!',
    highSalt: 'تم الكشف عن استهلاك عالي للملح!',
    quarter: 'ربع',
    half: 'نصف',
    full: 'كاملة',
    add: 'إضافة',
    cancel: 'إلغاء',
    confirm: 'تأكيد',
    delete: 'حذف',
    edit: 'تعديل',
    save: 'حفظ',
    search: 'بحث',
    noResults: 'لم يتم العثور على نتائج',
    loading: 'جاري التحميل...',
    analyzing: 'جاري التحليل...',
    confidence: 'نسبة التأكد',
    wrongFood: 'طعام خاطئ؟',
    retake: 'إعادة التصوير',
    scanAgain: 'مسح مرة أخرى',
    addToLog: 'إضافة للسجل اليومي',
    quantity: 'الكمية',
    grams: 'جرام',
    servingSize: 'حجم الحصة',
    nutritionInfo: 'المعلومات الغذائية',
    breathingExercise: 'تمارين التنفس',
    inhale: 'شهيق',
    exhale: 'زفير',
    hold: 'احتفظ',
    fastingStages: 'مراحل الصيام',
    bloodSugarRise: 'ارتفاع سكر الدم',
    fatBurning: 'بدء حرق الدهون',
    ketosis: 'الكيتوزس',
    autophagy: 'بدء الالتهام الذاتي',
    notifications: 'الإشعارات',
    backup: 'النسخ الاحتياطي والمزامنة',
    exportData: 'تصدير البيانات',
    importData: 'استيراد البيانات',
    dataExported: 'تم تصدير البيانات بنجاح',
    dataImported: 'تم استيراد البيانات بنجاح',
    invalidData: 'صيغة البيانات غير صالحة',
    nameEditable: 'القيم الغذائية صحيحة ولكن الاسم قد يختلف. يمكنك تعديله.',
    editName: 'تعديل الاسم',
    products: 'المنتجات',
    harmfulFoods: 'الأطعمة الضارة',
    favoriteProducts: 'المنتجات المفضلة',
    addToFavorites: 'إضافة للمفضلة',
    measurementTip: 'استخدم ملعقة قياس للحصول على نتائج دقيقة',
    cancerWarning: 'قد يزيد من خطر الإصابة بالسرطان إذا تم استهلاكه بكثرة',
  },
  es: {
    home: 'Inicio',
    reports: 'Informes',
    scan: 'Escanear',
    recipes: 'Recetas',
    profile: 'Perfil',
    water: 'Agua',
    protein: 'Proteína',
    carbs: 'Carbos',
    fat: 'Grasa',
    calories: 'Calorías',
    steps: 'Pasos',
    fasting: 'Ayuno',
    startFasting: 'Iniciar Ayuno',
    stopFasting: 'Detener Ayuno',
    fastingComplete: '¡Ayuno Completo!',
    fastingCompleteMsg: '¡Buen trabajo! Has completado tu ayuno.',
    scanFood: 'Escanear Comida',
    scanBarcode: 'Escanear Código',
    addManually: 'Añadir Manual',
    savedRecipes: 'Recetas Guardadas',
    addRecipe: 'Añadir Receta',
    recentHistory: 'Historial Reciente',
    viewAll: 'Ver Todo',
    healthyFoodLevel: 'Nivel de Comida Saludable',
    unhealthy: 'No Saludable',
    veryHealthy: 'Muy Saludable',
    dailyWaterNeeds: 'Necesidades de Agua',
    proteinNeeds: 'Necesidades de Proteína',
    weight: 'Peso',
    height: 'Altura',
    age: 'Edad',
    activityLevel: 'Nivel de Actividad',
    language: 'Idioma',
    sleepTime: 'Hora de Dormir',
    sleepStart: 'Inicio del Sueño',
    sleepEnd: 'Fin del Sueño',
    customFastingHours: 'Horas de Ayuno Personalizadas',
    waterCupSize: 'Tamaño del Vaso',
    bmi: 'IMC',
    tips: 'Consejos Importantes',
    myAccount: 'Mi Cuenta',
    logout: 'Cerrar Sesión',
    upgrade: 'Actualizar a Premium',
    unlockFeatures: 'Desbloquear todas las funciones',
    thisWeek: 'Esta Semana',
    lastWeek: 'Semana Pasada',
    overview: 'Resumen',
    vitamins: 'Vitaminas',
    aminoAcids: 'Aminoácidos',
    hydration: 'Hidratación',
    compliance: 'Cumplimiento',
    waterReminder: '¡Hora de beber agua!',
    waterReminderMsg: 'Mantente hidratado para mejor salud.',
    sugarLimit: 'Límite de Azúcar',
    saltLimit: 'Límite de Sal',
    warning: 'Advertencia',
    highSugar: '¡Alto consumo de azúcar detectado!',
    highSalt: '¡Alto consumo de sal detectado!',
    quarter: 'Cuarto',
    half: 'Mitad',
    full: 'Completo',
    add: 'Añadir',
    cancel: 'Cancelar',
    confirm: 'Confirmar',
    delete: 'Eliminar',
    edit: 'Editar',
    save: 'Guardar',
    search: 'Buscar',
    noResults: 'No se encontraron resultados',
    loading: 'Cargando...',
    analyzing: 'Analizando...',
    confidence: 'Confianza',
    wrongFood: '¿Comida incorrecta?',
    retake: 'Volver a tomar',
    scanAgain: 'Escanear de Nuevo',
    addToLog: 'Añadir al Registro',
    quantity: 'Cantidad',
    grams: 'gramos',
    servingSize: 'Tamaño de Porción',
    nutritionInfo: 'Info Nutricional',
    breathingExercise: 'Ejercicio de Respiración',
    inhale: 'Inhalar',
    exhale: 'Exhalar',
    hold: 'Mantener',
    fastingStages: 'Etapas del Ayuno',
    bloodSugarRise: 'Aumento de azúcar',
    fatBurning: 'Quema de grasa',
    ketosis: 'Cetosis',
    autophagy: 'Autofagia',
    notifications: 'Notificaciones',
    backup: 'Respaldo y Sincronización',
    exportData: 'Exportar Datos',
    importData: 'Importar Datos',
    dataExported: 'Datos exportados exitosamente',
    dataImported: 'Datos importados exitosamente',
    invalidData: 'Formato de datos inválido',
    nameEditable: 'Los valores nutricionales son correctos pero el nombre puede diferir. Puedes editarlo.',
    editName: 'Editar Nombre',
    products: 'Productos',
    harmfulFoods: 'Alimentos Dañinos',
    favoriteProducts: 'Productos Favoritos',
    addToFavorites: 'Añadir a Favoritos',
    measurementTip: 'Use una cuchara medidora para resultados precisos',
    cancerWarning: 'Puede aumentar el riesgo de cáncer si se consume en exceso',
  },
  de: {
    home: 'Startseite',
    reports: 'Berichte',
    scan: 'Scannen',
    recipes: 'Rezepte',
    profile: 'Profil',
    water: 'Wasser',
    protein: 'Protein',
    carbs: 'Kohlenhydrate',
    fat: 'Fett',
    calories: 'Kalorien',
    steps: 'Schritte',
    fasting: 'Fasten',
    startFasting: 'Fasten Starten',
    stopFasting: 'Fasten Stoppen',
    fastingComplete: 'Fasten Abgeschlossen!',
    fastingCompleteMsg: 'Gut gemacht! Du hast dein Fasten abgeschlossen.',
    scanFood: 'Essen Scannen',
    scanBarcode: 'Barcode Scannen',
    addManually: 'Manuell Hinzufügen',
    savedRecipes: 'Gespeicherte Rezepte',
    addRecipe: 'Rezept Hinzufügen',
    recentHistory: 'Letzte Einträge',
    viewAll: 'Alle Anzeigen',
    healthyFoodLevel: 'Gesundes Essen Level',
    unhealthy: 'Ungesund',
    veryHealthy: 'Sehr Gesund',
    dailyWaterNeeds: 'Täglicher Wasserbedarf',
    proteinNeeds: 'Proteinbedarf',
    weight: 'Gewicht',
    height: 'Größe',
    age: 'Alter',
    activityLevel: 'Aktivitätslevel',
    language: 'Sprache',
    sleepTime: 'Schlafzeit',
    sleepStart: 'Schlafbeginn',
    sleepEnd: 'Schlafende',
    customFastingHours: 'Benutzerdefinierte Fastenstunden',
    waterCupSize: 'Bechergröße',
    bmi: 'BMI',
    tips: 'Wichtige Tipps',
    myAccount: 'Mein Konto',
    logout: 'Abmelden',
    upgrade: 'Auf Premium Upgraden',
    unlockFeatures: 'Alle Funktionen freischalten',
    thisWeek: 'Diese Woche',
    lastWeek: 'Letzte Woche',
    overview: 'Übersicht',
    vitamins: 'Vitamine',
    aminoAcids: 'Aminosäuren',
    hydration: 'Hydration',
    compliance: 'Einhaltung',
    waterReminder: 'Zeit Wasser zu trinken!',
    waterReminderMsg: 'Bleib hydriert für bessere Gesundheit.',
    sugarLimit: 'Zuckerlimit',
    saltLimit: 'Salzlimit',
    warning: 'Warnung',
    highSugar: 'Hoher Zuckerkonsum erkannt!',
    highSalt: 'Hoher Salzkonsum erkannt!',
    quarter: 'Viertel',
    half: 'Halb',
    full: 'Voll',
    add: 'Hinzufügen',
    cancel: 'Abbrechen',
    confirm: 'Bestätigen',
    delete: 'Löschen',
    edit: 'Bearbeiten',
    save: 'Speichern',
    search: 'Suchen',
    noResults: 'Keine Ergebnisse gefunden',
    loading: 'Laden...',
    analyzing: 'Analysieren...',
    confidence: 'Konfidenz',
    wrongFood: 'Falsches Essen?',
    retake: 'Neu aufnehmen',
    scanAgain: 'Erneut Scannen',
    addToLog: 'Zum Protokoll Hinzufügen',
    quantity: 'Menge',
    grams: 'Gramm',
    servingSize: 'Portionsgröße',
    nutritionInfo: 'Nährwertinfo',
    breathingExercise: 'Atemübung',
    inhale: 'Einatmen',
    exhale: 'Ausatmen',
    hold: 'Halten',
    fastingStages: 'Fastenphasen',
    bloodSugarRise: 'Blutzuckeranstieg',
    fatBurning: 'Fettverbrennung',
    ketosis: 'Ketose',
    autophagy: 'Autophagie',
    notifications: 'Benachrichtigungen',
    backup: 'Backup & Sync',
    exportData: 'Daten Exportieren',
    importData: 'Daten Importieren',
    dataExported: 'Daten erfolgreich exportiert',
    dataImported: 'Daten erfolgreich importiert',
    invalidData: 'Ungültiges Datenformat',
    nameEditable: 'Die Nährwerte sind korrekt, aber der Name kann abweichen. Sie können ihn bearbeiten.',
    editName: 'Name Bearbeiten',
    products: 'Produkte',
    harmfulFoods: 'Schädliche Lebensmittel',
    favoriteProducts: 'Lieblingsprodukte',
    addToFavorites: 'Zu Favoriten',
    measurementTip: 'Verwenden Sie einen Messlöffel für genaue Ergebnisse',
    cancerWarning: 'Kann das Krebsrisiko bei übermäßigem Konsum erhöhen',
  },
  fr: {
    home: 'Accueil',
    reports: 'Rapports',
    scan: 'Scanner',
    recipes: 'Recettes',
    profile: 'Profil',
    water: 'Eau',
    protein: 'Protéine',
    carbs: 'Glucides',
    fat: 'Lipides',
    calories: 'Calories',
    steps: 'Pas',
    fasting: 'Jeûne',
    startFasting: 'Commencer le Jeûne',
    stopFasting: 'Arrêter le Jeûne',
    fastingComplete: 'Jeûne Terminé!',
    fastingCompleteMsg: 'Bravo! Vous avez terminé votre jeûne.',
    scanFood: 'Scanner Nourriture',
    scanBarcode: 'Scanner Code-barres',
    addManually: 'Ajouter Manuellement',
    savedRecipes: 'Recettes Sauvegardées',
    addRecipe: 'Ajouter Recette',
    recentHistory: 'Historique Récent',
    viewAll: 'Voir Tout',
    healthyFoodLevel: 'Niveau de Nourriture Saine',
    unhealthy: 'Non Sain',
    veryHealthy: 'Très Sain',
    dailyWaterNeeds: 'Besoins en Eau',
    proteinNeeds: 'Besoins en Protéines',
    weight: 'Poids',
    height: 'Taille',
    age: 'Âge',
    activityLevel: 'Niveau d\'Activité',
    language: 'Langue',
    sleepTime: 'Heure de Sommeil',
    sleepStart: 'Début du Sommeil',
    sleepEnd: 'Fin du Sommeil',
    customFastingHours: 'Heures de Jeûne Personnalisées',
    waterCupSize: 'Taille du Verre',
    bmi: 'IMC',
    tips: 'Conseils Importants',
    myAccount: 'Mon Compte',
    logout: 'Déconnexion',
    upgrade: 'Passer à Premium',
    unlockFeatures: 'Débloquer toutes les fonctionnalités',
    thisWeek: 'Cette Semaine',
    lastWeek: 'Semaine Dernière',
    overview: 'Aperçu',
    vitamins: 'Vitamines',
    aminoAcids: 'Acides Aminés',
    hydration: 'Hydratation',
    compliance: 'Conformité',
    waterReminder: 'C\'est l\'heure de boire de l\'eau!',
    waterReminderMsg: 'Restez hydraté pour une meilleure santé.',
    sugarLimit: 'Limite de Sucre',
    saltLimit: 'Limite de Sel',
    warning: 'Avertissement',
    highSugar: 'Consommation élevée de sucre détectée!',
    highSalt: 'Consommation élevée de sel détectée!',
    quarter: 'Quart',
    half: 'Moitié',
    full: 'Complet',
    add: 'Ajouter',
    cancel: 'Annuler',
    confirm: 'Confirmer',
    delete: 'Supprimer',
    edit: 'Modifier',
    save: 'Sauvegarder',
    search: 'Rechercher',
    noResults: 'Aucun résultat trouvé',
    loading: 'Chargement...',
    analyzing: 'Analyse...',
    confidence: 'Confiance',
    wrongFood: 'Mauvais aliment?',
    retake: 'Reprendre',
    scanAgain: 'Scanner à Nouveau',
    addToLog: 'Ajouter au Journal',
    quantity: 'Quantité',
    grams: 'grammes',
    servingSize: 'Taille de Portion',
    nutritionInfo: 'Info Nutritionnelle',
    breathingExercise: 'Exercice de Respiration',
    inhale: 'Inspirez',
    exhale: 'Expirez',
    hold: 'Maintenez',
    fastingStages: 'Étapes du Jeûne',
    bloodSugarRise: 'Augmentation glycémie',
    fatBurning: 'Combustion des graisses',
    ketosis: 'Cétose',
    autophagy: 'Autophagie',
    notifications: 'Notifications',
    backup: 'Sauvegarde & Sync',
    exportData: 'Exporter les Données',
    importData: 'Importer les Données',
    dataExported: 'Données exportées avec succès',
    dataImported: 'Données importées avec succès',
    invalidData: 'Format de données invalide',
    nameEditable: 'Les valeurs nutritionnelles sont correctes mais le nom peut différer. Vous pouvez le modifier.',
    editName: 'Modifier le Nom',
    products: 'Produits',
    harmfulFoods: 'Aliments Nocifs',
    favoriteProducts: 'Produits Favoris',
    addToFavorites: 'Ajouter aux Favoris',
    measurementTip: 'Utilisez une cuillère doseuse pour des résultats précis',
    cancerWarning: 'Peut augmenter le risque de cancer en cas de consommation excessive',
  },
};

const NutritionContext = createContext<NutritionContextType | undefined>(undefined);

export const useNutrition = () => {
  const context = useContext(NutritionContext);
  if (!context) {
    throw new Error('useNutrition must be used within a NutritionProvider');
  }
  return context;
};

export const NutritionProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('userProfile');
    return saved ? JSON.parse(saved) : defaultProfile;
  });
  const [meals, setMeals] = useState<Meal[]>(() => {
    const saved = localStorage.getItem('meals');
    if (saved) {
      const parsed = JSON.parse(saved);
      return parsed.map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) }));
    }
    return sampleMeals;
  });
  const [partialMeals, setPartialMeals] = useState<PartialMeal[]>(() => {
    const saved = localStorage.getItem('partialMeals');
    return saved ? JSON.parse(saved) : [];
  });
  const [favoriteProducts, setFavoriteProducts] = useState<FavoriteProduct[]>(() => {
    const saved = localStorage.getItem('favoriteProducts');
    return saved ? JSON.parse(saved) : [];
  });
  const [recipes, setRecipes] = useState<Recipe[]>(() => {
    const saved = localStorage.getItem('recipes');
    return saved ? JSON.parse(saved) : defaultRecipes;
  });
  const [waterIntake, setWaterIntake] = useState<number>(() => {
    const today = new Date().toDateString();
    const saved = localStorage.getItem('waterIntake');
    const savedDate = localStorage.getItem('waterIntakeDate');
    if (saved && savedDate === today) {
      return parseInt(saved);
    }
    return 0;
  });
  const [steps, setSteps] = useState<number>(() => {
    const saved = localStorage.getItem('steps');
    return saved ? parseInt(saved) : 0;
  });
  const [fastingSession, setFastingSession] = useState<FastingSession | null>(() => {
    const saved = localStorage.getItem('fastingSession');
    if (saved) {
      const session = JSON.parse(saved);
      session.startTime = new Date(session.startTime);
      session.endTime = new Date(session.endTime);
      return session;
    }
    return null;
  });
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('language');
    return (saved as Language) || 'en';
  });
  const [dailyLogs, setDailyLogs] = useState<DailyLog[]>(() => {
    const saved = localStorage.getItem('dailyLogs');
    return saved ? JSON.parse(saved) : [];
  });
  const [waterRemindersEnabled, setWaterRemindersEnabledState] = useState<boolean>(() => {
    const saved = localStorage.getItem('waterRemindersEnabled');
    return saved === 'true';
  });
  const [stressRemindersEnabled, setStressRemindersEnabledState] = useState<boolean>(() => {
    const saved = localStorage.getItem('stressRemindersEnabled');
    return saved === 'true';
  });
  const [complianceDays, setComplianceDays] = useState<number>(() => {
    const saved = localStorage.getItem('complianceDays');
    return saved ? parseInt(saved) : 0;
  });

  const t = useCallback((key: string) => {
    return translations[language][key] || translations.en[key] || key;
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  };

  // Set initial direction
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, []);

  // Water reminders
  useEffect(() => {
    if (!waterRemindersEnabled) return;

    const showWaterNotification = () => {
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(t('waterReminder'), {
          body: t('waterReminderMsg'),
          icon: '/icon-512.png',
        });
      }
      toast(t('waterReminder'), { description: t('waterReminderMsg') });
    };

    // Show notification immediately when enabled
    showWaterNotification();

    // Then every 2 hours
    const interval = setInterval(showWaterNotification, 2 * 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, [waterRemindersEnabled, t]);

  // Stress/Breathing reminders
  useEffect(() => {
    if (!stressRemindersEnabled) return;

    const showStressNotification = () => {
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(t('breathingExercise'), {
          body: language === 'ar' ? 'خذ استراحة وتنفس!' : 'Take a break and breathe!',
          icon: '/icon-512.png',
        });
      }
      toast(t('breathingExercise'), { 
        description: language === 'ar' ? 'خذ استراحة وتنفس!' : 'Take a break and breathe!' 
      });
    };

    // Show notification immediately when enabled
    showStressNotification();

    // Then every 4 hours
    const interval = setInterval(showStressNotification, 4 * 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, [stressRemindersEnabled, t, language]);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('userProfile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('meals', JSON.stringify(meals));
  }, [meals]);

  useEffect(() => {
    localStorage.setItem('partialMeals', JSON.stringify(partialMeals));
  }, [partialMeals]);

  useEffect(() => {
    localStorage.setItem('favoriteProducts', JSON.stringify(favoriteProducts));
  }, [favoriteProducts]);

  useEffect(() => {
    localStorage.setItem('recipes', JSON.stringify(recipes));
  }, [recipes]);

  useEffect(() => {
    localStorage.setItem('waterIntake', waterIntake.toString());
    localStorage.setItem('waterIntakeDate', new Date().toDateString());
  }, [waterIntake]);

  useEffect(() => {
    localStorage.setItem('steps', steps.toString());
  }, [steps]);

  useEffect(() => {
    if (fastingSession) {
      localStorage.setItem('fastingSession', JSON.stringify(fastingSession));
    } else {
      localStorage.removeItem('fastingSession');
    }
  }, [fastingSession]);

  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('dailyLogs', JSON.stringify(dailyLogs));
  }, [dailyLogs]);

  useEffect(() => {
    localStorage.setItem('waterRemindersEnabled', waterRemindersEnabled.toString());
  }, [waterRemindersEnabled]);

  useEffect(() => {
    localStorage.setItem('stressRemindersEnabled', stressRemindersEnabled.toString());
  }, [stressRemindersEnabled]);

  useEffect(() => {
    localStorage.setItem('complianceDays', complianceDays.toString());
  }, [complianceDays]);

  const updateProfile = (updates: Partial<UserProfile>) => {
    setProfile(prev => ({ ...prev, ...updates }));
  };

  const addMeal = (meal: Meal) => {
    setMeals(prev => [meal, ...prev]);
    
    // Check for high sugar/salt warnings
    if (meal.sugar && meal.sugar > 25) {
      toast.warning(t('warning'), { description: t('highSugar') });
    }
    if (meal.salt && meal.salt > 2.3) {
      toast.warning(t('warning'), { description: t('highSalt') });
    }
  };

  const removeMeal = (id: string) => {
    setMeals(prev => prev.filter(m => m.id !== id));
  };

  const updateMeal = (id: string, updates: Partial<Meal>) => {
    setMeals(prev => prev.map(m => m.id === id ? { ...m, ...updates } : m));
  };

  const addPartialMeal = (meal: PartialMeal) => {
    setPartialMeals(prev => [meal, ...prev]);
  };

  const consumePartialMeal = (id: string, portion: number) => {
    setPartialMeals(prev => prev.map(m => {
      if (m.id === id) {
        const newRemaining = Math.max(0, m.remainingPortion - portion);
        return { ...m, remainingPortion: newRemaining };
      }
      return m;
    }).filter(m => m.remainingPortion > 0));
  };

  const removePartialMeal = (id: string) => {
    setPartialMeals(prev => prev.filter(m => m.id !== id));
  };

  const addFavorite = (product: FavoriteProduct) => {
    setFavoriteProducts(prev => {
      if (prev.some(p => p.id === product.id)) return prev;
      return [product, ...prev];
    });
  };

  const removeFavorite = (id: string) => {
    setFavoriteProducts(prev => prev.filter(p => p.id !== id));
  };

  const addRecipe = (recipe: Recipe) => {
    setRecipes(prev => [recipe, ...prev]);
  };

  const removeRecipe = (id: string) => {
    setRecipes(prev => prev.filter(r => r.id !== id));
  };

  const addWater = (amount: number) => {
    setWaterIntake(prev => prev + amount);
  };

  const addSteps = (count: number) => {
    setSteps(prev => prev + count);
  };

  const startFasting = (hours: number) => {
    const now = new Date();
    const endTime = new Date(now.getTime() + hours * 60 * 60 * 1000);
    setFastingSession({
      id: Date.now().toString(),
      startTime: now,
      duration: hours,
      endTime,
      isActive: true,
    });
  };

  const stopFasting = () => {
    setFastingSession(null);
  };

  const setWaterRemindersEnabled = (enabled: boolean) => {
    setWaterRemindersEnabledState(enabled);
    if (enabled && 'Notification' in window) {
      Notification.requestPermission();
    }
  };

  const setStressRemindersEnabled = (enabled: boolean) => {
    setStressRemindersEnabledState(enabled);
  };

  const dailyTotals = meals.reduce(
    (acc, meal) => {
      const today = new Date().toDateString();
      const mealDate = new Date(meal.timestamp).toDateString();
      if (mealDate === today) {
        return {
          calories: acc.calories + (meal.calories * meal.quantity),
          protein: acc.protein + (meal.protein * meal.quantity),
          carbs: acc.carbs + (meal.carbs * meal.quantity),
          fat: acc.fat + (meal.fat * meal.quantity),
          sugar: acc.sugar + ((meal.sugar || 0) * meal.quantity),
          salt: acc.salt + ((meal.salt || 0) * meal.quantity),
        };
      }
      return acc;
    },
    { calories: 0, protein: 0, carbs: 0, fat: 0, sugar: 0, salt: 0 }
  );

  const exportData = (): string => {
    const data = {
      profile,
      meals,
      recipes,
      partialMeals,
      favoriteProducts,
      waterIntake,
      steps,
      fastingSession,
      dailyLogs,
      complianceDays,
    };
    return JSON.stringify(data);
  };

  const importData = (dataStr: string): boolean => {
    try {
      const data = JSON.parse(dataStr);
      if (data.profile) setProfile(data.profile);
      if (data.meals) setMeals(data.meals.map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) })));
      if (data.recipes) setRecipes(data.recipes);
      if (data.partialMeals) setPartialMeals(data.partialMeals);
      if (data.favoriteProducts) setFavoriteProducts(data.favoriteProducts);
      if (data.waterIntake) setWaterIntake(data.waterIntake);
      if (data.steps) setSteps(data.steps);
      if (data.dailyLogs) setDailyLogs(data.dailyLogs);
      if (data.complianceDays) setComplianceDays(data.complianceDays);
      toast.success(t('dataImported'));
      return true;
    } catch {
      toast.error(t('invalidData'));
      return false;
    }
  };

  return (
    <NutritionContext.Provider
      value={{
        activeTab,
        setActiveTab,
        profile,
        updateProfile,
        meals,
        addMeal,
        removeMeal,
        updateMeal,
        partialMeals,
        addPartialMeal,
        consumePartialMeal,
        removePartialMeal,
        favoriteProducts,
        addFavorite,
        removeFavorite,
        recipes,
        addRecipe,
        removeRecipe,
        waterIntake,
        addWater,
        steps,
        addSteps,
        fastingSession,
        startFasting,
        stopFasting,
        dailyTotals,
        language,
        setLanguage,
        t,
        dailyLogs,
        waterRemindersEnabled,
        setWaterRemindersEnabled,
        stressRemindersEnabled,
        setStressRemindersEnabled,
        exportData,
        importData,
        complianceDays,
      }}
    >
      {children}
    </NutritionContext.Provider>
  );
};
