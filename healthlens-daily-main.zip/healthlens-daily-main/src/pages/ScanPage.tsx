import { useState, useRef } from 'react';
import { Camera, Upload, X, Loader2 } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { Meal } from '@/types/nutrition';
import { analyzeFood, FoodAnalysisResult } from '@/lib/gemini-api';
import { ScanResultView } from '@/components/scan/ScanResultView';

export const ScanPage = () => {
  const { language, addMeal, setActiveTab, addFavorite } = useNutrition();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<FoodAnalysisResult | null>(null);

  const handleCapture = () => {
    // Use native camera via input capture
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const dataUrl = reader.result as string;
      setCapturedImage(dataUrl);
      await analyzeFoodImage(dataUrl);
    };
    reader.readAsDataURL(file);
    
    // Reset input so same file can be selected again
    e.target.value = '';
  };

  const analyzeFoodImage = async (imageData: string) => {
    setIsLoading(true);
    try {
      const result = await analyzeFood(imageData, language);
      setAnalysisResult(result);
    } catch (error) {
      console.error('Analysis failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleMealScanned = (meal: Meal) => {
    addMeal(meal);
    setCapturedImage(null);
    setAnalysisResult(null);
    setActiveTab('home');
  };

  const handleSaveToFavorites = () => {
    if (!analysisResult) return;
    addFavorite({
      id: Date.now().toString(),
      name: analysisResult.name,
      nameAr: analysisResult.nameAr,
      calories: analysisResult.calories,
      protein: analysisResult.protein,
      carbs: analysisResult.carbs,
      fat: analysisResult.fat,
      sugar: analysisResult.sugar,
      salt: analysisResult.salt,
    });
  };

  const retake = () => {
    setCapturedImage(null);
    setAnalysisResult(null);
  };

  // Show result view when we have analysis
  if (analysisResult) {
    return (
      <ScanResultView
        result={analysisResult}
        capturedImage={capturedImage}
        language={language}
        onConfirm={handleMealScanned}
        onRetake={retake}
        onSaveToFavorites={handleSaveToFavorites}
      />
    );
  }

  return (
    <div className="pb-24 pt-8 px-4">
      <h1 className="text-2xl font-bold text-foreground mb-6">
        {language === 'ar' ? 'مسح الطعام' : 'Scan Food'}
      </h1>

      {/* Hidden file input with camera capture */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Loading State */}
      {isLoading && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="text-center bg-card p-8 rounded-2xl card-shadow">
            <Loader2 size={48} className="animate-spin text-primary mx-auto mb-4" />
            <p className="text-foreground font-medium">
              {language === 'ar' ? 'جاري التحليل...' : 'Analyzing...'}
            </p>
          </div>
        </div>
      )}

      {/* Main Scan Button */}
      <button
        onClick={handleCapture}
        className="w-full bg-primary text-primary-foreground rounded-2xl p-6 card-shadow-lg hover:opacity-90 transition-opacity"
      >
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-full bg-primary-foreground/20 flex items-center justify-center mb-4">
            <Camera size={32} />
          </div>
          <h3 className="text-lg font-semibold mb-2">
            {language === 'ar' ? 'تصوير الوجبة أو الباركود' : 'Scan Meal or Barcode'}
          </h3>
          <p className="text-sm opacity-80">
            {language === 'ar' 
              ? 'التقط صورة للوجبة أو الباركود للحصول على المعلومات الغذائية'
              : 'Take a photo of your meal or barcode for nutrition info'}
          </p>
        </div>
      </button>

      {/* Upload Option */}
      <button
        onClick={() => {
          // Create a second input without capture for gallery
          const input = document.createElement('input');
          input.type = 'file';
          input.accept = 'image/*';
          input.onchange = (e) => handleFileChange(e as any);
          input.click();
        }}
        className="w-full mt-4 bg-card border border-border text-foreground rounded-2xl p-6 card-shadow hover:bg-muted transition-colors"
      >
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
            <Upload size={32} className="text-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">
            {language === 'ar' ? 'رفع صورة' : 'Upload Image'}
          </h3>
          <p className="text-sm text-muted-foreground">
            {language === 'ar' 
              ? 'اختر صورة من معرض الصور'
              : 'Choose an image from your gallery'}
          </p>
        </div>
      </button>

      {/* Tips */}
      <div className="mt-8 bg-card rounded-2xl p-5 card-shadow">
        <h3 className="font-semibold text-foreground mb-3">
          {language === 'ar' ? 'نصائح للحصول على أفضل نتائج' : 'Tips for best results'}
        </h3>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li className="flex items-start gap-2">
            <span className="text-primary">•</span>
            {language === 'ar' 
              ? 'تأكد من وجود إضاءة جيدة عند التصوير'
              : 'Make sure you have good lighting when taking photos'}
          </li>
          <li className="flex items-start gap-2">
            <span className="text-primary">•</span>
            {language === 'ar' 
              ? 'ضع الطعام أو الباركود في منتصف الكاميرا'
              : 'Center the food or barcode in the camera frame'}
          </li>
          <li className="flex items-start gap-2">
            <span className="text-primary">•</span>
            {language === 'ar' 
              ? 'للباركود، تأكد من وضوح الباركود في الصورة'
              : 'For barcodes, ensure the barcode is clear and visible'}
          </li>
        </ul>
      </div>
    </div>
  );
};
