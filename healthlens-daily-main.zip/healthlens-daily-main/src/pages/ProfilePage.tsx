import { useState } from 'react';
import { User, LogOut, ChevronDown, Lightbulb, Crown, Bell, Droplets, Brain, Plus, Minus, Download, Upload } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { Switch } from '@/components/ui/switch';
import { SugarLimitSettings } from '@/components/settings/SugarLimitSettings';
import { PremiumPage } from '@/components/premium/PremiumPage';
export const ProfilePage = () => {
  const { 
    language, 
    setLanguage, 
    profile, 
    updateProfile, 
    t,
    waterRemindersEnabled,
    setWaterRemindersEnabled,
    stressRemindersEnabled,
    setStressRemindersEnabled,
    exportData,
    importData,
  } = useNutrition();
  const [isActivityOpen, setIsActivityOpen] = useState(false);
  const [showPremium, setShowPremium] = useState(false);

  const bmi = profile.weight / Math.pow(profile.height / 100, 2);
  const bmiCategory = bmi < 18.5 ? (language === 'ar' ? 'نحيف' : 'Underweight') 
    : bmi < 25 ? (language === 'ar' ? 'وزن صحي' : 'Healthy Weight')
    : bmi < 30 ? (language === 'ar' ? 'زيادة وزن' : 'Overweight')
    : (language === 'ar' ? 'سمنة' : 'Obese');

  const dailyWaterNeed = Math.round(profile.weight * 35); // 35ml per kg
  
  // Protein calculation based on activity level
  const getProteinMultiplier = () => {
    switch (profile.activityLevel) {
      case 'sedentary': return 0.8;
      case 'light': return 1.0;
      case 'moderate': return 1.2;
      case 'active': return 1.6;
      case 'veryActive': return 2.0;
      default: return 1.2;
    }
  };
  
  const dailyProteinNeed = Math.round(profile.weight * getProteinMultiplier());

  // Sugar limit based on age (WHO recommendations)
  const getSugarLimit = () => {
    if (profile.age < 2) return 0;
    if (profile.age < 18) return 25;
    return 30;
  };

  const activityLevels = [
    { value: 'sedentary', label: 'Sedentary', labelAr: 'قليل النشاط', proteinMultiplier: 0.8 },
    { value: 'light', label: 'Light', labelAr: 'نشاط خفيف', proteinMultiplier: 1.0 },
    { value: 'moderate', label: 'Moderate', labelAr: 'متوسط', proteinMultiplier: 1.2 },
    { value: 'active', label: 'Active', labelAr: 'نشيط', proteinMultiplier: 1.6 },
    { value: 'veryActive', label: 'Very Active', labelAr: 'نشيط جداً', proteinMultiplier: 2.0 },
  ];

  const tips = language === 'ar' 
    ? [
        'اشرب الماء بانتظام طوال اليوم',
        'تناول البروتين في كل وجبة رئيسية',
        'راقب وزنك مرة أسبوعياً',
        'مارس الرياضة 3-4 مرات أسبوعياً',
      ]
    : [
        'Drink water regularly throughout the day',
        'Include protein in every main meal',
        'Monitor your weight weekly',
        'Exercise 3-4 times per week',
      ];

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }
    return false;
  };

  const handleWaterToggle = async (enabled: boolean) => {
    if (enabled) {
      const granted = await requestNotificationPermission();
      if (granted) {
        setWaterRemindersEnabled(true);
      }
    } else {
      setWaterRemindersEnabled(false);
    }
  };

  const handleStressToggle = async (enabled: boolean) => {
    if (enabled) {
      const granted = await requestNotificationPermission();
      if (granted) {
        setStressRemindersEnabled(true);
      }
    } else {
      setStressRemindersEnabled(false);
    }
  };

  const handleExport = () => {
    const data = exportData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nutrition-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (ev) => {
          const data = ev.target?.result as string;
          importData(data);
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  return (
    <div className="pb-24 pt-8 px-4">
      {/* Account Header */}
      <div className="bg-card rounded-2xl p-4 card-shadow flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
            <User size={24} className="text-muted-foreground" />
          </div>
          <div>
            <h2 className="font-semibold text-foreground">
              {language === 'ar' ? 'حسابي' : 'My Account'}
            </h2>
            <p className="text-sm text-muted-foreground">
              {language === 'ar' ? 'معلومات صحتك الشخصية' : 'Your personal health info'}
            </p>
          </div>
        </div>
        <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
          <LogOut size={18} />
          <span className="text-sm">{language === 'ar' ? 'خروج' : 'Logout'}</span>
        </button>
      </div>

      {/* Premium Card */}
      <button
        onClick={() => setShowPremium(true)}
        className="w-full bg-gradient-to-r from-primary to-primary/80 rounded-2xl p-4 card-shadow mb-4 text-left"
      >
        <div className="flex items-center justify-between text-primary-foreground">
          <div className="flex items-center gap-3">
            <Crown size={24} />
            <div>
              <h3 className="font-semibold">
                {language === 'ar' ? 'ترقية إلى بريميوم' : 'Upgrade to Premium'}
              </h3>
              <p className="text-sm opacity-80">
                {language === 'ar' ? 'افتح جميع الميزات' : 'Unlock all features'}
              </p>
            </div>
          </div>
          <div className="text-right">
            <span className="text-2xl font-bold">$7</span>
            <p className="text-xs opacity-80">{language === 'ar' ? 'شهرياً' : 'per month'}</p>
          </div>
        </div>
      </button>

      {/* Notifications Settings */}
      <div className="bg-card rounded-2xl p-4 card-shadow mb-4">
        <div className="flex items-center gap-2 mb-4">
          <Bell size={20} className="text-primary" />
          <h3 className="font-semibold text-foreground">{t('notifications')}</h3>
        </div>
        
        <div className="space-y-4">
          {/* Water Reminders */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-water/10 flex items-center justify-center">
                <Droplets size={20} className="text-water" />
              </div>
              <div>
                <p className="font-medium text-foreground text-sm">{t('waterReminder')}</p>
                <p className="text-xs text-muted-foreground">
                  {language === 'ar' ? 'كل ساعتين خلال فترة الاستيقاظ' : 'Every 2 hours during awake time'}
                </p>
              </div>
            </div>
            <Switch 
              checked={waterRemindersEnabled}
              onCheckedChange={handleWaterToggle}
            />
          </div>
          
          {/* Stress Reminders */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Brain size={20} className="text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground text-sm">{t('breathingExercise')}</p>
                <p className="text-xs text-muted-foreground">
                  {language === 'ar' ? 'تنبيهات للتقليل من التوتر' : 'Stress relief reminders'}
                </p>
              </div>
            </div>
            <Switch 
              checked={stressRemindersEnabled}
              onCheckedChange={handleStressToggle}
            />
          </div>
        </div>
      </div>

      {/* Body Stats */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-card rounded-2xl p-4 card-shadow">
          <label className="text-sm text-muted-foreground">
            {language === 'ar' ? 'الوزن (كج)' : 'Weight (kg)'}
          </label>
          <input
            type="number"
            value={profile.weight}
            onChange={(e) => updateProfile({ weight: parseInt(e.target.value) || 0 })}
            className="w-full text-2xl font-bold text-foreground bg-transparent border-none outline-none"
          />
        </div>
        <div className="bg-card rounded-2xl p-4 card-shadow">
          <label className="text-sm text-muted-foreground">
            {language === 'ar' ? 'الطول (سم)' : 'Height (cm)'}
          </label>
          <input
            type="number"
            value={profile.height}
            onChange={(e) => updateProfile({ height: parseInt(e.target.value) || 0 })}
            className="w-full text-2xl font-bold text-foreground bg-transparent border-none outline-none"
          />
        </div>
        <div className="bg-card rounded-2xl p-4 card-shadow">
          <label className="text-sm text-muted-foreground">
            {language === 'ar' ? 'العمر' : 'Age'}
          </label>
          <input
            type="number"
            value={profile.age}
            onChange={(e) => updateProfile({ age: parseInt(e.target.value) || 0 })}
            className="w-full text-2xl font-bold text-foreground bg-transparent border-none outline-none"
          />
        </div>
        <div className="bg-card rounded-2xl p-4 card-shadow relative">
          <label className="text-sm text-muted-foreground">
            {language === 'ar' ? 'مستوى النشاط' : 'Activity Level'}
          </label>
          <button 
            onClick={() => setIsActivityOpen(!isActivityOpen)}
            className="w-full flex items-center justify-between"
          >
            <span className="text-lg font-semibold text-foreground">
              {activityLevels.find(l => l.value === profile.activityLevel)?.[language === 'ar' ? 'labelAr' : 'label']}
            </span>
            <ChevronDown size={18} className={`text-muted-foreground transition-transform ${isActivityOpen ? 'rotate-180' : ''}`} />
          </button>
          
          {isActivityOpen && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-card rounded-xl border border-border shadow-lg z-10">
              {activityLevels.map((level) => (
                <button
                  key={level.value}
                  onClick={() => {
                    updateProfile({ activityLevel: level.value as any });
                    setIsActivityOpen(false);
                  }}
                  className={`w-full px-4 py-3 text-left hover:bg-muted transition-colors first:rounded-t-xl last:rounded-b-xl ${
                    profile.activityLevel === level.value ? 'bg-primary/10 text-primary' : 'text-foreground'
                  }`}
                >
                  <span>{language === 'ar' ? level.labelAr : level.label}</span>
                  <span className="text-xs text-muted-foreground ms-2">
                    ({level.proteinMultiplier}g/{language === 'ar' ? 'كج' : 'kg'})
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Sugar Limit Setting */}
      <SugarLimitSettings 
        language={language} 
        profile={profile} 
        updateProfile={updateProfile}
        defaultLimit={getSugarLimit()}
      />

      {/* Water Cup Size */}
      <div className="bg-card rounded-2xl p-4 card-shadow mb-4">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xl">💧</span>
          <span className="font-medium text-foreground">
            {language === 'ar' ? 'حجم كوب الماء' : 'Water Cup Size'}
          </span>
        </div>
        <div className="flex gap-2">
          {[150, 200, 250, 300].map((size) => (
            <button
              key={size}
              onClick={() => updateProfile({ waterCupSize: size })}
              className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                profile.waterCupSize === size 
                  ? 'bg-foreground text-background' 
                  : 'bg-muted text-foreground'
              }`}
            >
              {size}ml
            </button>
          ))}
        </div>
      </div>

      {/* BMI */}
      <div className="bg-card rounded-2xl p-4 card-shadow mb-4">
        <div className="flex items-center justify-between mb-3">
          <span className="font-medium text-foreground">
            {language === 'ar' ? '(BMI) مؤشر كتلة الجسم' : 'BMI (Body Mass Index)'}
          </span>
          <span className="text-2xl font-bold text-primary">{bmi.toFixed(1)}</span>
        </div>
        <div className="h-3 bg-gradient-to-r from-info via-primary to-destructive rounded-full mb-2 relative">
          <div 
            className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-foreground rounded-full border-2 border-card"
            style={{ left: `${Math.min(Math.max((bmi - 15) / 25 * 100, 0), 100)}%` }}
          />
        </div>
        <p className="text-center text-sm font-medium text-primary">{bmiCategory}</p>
      </div>

      {/* Daily Needs */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-card rounded-2xl p-4 card-shadow">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-water-light flex items-center justify-center">
              <span>💧</span>
            </div>
            <span className="text-sm text-muted-foreground">
              {language === 'ar' ? 'احتياجات الماء اليومية' : 'Daily Water Needs'}
            </span>
          </div>
          <p className="text-2xl font-bold text-foreground">{(dailyWaterNeed / 1000).toFixed(1)}L</p>
          <p className="text-xs text-muted-foreground">{language === 'ar' ? 'يومياً' : 'daily'} {dailyWaterNeed}ml</p>
        </div>
        <div className="bg-card rounded-2xl p-4 card-shadow">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-protein-light flex items-center justify-center">
              <span>🥩</span>
            </div>
            <span className="text-sm text-muted-foreground">
              {language === 'ar' ? 'احتياجات البروتين' : 'Protein Needs'}
            </span>
          </div>
          <p className="text-2xl font-bold text-foreground">{dailyProteinNeed}g</p>
          <p className="text-xs text-muted-foreground">
            {getProteinMultiplier()}g/{language === 'ar' ? 'كج' : 'kg'}
          </p>
        </div>
      </div>

      {/* Sleep Time Settings */}
      <div className="bg-card rounded-2xl p-4 card-shadow mb-4">
        <h3 className="font-medium text-foreground mb-3">
          {language === 'ar' ? 'وقت النوم (لتنبيهات الماء)' : 'Sleep Time (for water reminders)'}
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm text-muted-foreground block mb-1">
              {language === 'ar' ? 'بداية النوم' : 'Sleep Start'}
            </label>
            <input
              type="time"
              value={profile.sleepStart}
              onChange={(e) => updateProfile({ sleepStart: e.target.value })}
              className="w-full bg-muted border border-border rounded-xl px-4 py-2 text-foreground"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground block mb-1">
              {language === 'ar' ? 'نهاية النوم' : 'Sleep End'}
            </label>
            <input
              type="time"
              value={profile.sleepEnd}
              onChange={(e) => updateProfile({ sleepEnd: e.target.value })}
              className="w-full bg-muted border border-border rounded-xl px-4 py-2 text-foreground"
            />
          </div>
        </div>
      </div>

      {/* Custom Fasting Hours */}
      <div className="bg-card rounded-2xl p-4 card-shadow mb-4">
        <h3 className="font-medium text-foreground mb-3">
          {language === 'ar' ? 'ساعات الصيام المخصصة' : 'Custom Fasting Hours'}
        </h3>
        <input
          type="number"
          value={profile.customFastingHours || ''}
          onChange={(e) => updateProfile({ customFastingHours: parseInt(e.target.value) || undefined })}
          placeholder={language === 'ar' ? 'مثال: 20' : 'e.g., 20'}
          className="w-full bg-muted border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground"
        />
      </div>

      {/* Backup & Sync */}
      <div className="bg-card rounded-2xl p-4 card-shadow mb-4">
        <h3 className="font-medium text-foreground mb-3">
          {t('backup')}
        </h3>
        <div className="flex gap-2">
          <button
            onClick={handleExport}
            className="flex-1 py-3 bg-primary text-primary-foreground rounded-xl font-medium flex items-center justify-center gap-2"
          >
            <Download size={18} />
            {t('exportData')}
          </button>
          <button
            onClick={handleImport}
            className="flex-1 py-3 border border-border rounded-xl font-medium flex items-center justify-center gap-2 text-foreground"
          >
            <Upload size={18} />
            {t('importData')}
          </button>
        </div>
      </div>

      {/* Language */}
      <div className="bg-card rounded-2xl p-4 card-shadow mb-4">
        <h3 className="font-medium text-foreground mb-3">
          {language === 'ar' ? 'اللغة' : 'Language'}
        </h3>
        <div className="grid grid-cols-5 gap-2">
          {[
            { code: 'en', label: 'EN' },
            { code: 'ar', label: 'عربي' },
            { code: 'es', label: 'ES' },
            { code: 'de', label: 'DE' },
            { code: 'fr', label: 'FR' },
          ].map((lang) => (
            <button
              key={lang.code}
              onClick={() => setLanguage(lang.code as any)}
              className={`py-2.5 rounded-xl text-sm font-medium transition-colors ${
                language === lang.code ? 'bg-foreground text-background' : 'bg-muted text-foreground'
              }`}
            >
              {lang.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tips */}
      <div className="bg-warning/10 rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <Lightbulb className="text-warning" size={20} />
          <h3 className="font-semibold text-foreground">
            {language === 'ar' ? 'نصائح مهمة' : 'Important Tips'}
          </h3>
        </div>
        <ul className="space-y-2">
          {tips.map((tip, index) => (
            <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
              <span className="text-warning">•</span>
              {tip}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
