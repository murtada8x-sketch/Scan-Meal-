import { NutritionProvider, useNutrition } from '@/contexts/NutritionContext';
import { BottomNavigation } from '@/components/BottomNavigation';
import { HomePage } from '@/pages/HomePage';
import { ReportsPage } from '@/pages/ReportsPage';
import { ScanPage } from '@/pages/ScanPage';
import { RecipesPage } from '@/pages/RecipesPage';
import { ProfilePage } from '@/pages/ProfilePage';

const AppContent = () => {
  const { activeTab, language } = useNutrition();

  return (
    <div className="min-h-screen bg-background max-w-md mx-auto" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <div className="pt-4 pb-20">
        {activeTab === 'home' && <HomePage />}
        {activeTab === 'reports' && <ReportsPage />}
        {activeTab === 'scan' && <ScanPage />}
        {activeTab === 'recipes' && <RecipesPage />}
        {activeTab === 'profile' && <ProfilePage />}
      </div>
      <BottomNavigation />
    </div>
  );
};

const Index = () => {
  return (
    <NutritionProvider>
      <AppContent />
    </NutritionProvider>
  );
};

export default Index;
