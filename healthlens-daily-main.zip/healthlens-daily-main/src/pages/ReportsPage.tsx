import { useState } from 'react';
import { ChevronLeft, ChevronRight, TrendingUp, TrendingDown, CheckCircle } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { ReportTab } from '@/types/nutrition';
import { PDFReport } from '@/components/reports/PDFReport';

const reportTabs: { id: ReportTab; label: string; labelAr: string; icon: string; color: string }[] = [
  { id: 'overview', label: 'Overview', labelAr: 'نظرة عامة', icon: '⊙', color: 'bg-foreground text-background' },
  { id: 'protein', label: 'Protein', labelAr: 'بروتين', icon: '🥩', color: 'bg-protein text-primary-foreground' },
  { id: 'carbs', label: 'Carbs', labelAr: 'كارب', icon: '🌾', color: 'bg-carbs text-primary-foreground' },
  { id: 'fats', label: 'Fats', labelAr: 'دهون', icon: '💧', color: 'bg-fats text-primary-foreground' },
  { id: 'vitamins', label: 'Vitamins', labelAr: 'فيتامينات', icon: '💊', color: 'bg-vitamins text-primary-foreground' },
  { id: 'amino', label: 'Amino Acids', labelAr: 'أحماض أمينية', icon: '🧬', color: 'bg-amino text-primary-foreground' },
  { id: 'hydration', label: 'Hydration', labelAr: 'الماء', icon: '💧', color: 'bg-water text-primary-foreground' },
  { id: 'compliance', label: 'Compliance', labelAr: 'الالتزام', icon: '✓', color: 'bg-primary text-primary-foreground' },
];

const weekDays = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

// Sample data for charts
const getWeeklyData = (offset: number) => ({
  protein: [80 - offset * 5, 95 - offset * 3, 70 + offset * 2, 88, 110 - offset, 125, 90].map(v => Math.max(0, v)),
  carbs: [120, 140 - offset * 10, 130, 150 + offset * 5, 145, 160, 135],
  fats: [35, 42, 38 + offset * 2, 50, 55, 48, 40],
  vitamins: [70, 75 + offset * 5, 80, 82, 90, 95, 85],
  amino: [65, 72, 68, 80, 85, 78, 75],
  hydration: [1800, 2000, 1600, 2200, 2400, 2100, 1900],
  compliance: [1, 1, 0, 1, 1, 1, 0], // 1 = compliant, 0 = not
});

const vitaminsDetails = [
  { name: 'Vitamin A', nameAr: 'فيتامين A', value: 95, amount: '900mcg', color: 'bg-primary' },
  { name: 'Vitamin B1 (Thiamin)', nameAr: 'فيتامين B1', value: 78, amount: '1.2mg', color: 'bg-warning' },
  { name: 'Vitamin B2 (Riboflavin)', nameAr: 'فيتامين B2', value: 82, amount: '1.3mg', color: 'bg-primary' },
  { name: 'Vitamin B6', nameAr: 'فيتامين B6', value: 88, amount: '1.7mg', color: 'bg-warning' },
  { name: 'Vitamin B12', nameAr: 'فيتامين B12', value: 92, amount: '2.4mcg', color: 'bg-warning' },
  { name: 'Vitamin C', nameAr: 'فيتامين C', value: 88, amount: '90mg', color: 'bg-primary' },
  { name: 'Vitamin D', nameAr: 'فيتامين D', value: 45, amount: '20mcg', color: 'bg-warning' },
  { name: 'Vitamin E', nameAr: 'فيتامين E', value: 72, amount: '15mg', color: 'bg-info' },
  { name: 'Vitamin K', nameAr: 'فيتامين K', value: 68, amount: '120mcg', color: 'bg-info' },
];

const aminoDetails = [
  { name: 'Leucine', desc: 'Muscle protein synthesis', value: 85, color: 'bg-amino' },
  { name: 'Isoleucine', desc: 'Energy regulation', value: 78, color: 'bg-warning' },
  { name: 'Valine', desc: 'Muscle metabolism', value: 82, color: 'bg-primary' },
  { name: 'Lysine', desc: 'Collagen production', value: 72, color: 'bg-primary' },
  { name: 'Methionine', desc: 'Antioxidant', value: 65, color: 'bg-primary' },
  { name: 'Phenylalanine', desc: 'Neurotransmitters', value: 88, color: 'bg-primary' },
  { name: 'Threonine', desc: 'Immune function', value: 75, color: 'bg-primary' },
  { name: 'Tryptophan', desc: 'Serotonin production', value: 68, color: 'bg-amino' },
  { name: 'Histidine', desc: 'Tissue repair', value: 80, color: 'bg-warning' },
];

export const ReportsPage = () => {
  const { language, dailyTotals, t, complianceDays, fastingSession } = useNutrition();
  const [activeTab, setActiveTab] = useState<ReportTab>('overview');
  const [weekOffset, setWeekOffset] = useState(0);

  const weeklyData = getWeeklyData(weekOffset);

  const getWeekLabel = () => {
    if (weekOffset === 0) return language === 'ar' ? 'هذا الأسبوع' : 'This Week';
    if (weekOffset === 1) return language === 'ar' ? 'الأسبوع الماضي' : 'Last Week';
    return language === 'ar' ? `منذ ${weekOffset} أسابيع` : `${weekOffset} weeks ago`;
  };

  const getTabColor = (tabId: ReportTab) => {
    switch (tabId) {
      case 'protein': return 'bg-protein';
      case 'carbs': return 'bg-carbs';
      case 'fats': return 'bg-fats';
      case 'vitamins': return 'bg-vitamins';
      case 'amino': return 'bg-amino';
      case 'hydration': return 'bg-water';
      case 'compliance': return 'bg-primary';
      default: return 'bg-muted';
    }
  };

  const getTabData = () => {
    switch (activeTab) {
      case 'protein': return { data: weeklyData.protein, avg: 112, unit: 'g', trend: 12 };
      case 'carbs': return { data: weeklyData.carbs, avg: 148, unit: 'g', trend: 8 };
      case 'fats': return { data: weeklyData.fats, avg: 45, unit: 'g', trend: -5 };
      case 'vitamins': return { data: weeklyData.vitamins, avg: 85, unit: '%', trend: 15 };
      case 'amino': return { data: weeklyData.amino, avg: 78, unit: '%', trend: 8 };
      case 'hydration': return { data: weeklyData.hydration, avg: 2000, unit: 'ml', trend: 10 };
      case 'compliance': return { data: weeklyData.compliance, avg: complianceDays, unit: language === 'ar' ? 'يوم' : 'days', trend: 5 };
      default: return { data: [], avg: 0, unit: '', trend: 0 };
    }
  };

  const tabData = getTabData();
  const maxValue = Math.max(...tabData.data);

  return (
    <div className="pb-24 pt-8 px-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-foreground">
          {language === 'ar' ? 'التقارير' : 'Reports'}
        </h1>
        <div className="flex items-center gap-2 bg-card rounded-full px-4 py-2 border border-border">
          <button onClick={() => setWeekOffset(w => w + 1)}>
            <ChevronLeft size={18} className="text-muted-foreground" />
          </button>
          <span className="text-sm font-medium text-foreground px-2 min-w-[100px] text-center">
            {getWeekLabel()}
          </span>
          <button 
            onClick={() => setWeekOffset(w => Math.max(0, w - 1))}
            disabled={weekOffset === 0}
            className="disabled:opacity-30"
          >
            <ChevronRight size={18} className="text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* PDF Download Buttons */}
      <div className="flex gap-3 mb-6">
        <PDFReport period="week" />
        <PDFReport period="month" />
      </div>

      {/* Tabs */}
      <div className="overflow-x-auto hide-scrollbar mb-6 -mx-4 px-4">
        <div className="flex gap-2">
          {reportTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all flex items-center gap-2 ${
                activeTab === tab.id 
                  ? tab.color
                  : 'bg-card text-foreground border border-border'
              }`}
            >
              <span>{tab.icon}</span>
              {language === 'ar' ? tab.labelAr : tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {activeTab === 'overview' ? (
        <OverviewContent language={language} dailyTotals={dailyTotals} fastingSession={fastingSession} t={t} />
      ) : activeTab === 'vitamins' ? (
        <VitaminsContent language={language} />
      ) : activeTab === 'amino' ? (
        <AminoContent language={language} />
      ) : activeTab === 'compliance' ? (
        <ComplianceContent language={language} data={weeklyData.compliance} complianceDays={complianceDays} t={t} />
      ) : (
        <div className="space-y-6">
          {/* Chart Card */}
          <div className="bg-card rounded-2xl p-5 card-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="text-lg">{reportTabs.find(t => t.id === activeTab)?.icon}</span>
                <h3 className="font-semibold text-foreground">
                  {language === 'ar' ? 'متوسط ' : 'Avg Daily '}
                  {reportTabs.find(t => t.id === activeTab)?.[language === 'ar' ? 'labelAr' : 'label']}
                </h3>
              </div>
              <div className={`flex items-center gap-1 text-sm ${tabData.trend >= 0 ? 'text-primary' : 'text-destructive'}`}>
                {tabData.trend >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                {tabData.trend >= 0 ? '+' : ''}{tabData.trend}%
              </div>
            </div>

            <p className="text-4xl font-bold text-foreground mb-6">
              {tabData.avg}<span className="text-lg font-normal text-muted-foreground">{tabData.unit}</span>
            </p>

            {/* Bar Chart */}
            <div className="flex items-end justify-between gap-2 h-40">
              {tabData.data.map((value, index) => (
                <div key={index} className="flex-1 flex flex-col items-center gap-2">
                  <div className="w-full relative" style={{ height: '120px' }}>
                    <div 
                      className={`absolute bottom-0 left-1/2 -translate-x-1/2 w-8 rounded-full transition-all duration-500 ${getTabColor(activeTab)}`}
                      style={{ 
                        height: `${maxValue > 0 ? (value / maxValue) * 100 : 0}%`,
                        opacity: index === tabData.data.length - 1 ? 1 : 0.6 
                      }}
                    />
                    <div 
                      className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 rounded-full bg-muted"
                      style={{ height: '100%', zIndex: -1 }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground">{weekDays[index]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const OverviewContent = ({ language, dailyTotals, fastingSession, t }: { language: string; dailyTotals: any; fastingSession: any; t: (key: string) => string }) => {
  const [period, setPeriod] = useState<'week' | 'month'>('week');
  
  const totalCalories = period === 'week' ? 1850 : 1920;
  const protein = period === 'week' ? 112 : 118;
  const carbs = period === 'week' ? 148 : 155;
  const fats = period === 'week' ? 45 : 48;
  const vitamins = period === 'week' ? 85 : 82;

  // Calculate percentages for donut chart
  const total = protein * 4 + carbs * 4 + fats * 9;
  const proteinPercent = (protein * 4 / total) * 100;
  const carbsPercent = (carbs * 4 / total) * 100;
  const fatsPercent = (fats * 9 / total) * 100;

  return (
    <div className="space-y-4">
      {/* Fasting Progress Bar */}
      {fastingSession && (
        <div className="bg-card rounded-2xl p-4 card-shadow">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-lg">⏱️</span>
            <h3 className="font-semibold text-foreground">{t('fasting')}</h3>
          </div>
          <FastingProgressBar session={fastingSession} t={t} />
        </div>
      )}

      {/* Macros Overview Card */}
      <div className="bg-card rounded-2xl p-5 card-shadow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground text-lg">
            {language === 'ar' ? 'نظرة عامة على الماكروز' : 'Macros Overview'}
          </h3>
          
          {/* Period Toggle */}
          <div className="flex gap-2">
            <button
              onClick={() => setPeriod('week')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                period === 'week'
                  ? 'bg-foreground text-background'
                  : 'bg-muted text-muted-foreground border border-border'
              }`}
            >
              {language === 'ar' ? 'أسبوع' : 'Week'}
            </button>
            <button
              onClick={() => setPeriod('month')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-1 ${
                period === 'month'
                  ? 'bg-foreground text-background'
                  : 'bg-muted text-muted-foreground border border-border'
              }`}
            >
              <span>☆</span>
              {language === 'ar' ? 'شهر' : 'Month'}
            </button>
          </div>
        </div>

        <div className="flex items-center gap-6">
          {/* Donut Chart */}
          <div className="relative w-32 h-32">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="40" fill="none" stroke="hsl(var(--muted))" strokeWidth="12" />
              <circle 
                cx="50" cy="50" r="40" fill="none" 
                stroke="hsl(var(--protein))" strokeWidth="12"
                strokeDasharray={`${proteinPercent * 2.51} 251`}
                strokeDashoffset="0"
              />
              <circle 
                cx="50" cy="50" r="40" fill="none" 
                stroke="hsl(var(--carbs))" strokeWidth="12"
                strokeDasharray={`${carbsPercent * 2.51} 251`}
                strokeDashoffset={`${-proteinPercent * 2.51}`}
              />
              <circle 
                cx="50" cy="50" r="40" fill="none" 
                stroke="hsl(var(--fats))" strokeWidth="12"
                strokeDasharray={`${fatsPercent * 2.51} 251`}
                strokeDashoffset={`${-(proteinPercent + carbsPercent) * 2.51}`}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold text-foreground">{totalCalories}</span>
              <span className="text-xs text-muted-foreground">kcal/day</span>
            </div>
          </div>

          {/* Legend */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-protein" />
              <span className="text-lg">🥩</span>
              <span className="text-sm text-muted-foreground">{language === 'ar' ? 'بروتين' : 'Protein'}</span>
              <span className="font-bold text-foreground ml-auto">{protein}g</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-carbs" />
              <span className="text-lg">🌾</span>
              <span className="text-sm text-muted-foreground">{language === 'ar' ? 'كارب' : 'Carbs'}</span>
              <span className="font-bold text-foreground ml-auto">{carbs}g</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-fats" />
              <span className="text-lg">💧</span>
              <span className="text-sm text-muted-foreground">{language === 'ar' ? 'دهون' : 'Fats'}</span>
              <span className="font-bold text-foreground ml-auto">{fats}g</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-vitamins" />
              <span className="text-lg">💊</span>
              <span className="text-sm text-muted-foreground">{language === 'ar' ? 'فيتامينات' : 'Vitamins'}</span>
              <span className="font-bold text-foreground ml-auto">{vitamins}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-card rounded-2xl p-4 card-shadow">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-fats-light flex items-center justify-center">
              <span>💧</span>
            </div>
            <span className="text-sm text-muted-foreground">{language === 'ar' ? 'الدهون' : 'Fat Intake'}</span>
          </div>
          <p className="text-2xl font-bold text-foreground">{fats} <span className="text-sm font-normal text-muted-foreground">g</span></p>
          <div className="h-1.5 bg-muted rounded-full mt-2 overflow-hidden">
            <div className="h-full bg-fats rounded-full" style={{ width: `${(fats / 60) * 100}%` }} />
          </div>
        </div>

        <div className="bg-card rounded-2xl p-4 card-shadow">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-vitamins-light flex items-center justify-center">
              <span>💊</span>
            </div>
            <span className="text-sm text-muted-foreground">{language === 'ar' ? 'المايكرو' : 'Micros'}</span>
          </div>
          <p className="text-2xl font-bold text-foreground">{vitamins} <span className="text-sm font-normal text-muted-foreground">%</span></p>
          <div className="h-1.5 bg-muted rounded-full mt-2 overflow-hidden">
            <div className="h-full bg-vitamins rounded-full" style={{ width: `${vitamins}%` }} />
          </div>
        </div>
      </div>
    </div>
  );
};

const FastingProgressBar = ({ session, t }: { session: any; t: (key: string) => string }) => {
  const now = new Date();
  const start = new Date(session.startTime);
  const elapsed = (now.getTime() - start.getTime()) / (1000 * 60 * 60);
  const progress = Math.min((elapsed / session.targetHours) * 100, 100);
  
  const getProgressColor = () => {
    if (progress < 50) return 'bg-primary';
    if (progress < 80) return 'bg-warning';
    return 'bg-destructive';
  };

  return (
    <div>
      <div className="flex justify-between text-sm mb-2">
        <span className="text-muted-foreground">{elapsed.toFixed(1)}h</span>
        <span className="text-muted-foreground">{session.targetHours}h</span>
      </div>
      <div className="h-3 bg-muted rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full transition-all duration-500 ${getProgressColor()}`}
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};

const VitaminsContent = ({ language }: { language: string }) => {
  const avg = 85;
  const weeklyData = [70, 75, 80, 82, 90, 95, 85];
  const maxValue = Math.max(...weeklyData);

  return (
    <div className="space-y-4">
      {/* Chart */}
      <div className="bg-card rounded-2xl p-5 card-shadow">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-lg">💊</span>
            <h3 className="font-semibold text-foreground">
              {language === 'ar' ? 'متوسط الفيتامينات' : 'Avg Daily Vitamins'}
            </h3>
          </div>
          <div className="flex items-center gap-1 text-sm text-primary">
            <TrendingUp size={14} />
            +15%
          </div>
        </div>

        <p className="text-4xl font-bold text-foreground mb-6">
          {avg}<span className="text-lg font-normal text-muted-foreground">%</span>
        </p>

        {/* Bar Chart */}
        <div className="flex items-end justify-between gap-2 h-32">
          {weeklyData.map((value, index) => (
            <div key={index} className="flex-1 flex flex-col items-center gap-2">
              <div className="w-full relative" style={{ height: '100px' }}>
                <div 
                  className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 rounded-full bg-vitamins transition-all duration-500"
                  style={{ 
                    height: `${(value / maxValue) * 100}%`,
                    opacity: index === weeklyData.length - 1 ? 1 : 0.6 
                  }}
                />
                <div 
                  className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 rounded-full bg-muted"
                  style={{ height: '100%', zIndex: -1 }}
                />
              </div>
              <span className="text-xs text-muted-foreground">{weekDays[index]}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Vitamins List */}
      <div className="bg-card rounded-2xl p-5 card-shadow">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-lg">💊</span>
          <h3 className="font-semibold text-foreground">
            {language === 'ar' ? 'الفيتامينات' : 'Vitamins'}
          </h3>
        </div>

        <div className="space-y-4">
          {vitaminsDetails.map((vitamin) => (
            <div key={vitamin.name}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium text-foreground">
                  {language === 'ar' ? vitamin.nameAr : vitamin.name}
                </span>
                <span className="text-sm text-muted-foreground">
                  {vitamin.value}% <span className="text-xs">({vitamin.amount})</span>
                </span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full ${vitamin.color}`}
                  style={{ width: `${vitamin.value}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const AminoContent = ({ language }: { language: string }) => {
  const avg = 78;
  const weeklyData = [65, 72, 68, 80, 85, 78, 75];
  const maxValue = Math.max(...weeklyData);

  return (
    <div className="space-y-4">
      {/* Chart */}
      <div className="bg-card rounded-2xl p-5 card-shadow">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-lg">🧬</span>
            <h3 className="font-semibold text-foreground">
              {language === 'ar' ? 'متوسط الأحماض الأمينية' : 'Avg Daily Amino Acids'}
            </h3>
          </div>
          <div className="flex items-center gap-1 text-sm text-primary">
            <TrendingUp size={14} />
            +8%
          </div>
        </div>

        <p className="text-4xl font-bold text-foreground mb-6">
          {avg}<span className="text-lg font-normal text-muted-foreground">%</span>
        </p>

        {/* Bar Chart */}
        <div className="flex items-end justify-between gap-2 h-32">
          {weeklyData.map((value, index) => (
            <div key={index} className="flex-1 flex flex-col items-center gap-2">
              <div className="w-full relative" style={{ height: '100px' }}>
                <div 
                  className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 rounded-full bg-amino transition-all duration-500"
                  style={{ 
                    height: `${(value / maxValue) * 100}%`,
                    opacity: index === weeklyData.length - 1 ? 1 : 0.6 
                  }}
                />
                <div 
                  className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 rounded-full bg-muted"
                  style={{ height: '100%', zIndex: -1 }}
                />
              </div>
              <span className="text-xs text-muted-foreground">{weekDays[index]}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Amino Acids List */}
      <div className="bg-card rounded-2xl p-5 card-shadow">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-lg">🧬</span>
          <h3 className="font-semibold text-foreground">
            {language === 'ar' ? 'الأحماض الأمينية' : 'Amino Acids'}
          </h3>
        </div>

        <div className="space-y-4">
          {aminoDetails.map((amino) => (
            <div key={amino.name}>
              <div className="flex items-center justify-between mb-1">
                <div>
                  <span className="text-sm font-medium text-foreground">{amino.name}</span>
                  <span className="text-xs text-muted-foreground block">{amino.desc}</span>
                </div>
                <span className="text-sm font-medium text-foreground">{amino.value}%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full ${amino.color}`}
                  style={{ width: `${amino.value}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const ComplianceContent = ({ language, data, complianceDays, t }: { language: string; data: number[]; complianceDays: number; t: (key: string) => string }) => {
  const compliantCount = data.filter(d => d === 1).length;

  return (
    <div className="space-y-4">
      {/* Summary Card */}
      <div className="bg-card rounded-2xl p-5 card-shadow">
        <div className="flex items-center gap-2 mb-4">
          <CheckCircle size={24} className="text-primary" />
          <h3 className="font-semibold text-foreground">
            {language === 'ar' ? 'أيام الالتزام' : 'Compliance Days'}
          </h3>
        </div>

        <div className="text-center mb-6">
          <p className="text-5xl font-bold text-primary">{complianceDays}</p>
          <p className="text-muted-foreground">{language === 'ar' ? 'يوم متتالي' : 'consecutive days'}</p>
        </div>

        {/* Week View */}
        <div className="flex justify-between gap-2">
          {weekDays.map((day, index) => (
            <div key={index} className="flex-1 flex flex-col items-center gap-2">
              <div 
                className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  data[index] === 1 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-muted text-muted-foreground'
                }`}
              >
                {data[index] === 1 ? '✓' : '✗'}
              </div>
              <span className="text-xs text-muted-foreground">{day}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-card rounded-2xl p-4 card-shadow text-center">
          <p className="text-3xl font-bold text-primary">{compliantCount}/7</p>
          <p className="text-sm text-muted-foreground">
            {language === 'ar' ? 'أيام هذا الأسبوع' : 'Days this week'}
          </p>
        </div>
        <div className="bg-card rounded-2xl p-4 card-shadow text-center">
          <p className="text-3xl font-bold text-foreground">{Math.round((compliantCount / 7) * 100)}%</p>
          <p className="text-sm text-muted-foreground">
            {language === 'ar' ? 'نسبة الالتزام' : 'Compliance rate'}
          </p>
        </div>
      </div>
    </div>
  );
};
