import { useState } from 'react';
import { Plus, Trash2, ChevronLeft, X, Minus, Check, Image as ImageIcon } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { Recipe } from '@/types/nutrition';

type RecipeTab = 'recipes' | 'products' | 'favorites';

export const RecipesPage = () => {
  const { language, recipes, addRecipe, removeRecipe, addMeal, favoriteProducts, removeFavorite, t } = useNutrition();
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [showAddRecipe, setShowAddRecipe] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<RecipeTab>('recipes');

  const handleAddToLog = () => {
    if (!selectedRecipe) return;

    addMeal({
      id: Date.now().toString(),
      name: selectedRecipe.name,
      nameAr: selectedRecipe.nameAr,
      image: selectedRecipe.image,
      calories: Math.round(selectedRecipe.calories * quantity),
      protein: Math.round(selectedRecipe.protein * quantity),
      carbs: Math.round(selectedRecipe.carbs * quantity),
      fat: Math.round(selectedRecipe.fat * quantity),
      vitamins: selectedRecipe.vitamins,
      minerals: selectedRecipe.minerals,
      aminoAcids: selectedRecipe.aminoAcids,
      quantity: 1,
      timestamp: new Date(),
      type: 'recipe',
      servingSize: selectedRecipe.servingSize,
      servingGrams: selectedRecipe.servingGrams,
    });

    setSelectedRecipe(null);
    setQuantity(1);
  };

  if (selectedRecipe) {
    return (
      <RecipeDetail 
        recipe={selectedRecipe} 
        language={language}
        quantity={quantity}
        setQuantity={setQuantity}
        onClose={() => {
          setSelectedRecipe(null);
          setQuantity(1);
        }}
        onAddToLog={handleAddToLog}
        t={t}
      />
    );
  }

  if (showAddRecipe) {
    return (
      <AddRecipeForm 
        language={language}
        onClose={() => setShowAddRecipe(false)}
        onAdd={(recipe) => {
          addRecipe(recipe);
          setShowAddRecipe(false);
        }}
        t={t}
      />
    );
  }

  return (
    <div className="pb-24 pt-8 px-4">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-foreground">
          {language === 'ar' ? 'الوصفات' : 'Recipes'}
        </h1>
        <button
          onClick={() => setShowAddRecipe(true)}
          className="bg-primary text-primary-foreground px-4 py-2 rounded-full font-semibold text-sm flex items-center gap-2 hover:opacity-90 transition-opacity"
        >
          <Plus size={18} />
          {language === 'ar' ? 'إضافة' : 'Add'}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto hide-scrollbar">
        <button
          onClick={() => setActiveTab('recipes')}
          className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
            activeTab === 'recipes'
              ? 'bg-foreground text-background'
              : 'bg-card text-foreground border border-border'
          }`}
        >
          {language === 'ar' ? 'الوصفات' : 'Recipes'}
        </button>
        <button
          onClick={() => setActiveTab('products')}
          className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
            activeTab === 'products'
              ? 'bg-foreground text-background'
              : 'bg-card text-foreground border border-border'
          }`}
        >
          {language === 'ar' ? 'المنتجات' : 'Products'}
        </button>
        <button
          onClick={() => setActiveTab('favorites')}
          className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
            activeTab === 'favorites'
              ? 'bg-foreground text-background'
              : 'bg-card text-foreground border border-border'
          }`}
        >
          {language === 'ar' ? 'المفضلة' : 'Favorites'}
        </button>
      </div>

      {activeTab === 'recipes' && (
        <div className="space-y-3">
          {recipes.map((recipe) => (
            <div
              key={recipe.id}
              className="bg-card rounded-2xl p-4 card-shadow flex items-center gap-4"
            >
              <button
                onClick={() => setSelectedRecipe(recipe)}
                className="flex-1 flex items-center gap-4 text-left"
              >
                <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center text-3xl flex-shrink-0">
                  {recipe.image || '🍽️'}
                </div>
                <div className="flex-1 min-w-0 overflow-hidden">
                  <h3 className="font-semibold text-foreground truncate">
                    {language === 'ar' ? recipe.nameAr || recipe.name : recipe.name}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-1">
                    {language === 'ar' 
                      ? recipe.ingredientsAr?.slice(0, 3).join(' • ') || recipe.ingredients.slice(0, 3).join(' • ')
                      : recipe.ingredients.slice(0, 3).join(' • ')}
                    {recipe.ingredients.length > 3 && '...'}
                  </p>
                  <div className="flex gap-3 mt-1 text-sm">
                    <span className="text-muted-foreground">{recipe.calories} kcal</span>
                    <span className="text-protein">{language === 'ar' ? 'بروتين' : 'P'} {recipe.protein}g</span>
                  </div>
                </div>
              </button>
              <button
                onClick={() => removeRecipe(recipe.id)}
                className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors flex-shrink-0"
              >
                <Trash2 size={20} />
              </button>
            </div>
          ))}

          {recipes.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <div className="text-4xl mb-4">📖</div>
              <p>{language === 'ar' ? 'لا توجد وصفات محفوظة' : 'No saved recipes'}</p>
              <p className="text-sm">{language === 'ar' ? 'أضف وصفتك الأولى!' : 'Add your first recipe!'}</p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'products' && (
        <div className="text-center py-12 text-muted-foreground">
          <div className="text-4xl mb-4">📊</div>
          <p>{language === 'ar' ? 'المنتجات الممسوحة بالباركود' : 'Barcode scanned products'}</p>
          <p className="text-sm">{language === 'ar' ? 'امسح منتجاً لإضافته هنا' : 'Scan a product to add it here'}</p>
        </div>
      )}

      {activeTab === 'favorites' && (
        <div className="space-y-3">
          {favoriteProducts.map((product) => (
            <div
              key={product.id}
              className="bg-card rounded-2xl p-4 card-shadow flex items-center gap-4"
            >
              <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center text-3xl flex-shrink-0">
                ❤️
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-foreground truncate">
                  {language === 'ar' ? product.nameAr || product.name : product.name}
                </h3>
                <div className="flex gap-3 mt-1 text-sm">
                  <span className="text-muted-foreground">{product.calories} kcal</span>
                  <span className="text-protein">P {product.protein}g</span>
                  <span className="text-carbs">C {product.carbs}g</span>
                </div>
              </div>
              <button
                onClick={() => removeFavorite(product.id)}
                className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors flex-shrink-0"
              >
                <Trash2 size={20} />
              </button>
            </div>
          ))}

          {favoriteProducts.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <div className="text-4xl mb-4">❤️</div>
              <p>{language === 'ar' ? 'لا توجد منتجات مفضلة' : 'No favorite products'}</p>
              <p className="text-sm">{language === 'ar' ? 'أضف منتجات للمفضلة عند المسح' : 'Add products to favorites when scanning'}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const RecipeDetail = ({ 
  recipe, 
  language, 
  quantity,
  setQuantity,
  onClose, 
  onAddToLog,
  t 
}: { 
  recipe: Recipe; 
  language: string;
  quantity: number;
  setQuantity: (q: number) => void;
  onClose: () => void;
  onAddToLog: () => void;
  t: (key: string) => string;
}) => {
  return (
    <div className="pb-24 pt-4">
      {/* Header */}
      <div className="flex items-center justify-between px-4 mb-4">
        <button onClick={onClose} className="p-2">
          <ChevronLeft size={24} className="text-foreground" />
        </button>
        <h2 className="font-semibold text-foreground">
          {language === 'ar' ? 'تفاصيل الوجبة' : 'Meal Details'}
        </h2>
        <div className="w-10" />
      </div>

      <div className="px-4 space-y-4">
        {/* Image */}
        <div className="bg-muted rounded-2xl h-48 flex items-center justify-center text-6xl">
          {recipe.image || '🍽️'}
        </div>

        {/* Name */}
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground">
            {language === 'ar' ? recipe.nameAr || recipe.name : recipe.name}
          </h1>
        </div>

        {/* Serving Size */}
        <div className="bg-card rounded-2xl p-4 card-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">{language === 'ar' ? 'حجم الحصة' : 'Serving Size'}</p>
              <p className="font-medium text-foreground">{recipe.servingSize || `${recipe.servingGrams}g`}</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setQuantity(Math.max(0.5, quantity - 0.5))}
                className="w-8 h-8 rounded-full bg-muted flex items-center justify-center"
              >
                <Minus size={16} className="text-foreground" />
              </button>
              <span className="text-lg font-bold w-8 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 0.5)}
                className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* Calories */}
        <div className="bg-card rounded-2xl p-6 card-shadow text-center">
          <p className="text-5xl font-bold text-foreground">{Math.round(recipe.calories * quantity)}</p>
          <p className="text-muted-foreground uppercase tracking-wide">CALORIES</p>
        </div>

        {/* Macros */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card rounded-2xl p-4 card-shadow text-center">
            <p className="text-2xl font-bold text-foreground">{Math.round(recipe.carbs * quantity)}g</p>
            <p className="text-sm text-muted-foreground">{language === 'ar' ? 'كارب' : 'Carbs'}</p>
            <div className="h-1 bg-carbs rounded-full mt-2" style={{ width: '45%' }} />
          </div>
          <div className="bg-card rounded-2xl p-4 card-shadow text-center">
            <p className="text-2xl font-bold text-foreground">{Math.round(recipe.protein * quantity)}g</p>
            <p className="text-sm text-muted-foreground">{language === 'ar' ? 'بروتين' : 'Protein'}</p>
            <div className="h-1 bg-protein rounded-full mt-2" style={{ width: '20%' }} />
          </div>
          <div className="bg-card rounded-2xl p-4 card-shadow text-center">
            <p className="text-2xl font-bold text-foreground">{Math.round(recipe.fat * quantity)}g</p>
            <p className="text-sm text-muted-foreground">{language === 'ar' ? 'دهون' : 'Fat'}</p>
            <div className="h-1 bg-fats rounded-full mt-2" style={{ width: '35%' }} />
          </div>
        </div>

        {/* Ingredients */}
        {recipe.ingredients && recipe.ingredients.length > 0 && (
          <div className="bg-card rounded-2xl p-4 card-shadow">
            <h3 className="font-semibold text-foreground mb-3">
              {language === 'ar' ? 'المكونات' : 'Ingredients'}
            </h3>
            <div className="space-y-2">
              {(language === 'ar' ? recipe.ingredientsAr || recipe.ingredients : recipe.ingredients).map((ingredient, index) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <span className="w-2 h-2 rounded-full bg-primary" />
                  <span className="text-foreground">{ingredient}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Dietary Insight */}
        <div className="bg-warning/10 rounded-2xl p-4 flex items-start gap-3">
          <span className="text-2xl">⭐</span>
          <div>
            <h4 className="font-semibold text-foreground">
              {language === 'ar' ? 'نصيحة غذائية' : 'Dietary Insight'}
            </h4>
            <p className="text-sm text-muted-foreground">
              {language === 'ar' 
                ? 'هذه الوجبة غنية بالبروتين والألياف، مما يجعلها خياراً رائعاً'
                : 'This meal is high in protein and fiber, making it a great choice'}
            </p>
          </div>
        </div>

        {/* Add Button */}
        <button
          onClick={onAddToLog}
          className="w-full bg-primary text-primary-foreground py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
        >
          <Plus size={20} />
          {language === 'ar' ? 'إضافة للسجل اليومي' : 'Add to Daily Log'}
        </button>
      </div>
    </div>
  );
};

const AddRecipeForm = ({ 
  language, 
  onClose, 
  onAdd,
  t 
}: { 
  language: string;
  onClose: () => void;
  onAdd: (recipe: Recipe) => void;
  t: (key: string) => string;
}) => {
  const [name, setName] = useState('');
  const [nameAr, setNameAr] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [calories, setCalories] = useState('');
  const [protein, setProtein] = useState('');
  const [carbs, setCarbs] = useState('');
  const [fat, setFat] = useState('');
  const [image, setImage] = useState('🍽️');

  const emojiOptions = ['🍽️', '🥗', '🍚', '🍗', '🥩', '🍳', '🥣', '🥛', '🐟', '🥑', '🍕', '🍔'];

  const handleSubmit = () => {
    if (!name || !calories) return;

    const recipe: Recipe = {
      id: Date.now().toString(),
      name,
      nameAr: nameAr || undefined,
      image,
      ingredients: ingredients.split(',').map(i => i.trim()).filter(Boolean),
      calories: parseInt(calories) || 0,
      protein: parseInt(protein) || 0,
      carbs: parseInt(carbs) || 0,
      fat: parseInt(fat) || 0,
      servingSize: '1 serving',
      servingGrams: 100,
    };

    onAdd(recipe);
  };

  return (
    <div className="pb-24 pt-4">
      {/* Header */}
      <div className="flex items-center justify-between px-4 mb-6">
        <button onClick={onClose} className="p-2">
          <X size={24} className="text-foreground" />
        </button>
        <h2 className="font-semibold text-foreground">
          {language === 'ar' ? 'إضافة وصفة جديدة' : 'Add New Recipe'}
        </h2>
        <div className="w-10" />
      </div>

      <div className="px-4 space-y-4">
        {/* Emoji Picker */}
        <div>
          <label className="text-sm text-muted-foreground block mb-2">
            {language === 'ar' ? 'اختر أيقونة' : 'Choose Icon'}
          </label>
          <div className="flex flex-wrap gap-2">
            {emojiOptions.map((emoji) => (
              <button
                key={emoji}
                onClick={() => setImage(emoji)}
                className={`w-12 h-12 rounded-xl text-2xl flex items-center justify-center transition-all ${
                  image === emoji ? 'bg-primary/20 ring-2 ring-primary' : 'bg-muted'
                }`}
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>

        {/* Name */}
        <div>
          <label className="text-sm text-muted-foreground block mb-2">
            {language === 'ar' ? 'اسم الوصفة (إنجليزي)' : 'Recipe Name (English)'}
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={language === 'ar' ? 'مثال: Grilled Chicken' : 'e.g., Grilled Chicken'}
            className="w-full bg-muted border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground"
          />
        </div>

        {/* Arabic Name */}
        <div>
          <label className="text-sm text-muted-foreground block mb-2">
            {language === 'ar' ? 'اسم الوصفة (عربي)' : 'Recipe Name (Arabic)'}
          </label>
          <input
            type="text"
            value={nameAr}
            onChange={(e) => setNameAr(e.target.value)}
            placeholder={language === 'ar' ? 'مثال: دجاج مشوي' : 'e.g., دجاج مشوي'}
            className="w-full bg-muted border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground"
          />
        </div>

        {/* Ingredients */}
        <div>
          <label className="text-sm text-muted-foreground block mb-2">
            {language === 'ar' ? 'المكونات (مفصولة بفاصلة)' : 'Ingredients (comma separated)'}
          </label>
          <input
            type="text"
            value={ingredients}
            onChange={(e) => setIngredients(e.target.value)}
            placeholder={language === 'ar' ? 'دجاج, زيت زيتون, ثوم' : 'chicken, olive oil, garlic'}
            className="w-full bg-muted border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground"
          />
        </div>

        {/* Nutrition */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm text-muted-foreground block mb-2">
              {language === 'ar' ? 'السعرات' : 'Calories'}
            </label>
            <input
              type="number"
              value={calories}
              onChange={(e) => setCalories(e.target.value)}
              placeholder="350"
              className="w-full bg-muted border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground block mb-2">
              {language === 'ar' ? 'البروتين (جرام)' : 'Protein (g)'}
            </label>
            <input
              type="number"
              value={protein}
              onChange={(e) => setProtein(e.target.value)}
              placeholder="30"
              className="w-full bg-muted border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground block mb-2">
              {language === 'ar' ? 'الكربوهيدرات (جرام)' : 'Carbs (g)'}
            </label>
            <input
              type="number"
              value={carbs}
              onChange={(e) => setCarbs(e.target.value)}
              placeholder="25"
              className="w-full bg-muted border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground block mb-2">
              {language === 'ar' ? 'الدهون (جرام)' : 'Fat (g)'}
            </label>
            <input
              type="number"
              value={fat}
              onChange={(e) => setFat(e.target.value)}
              placeholder="15"
              className="w-full bg-muted border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground"
            />
          </div>
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={!name || !calories}
          className="w-full bg-primary text-primary-foreground py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          <Check size={20} />
          {language === 'ar' ? 'حفظ الوصفة' : 'Save Recipe'}
        </button>
      </div>
    </div>
  );
};
