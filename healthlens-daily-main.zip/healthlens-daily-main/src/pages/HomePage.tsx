import { useState } from 'react';
import { Header } from '@/components/Header';
import { StepsCard } from '@/components/home/StepsCard';
import { HealthyFoodLevel } from '@/components/home/HealthyFoodLevel';
import { DailyNutrients } from '@/components/home/DailyNutrients';
import { WaterTracker } from '@/components/home/WaterTracker';
import { MacrosOverview } from '@/components/home/MacrosOverview';
import { RecentHistory } from '@/components/home/RecentHistory';
import { ActionButtons } from '@/components/home/ActionButtons';
import { FastingTimer } from '@/components/home/FastingTimer';
import { BreathingExercise } from '@/components/home/BreathingExercise';
import { SugarSaltTracker } from '@/components/home/SugarSaltTracker';
import { CameraScanner } from '@/components/scan/CameraScanner';
import { ManualMealEntry } from '@/components/scan/ManualMealEntry';
import { useNutrition } from '@/contexts/NutritionContext';
import { Meal } from '@/types/nutrition';

export const HomePage = () => {
  const { addMeal, setActiveTab } = useNutrition();
  const [showCamera, setShowCamera] = useState(false);
  const [showManualEntry, setShowManualEntry] = useState(false);

  const handleScanClick = () => {
    setActiveTab('scan');
  };

  const handleManualClick = () => {
    setShowManualEntry(true);
  };

  const handleMealAdded = (meal: Meal) => {
    addMeal(meal);
    setShowCamera(false);
    setShowManualEntry(false);
  };

  return (
    <div className="pb-24 pt-4">
      <Header />
      
      <div className="px-4 space-y-4">
        <StepsCard />
        <HealthyFoodLevel />
        <DailyNutrients />
        <SugarSaltTracker />
        <WaterTracker />
        <MacrosOverview />
        <BreathingExercise />
        <FastingTimer />
        <RecentHistory />
        <ActionButtons 
          onScanClick={handleScanClick} 
          onAddManualClick={handleManualClick}
        />
      </div>

      {showCamera && (
        <CameraScanner 
          onClose={() => setShowCamera(false)}
          onMealScanned={handleMealAdded}
        />
      )}

      {showManualEntry && (
        <ManualMealEntry 
          onClose={() => setShowManualEntry(false)}
          onMealAdded={handleMealAdded}
        />
      )}
    </div>
  );
};
