import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';
import { UserProfile } from '@/types/nutrition';

interface SugarLimitSettingsProps {
  language: string;
  profile: UserProfile;
  updateProfile: (updates: Partial<UserProfile>) => void;
  defaultLimit: number;
}

export const SugarLimitSettings = ({ 
  language, 
  profile, 
  updateProfile,
  defaultLimit 
}: SugarLimitSettingsProps) => {
  const [unit, setUnit] = useState<'g' | 'tsp'>('g');
  const currentLimit = profile.dailySugarLimit || defaultLimit;
  
  // 1 tsp = 4g
  const displayValue = unit === 'tsp' ? Math.round(currentLimit / 4) : currentLimit;

  const handleIncrease = () => {
    const increment = unit === 'tsp' ? 4 : 1;
    updateProfile({ dailySugarLimit: currentLimit + increment });
  };

  const handleDecrease = () => {
    const decrement = unit === 'tsp' ? 4 : 1;
    const newValue = Math.max(unit === 'tsp' ? 4 : 1, currentLimit - decrement);
    updateProfile({ dailySugarLimit: newValue });
  };

  return (
    <div className="bg-card rounded-2xl p-4 card-shadow mb-4">
      <div className="flex items-center gap-2 mb-3">
        <span className="text-xl">🍬</span>
        <span className="font-medium text-foreground">
          {language === 'ar' ? 'حد السكر اليومي' : 'Daily Sugar Limit'}
        </span>
      </div>

      {/* Visual Guide */}
      <div className="bg-muted rounded-xl p-3 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-background rounded-xl flex items-center justify-center">
              <span className="text-2xl">🥄</span>
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">
                {language === 'ar' ? '1 ملعقة صغيرة' : '1 teaspoon'}
              </p>
              <p className="text-xs text-muted-foreground">= 4g</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-background rounded-lg flex items-center justify-center">
              <span className="text-sm">4g</span>
            </div>
            <span className="text-xs text-muted-foreground">≈</span>
            <div className="flex gap-0.5">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="w-2 h-2 rounded-full bg-primary/60" />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Unit Toggle */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setUnit('g')}
          className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-colors ${
            unit === 'g' ? 'bg-foreground text-background' : 'bg-muted text-foreground'
          }`}
        >
          {language === 'ar' ? 'جرام (g)' : 'Grams (g)'}
        </button>
        <button
          onClick={() => setUnit('tsp')}
          className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-colors ${
            unit === 'tsp' ? 'bg-foreground text-background' : 'bg-muted text-foreground'
          }`}
        >
          {language === 'ar' ? 'ملعقة صغيرة (tsp)' : 'Teaspoons (tsp)'}
        </button>
      </div>

      {/* Limit Control */}
      <div className="flex items-center justify-between">
        <button
          onClick={handleDecrease}
          className="w-10 h-10 rounded-full bg-muted flex items-center justify-center"
        >
          <Minus size={18} className="text-foreground" />
        </button>
        
        <div className="text-center">
          <p className="text-3xl font-bold text-foreground">
            {displayValue}
            <span className="text-lg font-normal text-muted-foreground ms-1">
              {unit}
            </span>
          </p>
          {unit === 'tsp' && (
            <p className="text-xs text-muted-foreground">= {currentLimit}g</p>
          )}
        </div>
        
        <button
          onClick={handleIncrease}
          className="w-10 h-10 rounded-full bg-primary flex items-center justify-center"
        >
          <Plus size={18} className="text-primary-foreground" />
        </button>
      </div>

      <p className="text-xs text-muted-foreground text-center mt-3">
        {language === 'ar' 
          ? `الحد الموصى به (WHO): ${defaultLimit}g يومياً` 
          : `WHO recommended: ${defaultLimit}g daily`}
      </p>
    </div>
  );
};
