import { useState } from 'react';
import { FileDown, Loader2 } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { jsPDF } from 'jspdf';

interface PDFReportProps {
  period: 'week' | 'month';
}

export const PDFReport = ({ period }: PDFReportProps) => {
  const { language, meals, dailyTotals, fastingSession, complianceDays, waterIntake, steps, profile } = useNutrition();
  const [isGenerating, setIsGenerating] = useState(false);

  const generatePDF = async () => {
    setIsGenerating(true);
    
    try {
      const doc = new jsPDF();
      const isArabic = language === 'ar';
      
      // Title
      doc.setFontSize(22);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(34, 197, 94); // Primary green
      doc.text('NutriTrack Report', 105, 20, { align: 'center' });

      // Period Badge
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 100, 100);
      const periodText = period === 'week' ? 'Weekly Report' : 'Monthly Report';
      doc.text(periodText, 105, 30, { align: 'center' });

      // Date
      doc.setFontSize(10);
      doc.text(new Date().toLocaleDateString(), 105, 38, { align: 'center' });

      // Divider
      doc.setDrawColor(200, 200, 200);
      doc.setLineWidth(0.5);
      doc.line(20, 45, 190, 45);

      // Get period data
      const daysInPeriod = period === 'week' ? 7 : 30;
      const now = new Date();
      const periodStart = new Date(now.getTime() - daysInPeriod * 24 * 60 * 60 * 1000);
      const periodMeals = meals.filter(m => new Date(m.timestamp) >= periodStart);

      // Calculate totals
      const totals = periodMeals.reduce((acc, meal) => ({
        calories: acc.calories + (meal.calories * meal.quantity),
        protein: acc.protein + (meal.protein * meal.quantity),
        carbs: acc.carbs + (meal.carbs * meal.quantity),
        fat: acc.fat + (meal.fat * meal.quantity),
        sugar: acc.sugar + ((meal.sugar || 0) * meal.quantity),
        salt: acc.salt + ((meal.salt || 0) * meal.quantity),
      }), { calories: 0, protein: 0, carbs: 0, fat: 0, sugar: 0, salt: 0 });

      // Calculate daily averages
      const avgCalories = Math.round(totals.calories / daysInPeriod);
      const avgProtein = Math.round(totals.protein / daysInPeriod);
      const avgCarbs = Math.round(totals.carbs / daysInPeriod);
      const avgFat = Math.round(totals.fat / daysInPeriod);
      const avgSugar = Math.round(totals.sugar / daysInPeriod);
      const avgSalt = parseFloat((totals.salt / daysInPeriod).toFixed(1));

      let y = 55;
      const lineHeight = 8;

      // Summary Section Header
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(0, 0, 0);
      doc.text('📊 Nutritional Summary', 20, y); y += lineHeight + 2;

      doc.setFontSize(11);
      doc.setFont('helvetica', 'normal');
      
      // Calories
      doc.setTextColor(0, 0, 0);
      doc.text(`Average Daily Calories: ${avgCalories} kcal`, 25, y); y += lineHeight;

      // Protein - check against goal
      const proteinGoal = profile.weight * 1.2;
      if (avgProtein < proteinGoal * 0.8) {
        doc.setTextColor(220, 38, 38); // Red for low
        doc.text(`⚠ Protein: ${avgProtein}g (below target ${Math.round(proteinGoal)}g)`, 25, y);
      } else {
        doc.setTextColor(34, 197, 94); // Green for good
        doc.text(`✓ Protein: ${avgProtein}g (target: ${Math.round(proteinGoal)}g)`, 25, y);
      }
      y += lineHeight;

      // Carbs
      doc.setTextColor(0, 0, 0);
      doc.text(`Average Daily Carbs: ${avgCarbs}g`, 25, y); y += lineHeight;
      doc.text(`Average Daily Fat: ${avgFat}g`, 25, y); y += lineHeight;

      // Sugar with warning
      const sugarLimit = profile.dailySugarLimit || 25;
      if (avgSugar > sugarLimit) {
        doc.setTextColor(220, 38, 38);
        doc.text(`⚠ Sugar: ${avgSugar}g (EXCEEDS limit of ${sugarLimit}g!)`, 25, y);
      } else {
        doc.setTextColor(34, 197, 94);
        doc.text(`✓ Sugar: ${avgSugar}g (limit: ${sugarLimit}g)`, 25, y);
      }
      y += lineHeight;

      // Salt with warning
      const saltLimit = profile.dailySaltLimit || 5;
      if (avgSalt > saltLimit) {
        doc.setTextColor(220, 38, 38);
        doc.text(`⚠ Salt: ${avgSalt}g (EXCEEDS limit of ${saltLimit}g!)`, 25, y);
      } else {
        doc.setTextColor(34, 197, 94);
        doc.text(`✓ Salt: ${avgSalt}g (limit: ${saltLimit}g)`, 25, y);
      }
      y += lineHeight * 2;

      // Hydration Section
      doc.setTextColor(0, 0, 0);
      doc.setFont('helvetica', 'bold');
      doc.text('💧 Hydration', 20, y); y += lineHeight;
      doc.setFont('helvetica', 'normal');
      
      const waterGoal = profile.dailyWaterGoal || 2500;
      if (waterIntake < waterGoal * 0.8) {
        doc.setTextColor(234, 179, 8); // Warning yellow
        doc.text(`⚠ Today's Water: ${waterIntake}ml (below ${waterGoal}ml goal)`, 25, y);
      } else {
        doc.setTextColor(34, 197, 94);
        doc.text(`✓ Today's Water: ${waterIntake}ml (goal: ${waterGoal}ml)`, 25, y);
      }
      y += lineHeight * 2;

      // Activity Section
      doc.setTextColor(0, 0, 0);
      doc.setFont('helvetica', 'bold');
      doc.text('🏃 Activity', 20, y); y += lineHeight;
      doc.setFont('helvetica', 'normal');
      
      const stepsGoal = 10000;
      if (steps < stepsGoal * 0.6) {
        doc.setTextColor(234, 179, 8);
        doc.text(`⚠ Today's Steps: ${steps.toLocaleString()} (below ${stepsGoal.toLocaleString()} goal)`, 25, y);
      } else {
        doc.setTextColor(34, 197, 94);
        doc.text(`✓ Today's Steps: ${steps.toLocaleString()}`, 25, y);
      }
      y += lineHeight;
      doc.setTextColor(0, 0, 0);
      doc.text(`Calories Burned: ~${Math.round(steps * 0.04)} kcal`, 25, y); y += lineHeight * 2;

      // Fasting Section
      if (fastingSession) {
        doc.setFont('helvetica', 'bold');
        doc.text('⏱️ Fasting', 20, y); y += lineHeight;
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(34, 197, 94);
        doc.text(`Target: ${fastingSession.duration} hours | Status: Active`, 25, y); y += lineHeight * 2;
      }

      // Compliance Section
      doc.setTextColor(0, 0, 0);
      doc.setFont('helvetica', 'bold');
      doc.text('✅ Compliance', 20, y); y += lineHeight;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(34, 197, 94);
      doc.text(`Consecutive Days: ${complianceDays}`, 25, y); y += lineHeight * 2;

      // Health Indicators
      doc.setTextColor(0, 0, 0);
      doc.setFont('helvetica', 'bold');
      doc.text('📈 Health Indicators', 20, y); y += lineHeight;
      doc.setFont('helvetica', 'normal');
      
      const bmi = profile.weight / ((profile.height / 100) ** 2);
      const bmiStatus = bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Normal' : bmi < 30 ? 'Overweight' : 'Obese';
      
      if (bmi >= 18.5 && bmi < 25) {
        doc.setTextColor(34, 197, 94);
        doc.text(`✓ BMI: ${bmi.toFixed(1)} (${bmiStatus})`, 25, y);
      } else {
        doc.setTextColor(234, 179, 8);
        doc.text(`⚠ BMI: ${bmi.toFixed(1)} (${bmiStatus})`, 25, y);
      }
      y += lineHeight * 2;

      // Warnings Summary Box
      if (avgSugar > sugarLimit || avgSalt > saltLimit || waterIntake < waterGoal * 0.8 || steps < stepsGoal * 0.6) {
        doc.setFillColor(254, 226, 226);
        doc.roundedRect(20, y, 170, 30, 3, 3, 'F');
        doc.setTextColor(185, 28, 28);
        doc.setFont('helvetica', 'bold');
        doc.text('⚠ Areas Needing Attention:', 25, y + 8);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        
        let warningY = y + 16;
        if (avgSugar > sugarLimit) {
          doc.text('• Reduce sugar intake', 30, warningY); warningY += 6;
        }
        if (avgSalt > saltLimit) {
          doc.text('• Reduce salt intake', 30, warningY); warningY += 6;
        }
        if (waterIntake < waterGoal * 0.8) {
          doc.text('• Drink more water', 30, warningY); warningY += 6;
        }
        if (steps < stepsGoal * 0.6) {
          doc.text('• Increase daily activity', 30, warningY);
        }
      }

      // Footer
      doc.setFontSize(8);
      doc.setTextColor(150, 150, 150);
      doc.text('Generated by NutriTrack', 105, 285, { align: 'center' });

      // Download
      const fileName = `nutritrack-${period}-report-${new Date().toISOString().split('T')[0]}.pdf`;
      doc.save(fileName);
    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <button
      onClick={generatePDF}
      disabled={isGenerating}
      className="flex-1 flex items-center justify-center gap-2 bg-primary text-primary-foreground px-4 py-3 rounded-xl font-medium text-sm hover:opacity-90 transition-opacity disabled:opacity-50"
    >
      {isGenerating ? (
        <Loader2 size={16} className="animate-spin" />
      ) : (
        <FileDown size={16} />
      )}
      {period === 'week' 
        ? (language === 'ar' ? 'PDF أسبوعي' : 'Week PDF')
        : (language === 'ar' ? 'PDF شهري' : 'Month PDF')
      }
    </button>
  );
};
