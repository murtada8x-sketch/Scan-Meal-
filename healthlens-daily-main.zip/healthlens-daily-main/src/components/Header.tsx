import { Bell, Info } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';

export const Header = () => {
  const { profile, language } = useNutrition();

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (language === 'ar') {
      if (hour < 12) return 'صباح الخير';
      if (hour < 18) return 'مساء الخير';
      return 'مساء الخير';
    }
    if (hour < 12) return 'Good Morning';
    if (hour < 18) return 'Good Afternoon';
    return 'Good Evening';
  };

  return (
    <header className="flex items-center justify-between px-4 py-4">
      <div>
        <p className="text-muted-foreground text-sm">{getGreeting()},</p>
        <h1 className="text-xl font-bold text-foreground">{profile.name}</h1>
      </div>
      <div className="flex items-center gap-2">
        <button className="w-10 h-10 rounded-full bg-card flex items-center justify-center border border-border hover:bg-muted transition-colors">
          <Info size={20} className="text-muted-foreground" />
        </button>
        <button className="w-10 h-10 rounded-full bg-card flex items-center justify-center border border-border hover:bg-muted transition-colors relative">
          <Bell size={20} className="text-muted-foreground" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-destructive rounded-full"></span>
        </button>
      </div>
    </header>
  );
};
