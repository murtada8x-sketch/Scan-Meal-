import { Home, BarChart2, Camera, BookOpen, Settings } from 'lucide-react';
import { TabType } from '@/types/nutrition';
import { useNutrition } from '@/contexts/NutritionContext';

const tabs: { id: TabType; icon: typeof Home; label: string; labelAr: string }[] = [
  { id: 'home', icon: Home, label: 'Home', labelAr: 'الرئيسية' },
  { id: 'reports', icon: BarChart2, label: 'Reports', labelAr: 'التقارير' },
  { id: 'scan', icon: Camera, label: 'Scan', labelAr: 'مسح' },
  { id: 'recipes', icon: BookOpen, label: 'Recipes', labelAr: 'الوصفات' },
  { id: 'profile', icon: Settings, label: 'Profile', labelAr: 'حسابي' },
];

export const BottomNavigation = () => {
  const { activeTab, setActiveTab, language } = useNutrition();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border safe-bottom z-50">
      <div className="flex items-center justify-around h-16 max-w-md mx-auto px-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center flex-1 py-2 transition-colors ${
                isActive
                  ? 'text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon size={22} strokeWidth={isActive ? 2.5 : 2} />
              <span className={`text-xs mt-1 font-medium ${isActive ? 'text-primary' : ''}`}>
                {language === 'ar' ? tab.labelAr : tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
