import { useState } from 'react';
import { Plus, Minus, X } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';

export const SugarSaltTracker = () => {
  const { t, language, dailyTotals, profile, addMeal } = useNutrition();
  const [showSugarAdd, setShowSugarAdd] = useState(false);
  const [sugarAmount, setSugarAmount] = useState(4);
  const [sugarUnit, setSugarUnit] = useState<'g' | 'tsp'>('g');
  
  // Calculate limits based on age (WHO recommendations)
  const getSugarLimit = (age: number) => {
    if (age < 18) return 20; // Children: 20g
    if (age > 65) return 20; // Elderly: 20g
    return 25; // Adults: 25g
  };
  
  const getSaltLimit = (age: number) => {
    if (age < 18) return 4; // Children: 4g
    if (age > 65) return 4; // Elderly: 4g
    return 5; // Adults: 5g
  };
  
  const sugarLimit = profile.dailySugarLimit || getSugarLimit(profile.age);
  const saltLimit = profile.dailySaltLimit || getSaltLimit(profile.age);
  
  const sugarProgress = Math.min((dailyTotals.sugar / sugarLimit) * 100, 150);
  const saltProgress = Math.min((dailyTotals.salt / saltLimit) * 100, 150);
  
  const getSugarColor = () => {
    if (sugarProgress > 100) return 'bg-destructive';
    if (sugarProgress > 75) return 'bg-warning';
    return 'bg-primary';
  };
  
  const getSaltColor = () => {
    if (saltProgress > 100) return 'bg-destructive';
    if (saltProgress > 75) return 'bg-warning';
    return 'bg-primary';
  };

  // Convert teaspoons to grams (1 tsp = 4g sugar)
  const getSugarInGrams = () => {
    return sugarUnit === 'tsp' ? sugarAmount * 4 : sugarAmount;
  };

  const handleAddSugar = () => {
    const grams = getSugarInGrams();
    addMeal({
      id: Date.now().toString(),
      name: language === 'ar' ? 'سكر مضاف' : 'Added Sugar',
      nameAr: 'سكر مضاف',
      calories: grams * 4,
      protein: 0,
      carbs: grams,
      fat: 0,
      sugar: grams,
      quantity: 1,
      timestamp: new Date(),
      type: 'manual',
    });
    setShowSugarAdd(false);
    setSugarAmount(4);
  };

  return (
    <div className="bg-card rounded-2xl p-4 card-shadow animate-fade-in">
      <div className="space-y-4">
        {/* Sugar */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-lg">🍬</span>
              <span className="font-medium text-foreground text-sm">
                {language === 'ar' ? 'السكر' : 'Sugar'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-sm font-semibold ${sugarProgress > 100 ? 'text-destructive' : 'text-foreground'}`}>
                {dailyTotals.sugar.toFixed(1)}g / {sugarLimit}g
              </span>
              <button
                onClick={() => setShowSugarAdd(true)}
                className="w-6 h-6 rounded-full bg-primary flex items-center justify-center"
              >
                <Plus size={14} className="text-primary-foreground" />
              </button>
            </div>
          </div>
          <div className="h-2.5 bg-muted rounded-full overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${getSugarColor()}`}
              style={{ width: `${Math.min(sugarProgress, 100)}%` }}
            />
          </div>
          {sugarProgress > 100 && (
            <p className="text-xs text-destructive mt-1 flex items-center gap-1">
              ⚠️ {t('highSugar')}
            </p>
          )}
        </div>
        
        {/* Salt */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-lg">🧂</span>
              <span className="font-medium text-foreground text-sm">
                {language === 'ar' ? 'الملح' : 'Salt'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-sm font-semibold ${saltProgress > 100 ? 'text-destructive' : 'text-foreground'}`}>
                {dailyTotals.salt.toFixed(1)}g / {saltLimit}g
              </span>
            </div>
          </div>
          <div className="h-2.5 bg-muted rounded-full overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${getSaltColor()}`}
              style={{ width: `${Math.min(saltProgress, 100)}%` }}
            />
          </div>
          {saltProgress > 100 && (
            <p className="text-xs text-destructive mt-1 flex items-center gap-1">
              ⚠️ {t('highSalt')}
            </p>
          )}
        </div>
        
        <p className="text-xs text-muted-foreground text-center">
          {t('measurementTip')}
        </p>
      </div>

      {/* Sugar Add Modal */}
      {showSugarAdd && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-2xl p-6 w-full max-w-sm card-shadow">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">
                {language === 'ar' ? 'إضافة سكر' : 'Add Sugar'}
              </h3>
              <button onClick={() => setShowSugarAdd(false)}>
                <X size={20} className="text-muted-foreground" />
              </button>
            </div>

            {/* Visual Guide */}
            <div className="bg-muted rounded-xl p-3 mb-4">
              <div className="flex items-center gap-3">
                <div className="text-3xl">🥄</div>
                <div>
                  <p className="text-sm font-medium text-foreground">
                    {language === 'ar' ? '1 ملعقة صغيرة = 4 جرام' : '1 teaspoon = 4 grams'}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {language === 'ar' ? 'للتقدير البصري' : 'For visual estimation'}
                  </p>
                </div>
              </div>
            </div>

            {/* Unit Toggle */}
            <div className="flex gap-2 mb-4">
              <button
                onClick={() => setSugarUnit('g')}
                className={`flex-1 py-2 rounded-xl text-sm font-medium transition-colors ${
                  sugarUnit === 'g' ? 'bg-foreground text-background' : 'bg-muted text-foreground'
                }`}
              >
                {language === 'ar' ? 'جرام (g)' : 'Grams (g)'}
              </button>
              <button
                onClick={() => setSugarUnit('tsp')}
                className={`flex-1 py-2 rounded-xl text-sm font-medium transition-colors ${
                  sugarUnit === 'tsp' ? 'bg-foreground text-background' : 'bg-muted text-foreground'
                }`}
              >
                {language === 'ar' ? 'ملعقة صغيرة' : 'Teaspoon'}
              </button>
            </div>

            {/* Amount Control */}
            <div className="flex items-center justify-center gap-4 mb-4">
              <button
                onClick={() => setSugarAmount(Math.max(1, sugarAmount - 1))}
                className="w-10 h-10 rounded-full bg-muted flex items-center justify-center"
              >
                <Minus size={18} className="text-foreground" />
              </button>
              <div className="text-center">
                <span className="text-4xl font-bold text-foreground">{sugarAmount}</span>
                <span className="text-lg text-muted-foreground ms-1">
                  {sugarUnit === 'g' ? 'g' : 'tsp'}
                </span>
                {sugarUnit === 'tsp' && (
                  <p className="text-xs text-muted-foreground mt-1">
                    = {sugarAmount * 4}g
                  </p>
                )}
              </div>
              <button
                onClick={() => setSugarAmount(sugarAmount + 1)}
                className="w-10 h-10 rounded-full bg-primary flex items-center justify-center"
              >
                <Plus size={18} className="text-primary-foreground" />
              </button>
            </div>

            <button
              onClick={handleAddSugar}
              className="w-full bg-primary text-primary-foreground py-3 rounded-xl font-semibold"
            >
              {language === 'ar' ? 'إضافة' : 'Add'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
