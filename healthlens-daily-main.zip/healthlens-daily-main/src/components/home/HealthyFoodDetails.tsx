import { X, AlertTriangle, TrendingDown } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';

interface HealthyFoodDetailsProps {
  onClose: () => void;
}

export const HealthyFoodDetails = ({ onClose }: HealthyFoodDetailsProps) => {
  const { language, meals, t } = useNutrition();

  // Get today's meals and calculate which ones hurt health
  const today = new Date().toDateString();
  const todayMeals = meals.filter(m => new Date(m.timestamp).toDateString() === today);

  // Calculate health impact for each meal
  const mealsWithImpact = todayMeals.map(meal => {
    let negativeImpact = 0;
    const reasons: string[] = [];

    // High sugar (>10g per 100g is high)
    if (meal.sugar && meal.sugar > 10) {
      negativeImpact += meal.sugar * 2;
      reasons.push(language === 'ar' ? `سكر عالي: ${meal.sugar}g` : `High sugar: ${meal.sugar}g`);
    }

    // High saturated fat (>5g is high)
    if (meal.fat > 15) {
      negativeImpact += meal.fat * 1.5;
      reasons.push(language === 'ar' ? `دهون عالية: ${meal.fat}g` : `High fat: ${meal.fat}g`);
    }

    // High salt (>1.5g is high)
    if (meal.salt && meal.salt > 1.5) {
      negativeImpact += meal.salt * 10;
      reasons.push(language === 'ar' ? `ملح عالي: ${meal.salt}g` : `High salt: ${meal.salt}g`);
    }

    // Low protein ratio (protein should be meaningful)
    if (meal.protein < 5 && meal.calories > 200) {
      negativeImpact += 5;
      reasons.push(language === 'ar' ? 'بروتين منخفض' : 'Low protein');
    }

    // High carbs with low fiber indicators
    if (meal.carbs > 50) {
      negativeImpact += meal.carbs * 0.5;
      reasons.push(language === 'ar' ? `كربوهيدرات عالية: ${meal.carbs}g` : `High carbs: ${meal.carbs}g`);
    }

    return {
      ...meal,
      negativeImpact,
      reasons,
    };
  });

  // Filter and sort by negative impact
  const harmfulMeals = mealsWithImpact
    .filter(m => m.negativeImpact > 0)
    .sort((a, b) => b.negativeImpact - a.negativeImpact);

  // Remove duplicates by name
  const uniqueHarmfulMeals = harmfulMeals.filter(
    (meal, index, self) => index === self.findIndex(m => m.name === meal.name)
  );

  return (
    <div className="fixed inset-0 bg-background z-50 safe-top safe-bottom overflow-auto">
      <div className="flex items-center justify-between p-4 border-b border-border sticky top-0 bg-background z-10">
        <button onClick={onClose} className="p-2">
          <X size={24} className="text-foreground" />
        </button>
        <h2 className="font-semibold text-foreground">
          {language === 'ar' ? 'تفاصيل الأطعمة الضارة' : 'Harmful Foods Details'}
        </h2>
        <div className="w-10" />
      </div>

      <div className="p-4 space-y-4">
        {/* Explanation Card */}
        <div className="bg-warning/10 rounded-2xl p-4 border border-warning/20">
          <div className="flex items-start gap-3">
            <AlertTriangle className="text-warning flex-shrink-0 mt-1" size={20} />
            <div>
              <p className="font-medium text-foreground">
                {language === 'ar' ? 'الأطعمة التي خفضت مؤشرك الصحي' : 'Foods that lowered your health score'}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                {language === 'ar' 
                  ? 'هذه الأطعمة تحتوي على نسب عالية من السكر أو الدهون أو الملح'
                  : 'These foods contain high amounts of sugar, fat, or salt'}
              </p>
            </div>
          </div>
        </div>

        {uniqueHarmfulMeals.length === 0 ? (
          <div className="bg-card rounded-2xl p-8 text-center card-shadow">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <span className="text-3xl">🎉</span>
            </div>
            <p className="font-semibold text-foreground">
              {language === 'ar' ? 'ممتاز!' : 'Excellent!'}
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              {language === 'ar' 
                ? 'لم يتم تسجيل أي أطعمة ضارة اليوم'
                : 'No harmful foods logged today'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {uniqueHarmfulMeals.map((meal, index) => (
              <div 
                key={meal.id} 
                className="bg-card rounded-2xl p-4 card-shadow border-l-4 border-destructive"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center">
                      <TrendingDown className="text-destructive" size={20} />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{meal.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {meal.calories} kcal • {meal.quantity * 100}g
                      </p>
                    </div>
                  </div>
                  <span className="text-xs bg-destructive/10 text-destructive px-2 py-1 rounded-full">
                    -{Math.round(meal.negativeImpact)}
                  </span>
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  {meal.reasons.map((reason, i) => (
                    <span 
                      key={i}
                      className="text-xs bg-warning/10 text-warning px-2 py-1 rounded-full"
                    >
                      {reason}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tips */}
        <div className="bg-card rounded-2xl p-4 card-shadow mt-6">
          <h3 className="font-semibold text-foreground mb-3">
            {language === 'ar' ? 'نصائح لتحسين صحتك' : 'Tips to improve your health'}
          </h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              {language === 'ar' 
                ? 'استبدل المشروبات السكرية بالماء أو الشاي غير المحلى'
                : 'Replace sugary drinks with water or unsweetened tea'}
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              {language === 'ar'
                ? 'اختر الطعام المشوي بدلاً من المقلي'
                : 'Choose grilled food instead of fried'}
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary">•</span>
              {language === 'ar'
                ? 'قلل من استخدام الملح في الطعام'
                : 'Reduce salt usage in your food'}
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};