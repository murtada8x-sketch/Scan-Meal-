import { useNutrition } from '@/contexts/NutritionContext';

export const MacrosOverview = () => {
  const { language, dailyTotals } = useNutrition();
  
  const proteinGoal = 150;
  const carbsGoal = 200;
  const fatsGoal = 60;

  const macros = [
    {
      name: language === 'ar' ? 'بروتين' : 'Protein',
      value: Math.round(dailyTotals.protein),
      goal: proteinGoal,
      color: 'bg-protein',
      textColor: 'text-protein',
      icon: '🥩',
    },
    {
      name: language === 'ar' ? 'كارب' : 'Carbs',
      value: Math.round(dailyTotals.carbs),
      goal: carbsGoal,
      color: 'bg-carbs',
      textColor: 'text-carbs',
      icon: '🌾',
    },
    {
      name: language === 'ar' ? 'دهون' : 'Fats',
      value: Math.round(dailyTotals.fat),
      goal: fatsGoal,
      color: 'bg-fats',
      textColor: 'text-fats',
      icon: '💧',
    },
  ];

  return (
    <div className="grid grid-cols-3 gap-3 animate-fade-in">
      {macros.map((macro) => {
        const progress = Math.min((macro.value / macro.goal) * 100, 100);
        return (
          <div key={macro.name} className="bg-card rounded-2xl p-3 card-shadow text-center">
            <span className="text-lg">{macro.icon}</span>
            <p className="text-xs text-muted-foreground mt-1">{macro.name}</p>
            <p className="font-bold text-lg text-foreground">
              {macro.value}
              <span className="text-xs text-muted-foreground font-normal">/{macro.goal}g</span>
            </p>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-2">
              <div 
                className={`h-full ${macro.color} rounded-full transition-all duration-500`}
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};
