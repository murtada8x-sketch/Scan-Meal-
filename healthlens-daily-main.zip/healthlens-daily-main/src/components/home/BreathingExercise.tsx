import { useState, useEffect } from 'react';
import { useNutrition } from '@/contexts/NutritionContext';

type BreathingLevel = 'beginner' | 'athlete';

const breathingConfigs = {
  beginner: { inhale: 4, hold: 4, exhale: 4 },
  athlete: { inhale: 6, hold: 6, exhale: 8 },
};

export const BreathingExercise = () => {
  const { t, language } = useNutrition();
  const [phase, setPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [isActive, setIsActive] = useState(false);
  const [progress, setProgress] = useState(0);
  const [level, setLevel] = useState<BreathingLevel>('beginner');
  const [showSettings, setShowSettings] = useState(false);

  const config = breathingConfigs[level];

  useEffect(() => {
    if (!isActive) {
      setProgress(0);
      setPhase('inhale');
      return;
    }

    const phases = {
      inhale: { duration: config.inhale * 1000, next: 'hold' as const },
      hold: { duration: config.hold * 1000, next: 'exhale' as const },
      exhale: { duration: config.exhale * 1000, next: 'inhale' as const },
    };

    const currentPhase = phases[phase];
    let startTime = Date.now();

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progressPercent = Math.min((elapsed / currentPhase.duration) * 100, 100);
      setProgress(progressPercent);

      if (elapsed >= currentPhase.duration) {
        setPhase(currentPhase.next);
        setProgress(0);
        startTime = Date.now();
      }
    }, 50);

    return () => clearInterval(interval);
  }, [isActive, phase, config]);

  const getPhaseColor = () => {
    switch (phase) {
      case 'inhale': return 'text-primary';
      case 'hold': return 'text-warning';
      case 'exhale': return 'text-destructive';
    }
  };

  const getPhaseText = () => {
    switch (phase) {
      case 'inhale': return t('inhale');
      case 'hold': return t('hold');
      case 'exhale': return t('exhale');
    }
  };

  // Calculate lung animation scale
  const getLungScale = () => {
    if (!isActive) return 0.6;
    if (phase === 'inhale') return 0.6 + (progress / 100) * 0.4;
    if (phase === 'hold') return 1;
    if (phase === 'exhale') return 1 - (progress / 100) * 0.4;
    return 0.6;
  };

  return (
    <div className="bg-card rounded-2xl p-4 card-shadow animate-fade-in relative">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-foreground text-sm">{t('breathingExercise')}</h3>
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="text-xs text-primary"
        >
          {level === 'beginner' 
            ? (language === 'ar' ? 'مبتدئ' : 'Beginner')
            : (language === 'ar' ? 'رياضي' : 'Athlete')
          }
        </button>
      </div>

      {/* Settings */}
      {showSettings && (
        <div className="absolute top-12 end-4 bg-card border border-border rounded-lg p-2 shadow-lg z-10">
          <button
            onClick={() => { setLevel('beginner'); setShowSettings(false); }}
            className={`block w-full text-start px-3 py-2 rounded text-sm ${level === 'beginner' ? 'bg-primary/10 text-primary' : 'text-foreground'}`}
          >
            {language === 'ar' ? 'مبتدئ (4-4-4)' : 'Beginner (4-4-4)'}
          </button>
          <button
            onClick={() => { setLevel('athlete'); setShowSettings(false); }}
            className={`block w-full text-start px-3 py-2 rounded text-sm ${level === 'athlete' ? 'bg-primary/10 text-primary' : 'text-foreground'}`}
          >
            {language === 'ar' ? 'رياضي (6-6-8)' : 'Athlete (6-6-8)'}
          </button>
        </div>
      )}
      
      <div className="flex items-center gap-3">
        <button
          onClick={() => setIsActive(!isActive)}
          className="relative w-14 h-14 flex items-center justify-center"
        >
          {/* Lung SVG */}
          <svg
            viewBox="0 0 100 100"
            className="w-14 h-14 transition-transform duration-300"
            style={{ transform: `scale(${getLungScale()})` }}
          >
            {/* Left lung */}
            <path
              d="M 35 30 Q 20 35 18 55 Q 16 75 30 85 Q 40 90 45 80 L 45 35 Q 45 30 35 30"
              fill={phase === 'exhale' ? 'hsl(var(--destructive))' : 'hsl(var(--primary))'}
              opacity={isActive ? 0.8 : 0.4}
              className="transition-all duration-300"
            />
            {/* Right lung */}
            <path
              d="M 65 30 Q 80 35 82 55 Q 84 75 70 85 Q 60 90 55 80 L 55 35 Q 55 30 65 30"
              fill={phase === 'exhale' ? 'hsl(var(--destructive))' : 'hsl(var(--primary))'}
              opacity={isActive ? 0.8 : 0.4}
              className="transition-all duration-300"
            />
            {/* Trachea */}
            <path
              d="M 45 35 L 45 20 Q 50 15 55 20 L 55 35"
              fill="none"
              stroke={isActive ? 'hsl(var(--primary))' : 'hsl(var(--muted-foreground))'}
              strokeWidth="3"
              opacity={0.6}
            />
            {/* Progress circle overlay */}
            {isActive && (
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke={phase === 'inhale' ? 'hsl(var(--primary))' : phase === 'hold' ? 'hsl(var(--warning))' : 'hsl(var(--destructive))'}
                strokeWidth="2"
                strokeDasharray={`${progress * 2.83} 283`}
                strokeLinecap="round"
                transform="rotate(-90 50 50)"
                opacity={0.6}
              />
            )}
          </svg>
        </button>
        
        <div className="flex-1">
          {isActive ? (
            <>
              <p className={`text-sm font-medium ${getPhaseColor()}`}>{getPhaseText()}</p>
              <p className="text-xs text-muted-foreground">
                {config.inhale}-{config.hold}-{config.exhale}
              </p>
            </>
          ) : (
            <>
              <p className="text-sm text-muted-foreground">
                {language === 'ar' ? 'اضغط للبدء' : 'Tap to start'}
              </p>
              <p className="text-xs text-muted-foreground">
                {config.inhale}-{config.hold}-{config.exhale}
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
