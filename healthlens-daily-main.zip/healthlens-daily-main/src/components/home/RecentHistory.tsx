import { useState } from 'react';
import { Trash2, ChevronRight, X } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { Meal } from '@/types/nutrition';

export const RecentHistory = () => {
  const { language, t, meals, removeMeal, setActiveTab } = useNutrition();
  const [showAll, setShowAll] = useState(false);
  const [selectedMeal, setSelectedMeal] = useState<Meal | null>(null);

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const displayMeals = showAll ? meals : meals.slice(0, 4);

  // Full screen view all
  if (showAll) {
    return (
      <div className="fixed inset-0 bg-background z-50 safe-top safe-bottom">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <button onClick={() => setShowAll(false)} className="p-2">
            <X size={24} className="text-foreground" />
          </button>
          <h2 className="font-semibold text-foreground">{t('recentHistory')}</h2>
          <div className="w-10" />
        </div>
        
        <div className="p-4 overflow-y-auto h-[calc(100vh-80px)]">
          <div className="space-y-3">
            {meals.map((meal) => (
              <div 
                key={meal.id} 
                className="bg-card rounded-2xl p-3 card-shadow flex items-center gap-3"
              >
                <button
                  onClick={() => setSelectedMeal(meal)}
                  className="flex-1 flex items-center gap-3 text-start"
                >
                  <div className="w-12 h-12 bg-muted rounded-xl flex items-center justify-center text-2xl">
                    {meal.image || '🍽️'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-foreground truncate">
                      {language === 'ar' ? meal.nameAr || meal.name : meal.name}
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      {meal.type === 'camera' ? '📸' : meal.type === 'barcode' ? '📊' : '✏️'} • {meal.calories} kcal
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">{formatTime(meal.timestamp)}</p>
                  </div>
                </button>
                <button
                  onClick={() => removeMeal(meal.id)}
                  className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ))}

            {meals.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <p>{language === 'ar' ? 'لا توجد وجبات' : 'No meals yet'}</p>
              </div>
            )}
          </div>
        </div>

        {/* Meal Detail Modal */}
        {selectedMeal && (
          <div className="fixed inset-0 bg-background/80 z-50 flex items-center justify-center p-4">
            <div className="bg-card rounded-2xl p-4 card-shadow w-full max-w-sm">
              <div className="flex items-center justify-between mb-4">
                <button onClick={() => setSelectedMeal(null)} className="text-primary text-sm">
                  ← {language === 'ar' ? 'رجوع' : 'Back'}
                </button>
                <button 
                  onClick={() => { removeMeal(selectedMeal.id); setSelectedMeal(null); }}
                  className="text-destructive text-sm flex items-center gap-1"
                >
                  <Trash2 size={14} /> {t('delete')}
                </button>
              </div>
              <div className="text-center mb-4">
                <div className="text-4xl mb-2">{selectedMeal.image || '🍽️'}</div>
                <h3 className="font-bold text-lg text-foreground">
                  {language === 'ar' ? selectedMeal.nameAr || selectedMeal.name : selectedMeal.name}
                </h3>
                <p className="text-sm text-muted-foreground">{formatTime(selectedMeal.timestamp)}</p>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="bg-muted rounded-lg p-2">
                  <p className="font-bold text-foreground">{selectedMeal.calories}</p>
                  <p className="text-xs text-muted-foreground">kcal</p>
                </div>
                <div className="bg-protein-light rounded-lg p-2">
                  <p className="font-bold text-protein">{selectedMeal.protein}g</p>
                  <p className="text-xs text-muted-foreground">{t('protein')}</p>
                </div>
                <div className="bg-carbs-light rounded-lg p-2">
                  <p className="font-bold text-carbs">{selectedMeal.carbs}g</p>
                  <p className="text-xs text-muted-foreground">{t('carbs')}</p>
                </div>
                <div className="bg-fats-light rounded-lg p-2">
                  <p className="font-bold text-fats">{selectedMeal.fat}g</p>
                  <p className="text-xs text-muted-foreground">{t('fat')}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-foreground">{t('recentHistory')}</h3>
        <button 
          onClick={() => setShowAll(true)}
          className="text-primary text-sm font-medium flex items-center gap-1"
        >
          {t('viewAll')}
          <ChevronRight size={14} />
        </button>
      </div>
      
      <div className="space-y-3">
        {displayMeals.map((meal) => (
          <button 
            key={meal.id} 
            onClick={() => setSelectedMeal(meal)}
            className="w-full bg-card rounded-2xl p-3 card-shadow flex items-center gap-3 text-start"
          >
            <div className="w-12 h-12 bg-muted rounded-xl flex items-center justify-center text-2xl">
              {meal.image || '🍽️'}
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-foreground truncate">
                {language === 'ar' ? meal.nameAr || meal.name : meal.name}
              </h4>
              <p className="text-xs text-muted-foreground">
                {meal.type === 'camera' ? '📸' : meal.type === 'barcode' ? '📊' : '✏️'} • {meal.calories} kcal
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">{formatTime(meal.timestamp)}</p>
            </div>
          </button>
        ))}

        {meals.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <p>{language === 'ar' ? 'لا توجد وجبات' : 'No meals yet'}</p>
          </div>
        )}
      </div>

      {/* Meal Detail Modal */}
      {selectedMeal && (
        <div className="fixed inset-0 bg-background/80 z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-2xl p-4 card-shadow w-full max-w-sm">
            <div className="flex items-center justify-between mb-4">
              <button onClick={() => setSelectedMeal(null)} className="text-primary text-sm">
                ← {language === 'ar' ? 'رجوع' : 'Back'}
              </button>
            </div>
            <div className="text-center mb-4">
              <div className="text-4xl mb-2">{selectedMeal.image || '🍽️'}</div>
              <h3 className="font-bold text-lg text-foreground">
                {language === 'ar' ? selectedMeal.nameAr || selectedMeal.name : selectedMeal.name}
              </h3>
              <p className="text-sm text-muted-foreground">{formatTime(selectedMeal.timestamp)}</p>
            </div>
            <div className="grid grid-cols-4 gap-2 text-center">
              <div className="bg-muted rounded-lg p-2">
                <p className="font-bold text-foreground">{selectedMeal.calories}</p>
                <p className="text-xs text-muted-foreground">kcal</p>
              </div>
              <div className="bg-protein-light rounded-lg p-2">
                <p className="font-bold text-protein">{selectedMeal.protein}g</p>
                <p className="text-xs text-muted-foreground">{t('protein')}</p>
              </div>
              <div className="bg-carbs-light rounded-lg p-2">
                <p className="font-bold text-carbs">{selectedMeal.carbs}g</p>
                <p className="text-xs text-muted-foreground">{t('carbs')}</p>
              </div>
              <div className="bg-fats-light rounded-lg p-2">
                <p className="font-bold text-fats">{selectedMeal.fat}g</p>
                <p className="text-xs text-muted-foreground">{t('fat')}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
