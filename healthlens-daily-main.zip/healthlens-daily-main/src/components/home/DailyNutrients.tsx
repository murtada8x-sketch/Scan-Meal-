import { useNutrition } from '@/contexts/NutritionContext';

export const DailyNutrients = () => {
  const { language, dailyTotals } = useNutrition();
  
  const fatGoal = 60;
  const vitaminGoal = 100;
  const fatLevel = Math.min((dailyTotals.fat / fatGoal) * 100, 100);
  const vitaminLevel = 72; // Simulated vitamin level

  return (
    <div className="bg-card rounded-2xl p-4 card-shadow animate-fade-in">
      <h3 className="font-semibold text-foreground mb-4">
        {language === 'ar' ? 'حالة العناصر الغذائية اليومية' : 'Daily Nutrients Status'}
      </h3>
      
      <div className="space-y-4">
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-foreground">
              {language === 'ar' ? 'مستوى الدهون' : 'Fat Level'}
            </span>
            <span className="text-sm font-semibold text-primary">{Math.round(fatLevel)}%</span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-primary rounded-full transition-all duration-500"
              style={{ width: `${fatLevel}%` }}
            />
          </div>
        </div>
        
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-foreground">
              {language === 'ar' ? 'مستوى الفيتامينات' : 'Vitamins Level'}
            </span>
            <span className="text-sm font-semibold text-warning">{vitaminLevel}%</span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-warning rounded-full transition-all duration-500"
              style={{ width: `${vitaminLevel}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
