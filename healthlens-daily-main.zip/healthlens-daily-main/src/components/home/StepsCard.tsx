import { useEffect } from 'react';
import { Flame, MapPin } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';

export const StepsCard = () => {
  const { steps, addSteps, language, updateProfile, profile } = useNutrition();
  const goalSteps = 10000;
  const caloriesBurned = Math.round(steps * 0.04);
  const distance = (steps * 0.0008).toFixed(2);
  const progress = Math.min((steps / goalSteps) * 100, 100);

  // Auto-update activity level based on steps
  useEffect(() => {
    let newActivityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'veryActive';
    
    if (steps < 3000) {
      newActivityLevel = 'sedentary';
    } else if (steps < 5000) {
      newActivityLevel = 'light';
    } else if (steps < 8000) {
      newActivityLevel = 'moderate';
    } else if (steps < 12000) {
      newActivityLevel = 'active';
    } else {
      newActivityLevel = 'veryActive';
    }

    if (profile.activityLevel !== newActivityLevel) {
      updateProfile({ activityLevel: newActivityLevel });
    }
  }, [steps, profile.activityLevel, updateProfile]);

  const getActivityLabel = () => {
    switch (profile.activityLevel) {
      case 'sedentary': return language === 'ar' ? 'خامل' : 'Sedentary';
      case 'light': return language === 'ar' ? 'خفيف' : 'Light';
      case 'moderate': return language === 'ar' ? 'متوسط' : 'Moderate';
      case 'active': return language === 'ar' ? 'نشيط' : 'Active';
      case 'veryActive': return language === 'ar' ? 'نشيط جداً' : 'Very Active';
    }
  };

  return (
    <div className="bg-card rounded-2xl p-4 card-shadow animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-lg">👟</span>
          </div>
          <div>
            <h3 className="font-semibold text-foreground">
              {language === 'ar' ? 'الخطوات' : 'Steps'}
            </h3>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Flame size={12} className="text-warning" />
                {caloriesBurned} cal
              </span>
              <span className="flex items-center gap-1">
                <MapPin size={12} className="text-destructive" />
                {distance} km
              </span>
            </div>
          </div>
        </div>
        <div className="text-right">
          <p className="font-bold text-foreground">
            <span className="text-lg">{steps.toLocaleString()}</span>
            <span className="text-muted-foreground text-sm">/{goalSteps.toLocaleString()}</span>
          </p>
          <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
            {getActivityLabel()}
          </span>
        </div>
      </div>
      
      <div className="mt-3 flex items-center gap-3">
        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
          <div 
            className="h-full bg-primary rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <button 
          onClick={() => addSteps(100)}
          className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-xs font-semibold hover:opacity-90 transition-opacity"
        >
          +100
        </button>
      </div>
    </div>
  );
};
