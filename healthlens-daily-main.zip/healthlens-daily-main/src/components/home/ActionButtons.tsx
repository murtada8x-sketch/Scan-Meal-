import { Camera, Plus } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';

interface ActionButtonsProps {
  onScanClick: () => void;
  onAddManualClick: () => void;
}

export const ActionButtons = ({ onScanClick, onAddManualClick }: ActionButtonsProps) => {
  const { language } = useNutrition();

  return (
    <div className="space-y-3 animate-fade-in">
      <button 
        onClick={onScanClick}
        className="w-full bg-primary text-primary-foreground py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity card-shadow-lg"
      >
        <Camera size={20} />
        {language === 'ar' ? 'مسح الوجبة' : 'Scan Meal'}
      </button>
      
      <button 
        onClick={onAddManualClick}
        className="w-full bg-warning text-warning-foreground py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
      >
        <Plus size={20} />
        {language === 'ar' ? 'إضافة وجبة يدوياً' : 'Add Meal Manually'}
      </button>
    </div>
  );
};
