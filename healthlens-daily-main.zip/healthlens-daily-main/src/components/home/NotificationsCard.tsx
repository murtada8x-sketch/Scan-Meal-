import { useState } from 'react';
import { Bell, Droplets, Brain, ChevronRight, X } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { Switch } from '@/components/ui/switch';

export const NotificationsCard = () => {
  const { 
    t, 
    language,
    waterRemindersEnabled, 
    setWaterRemindersEnabled,
    stressRemindersEnabled,
    setStressRemindersEnabled,
  } = useNutrition();

  const [showPanel, setShowPanel] = useState(false);

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }
    return false;
  };

  const handleWaterToggle = async (enabled: boolean) => {
    if (enabled) {
      const granted = await requestNotificationPermission();
      if (granted) {
        setWaterRemindersEnabled(true);
      }
    } else {
      setWaterRemindersEnabled(false);
    }
  };

  const handleStressToggle = async (enabled: boolean) => {
    if (enabled) {
      const granted = await requestNotificationPermission();
      if (granted) {
        setStressRemindersEnabled(true);
      }
    } else {
      setStressRemindersEnabled(false);
    }
  };

  if (showPanel) {
    return (
      <div className="fixed inset-0 bg-background z-50 safe-top safe-bottom">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <button onClick={() => setShowPanel(false)} className="p-2">
            <X size={24} className="text-foreground" />
          </button>
          <h2 className="font-semibold text-foreground">{t('notifications')}</h2>
          <div className="w-10" />
        </div>
        
        <div className="p-4 space-y-4">
          {/* Water Reminders */}
          <div className="bg-card rounded-2xl p-4 border border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-water/10 flex items-center justify-center">
                  <Droplets size={24} className="text-water" />
                </div>
                <div>
                  <p className="font-medium text-foreground">{t('waterReminder')}</p>
                  <p className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'كل ساعتين خلال فترة الاستيقاظ' : 'Every 2 hours during awake time'}
                  </p>
                </div>
              </div>
              <Switch 
                checked={waterRemindersEnabled}
                onCheckedChange={handleWaterToggle}
              />
            </div>
          </div>
          
          {/* Stress Reminders */}
          <div className="bg-card rounded-2xl p-4 border border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Brain size={24} className="text-primary" />
                </div>
                <div>
                  <p className="font-medium text-foreground">{t('breathingExercise')}</p>
                  <p className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'تنبيهات للتقليل من التوتر' : 'Stress relief reminders'}
                  </p>
                </div>
              </div>
              <Switch 
                checked={stressRemindersEnabled}
                onCheckedChange={handleStressToggle}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <button
      onClick={() => setShowPanel(true)}
      className="bg-card rounded-2xl p-4 card-shadow animate-fade-in w-full text-start"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell size={18} className="text-primary" />
          <h3 className="font-semibold text-foreground text-sm">{t('notifications')}</h3>
        </div>
        <ChevronRight size={16} className="text-muted-foreground" />
      </div>
      
      <div className="mt-2 flex gap-2">
        {waterRemindersEnabled && (
          <span className="text-xs bg-water/10 text-water px-2 py-1 rounded-full">💧</span>
        )}
        {stressRemindersEnabled && (
          <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">🧠</span>
        )}
        {!waterRemindersEnabled && !stressRemindersEnabled && (
          <span className="text-xs text-muted-foreground">
            {language === 'ar' ? 'اضغط للإعداد' : 'Tap to setup'}
          </span>
        )}
      </div>
    </button>
  );
};
