import { useState } from 'react';
import { ChevronRight } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { HealthyFoodDetails } from './HealthyFoodDetails';

export const HealthyFoodLevel = () => {
  const { language, dailyTotals } = useNutrition();
  const [showDetails, setShowDetails] = useState(false);
  
  // Calculate health score based on balanced nutrition
  const proteinRatio = Math.min(dailyTotals.protein / 150, 1);
  const carbsRatio = Math.min(dailyTotals.carbs / 200, 1);
  const fatsRatio = Math.min(dailyTotals.fat / 60, 1);
  
  // Penalize for high sugar and salt
  const sugarPenalty = Math.max(0, (dailyTotals.sugar - 25) / 25) * 0.3;
  const saltPenalty = Math.max(0, (dailyTotals.salt - 2.3) / 2.3) * 0.2;
  
  const baseScore = ((proteinRatio + carbsRatio * 0.8 + fatsRatio * 0.6) / 2.4);
  const healthScore = Math.max(0, Math.min(100, Math.round((baseScore - sugarPenalty - saltPenalty) * 100)));

  if (showDetails) {
    return <HealthyFoodDetails onClose={() => setShowDetails(false)} />;
  }

  return (
    <button 
      onClick={() => setShowDetails(true)}
      className="w-full bg-card rounded-2xl p-4 card-shadow animate-fade-in text-start"
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-foreground">
          {language === 'ar' ? 'مستوى الغذاء الصحي' : 'Healthy Food Level'}
        </h3>
        <div className="flex items-center gap-1 text-primary">
          <span className="font-bold">{healthScore}%</span>
          <ChevronRight size={16} />
        </div>
      </div>
      
      <div className="relative h-2 bg-gradient-to-r from-destructive via-warning to-primary rounded-full overflow-hidden">
        <div 
          className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-foreground rounded-full border-2 border-card shadow-md transition-all duration-500"
          style={{ left: `calc(${healthScore}% - 6px)` }}
        />
      </div>
      
      <div className="flex justify-between mt-2 text-xs text-muted-foreground">
        <span>{language === 'ar' ? 'غير صحي' : 'Unhealthy'}</span>
        <span>{language === 'ar' ? 'صحي جداً' : 'Very Healthy'}</span>
      </div>
    </button>
  );
};
