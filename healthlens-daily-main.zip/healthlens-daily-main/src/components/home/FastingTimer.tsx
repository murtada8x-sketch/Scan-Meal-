import { useState, useEffect } from 'react';
import { Play, Pause, Timer } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';

interface FastingStage {
  hours: number;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
}

const fastingStages: FastingStage[] = [
  { hours: 0, name: 'Fed State', nameAr: 'حالة التغذية', description: 'Blood sugar rising', descriptionAr: 'ارتفاع سكر الدم' },
  { hours: 4, name: 'Early Fasting', nameAr: 'بداية الصيام', description: 'Blood sugar stabilizing', descriptionAr: 'استقرار سكر الدم' },
  { hours: 8, name: 'Fasting', nameAr: 'الصيام', description: 'Fat burning begins', descriptionAr: 'بدء حرق الدهون' },
  { hours: 12, name: 'Ketosis', nameAr: 'الكيتوزس', description: 'Entering ketosis', descriptionAr: 'الدخول في الكيتوزس' },
  { hours: 14, name: 'Autophagy', nameAr: 'الالتهام الذاتي', description: 'Cellular cleanup begins', descriptionAr: 'بدء تنظيف الخلايا' },
  { hours: 16, name: 'Deep Autophagy', nameAr: 'التهام ذاتي عميق', description: 'Enhanced cellular repair', descriptionAr: 'إصلاح خلوي معزز' },
  { hours: 18, name: 'Growth Hormone', nameAr: 'هرمون النمو', description: 'HGH surge', descriptionAr: 'ارتفاع هرمون النمو' },
];

export const FastingTimer = () => {
  const { language, t, fastingSession, startFasting, stopFasting, profile } = useNutrition();
  const [timeRemaining, setTimeRemaining] = useState<number>(0);
  const [showDurationPicker, setShowDurationPicker] = useState(false);

  const fastingOptions = [4, 7, 12, 16, 18, profile.customFastingHours].filter(Boolean) as number[];

  useEffect(() => {
    if (!fastingSession?.isActive) {
      setTimeRemaining(0);
      return;
    }

    const updateTimer = () => {
      const now = new Date().getTime();
      const end = new Date(fastingSession.endTime).getTime();
      const remaining = Math.max(0, end - now);
      setTimeRemaining(remaining);

      if (remaining <= 0) {
        stopFasting();
        // Trigger notification
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification(t('fastingComplete'), {
            body: t('fastingCompleteMsg'),
            icon: '/icon-512.png',
          });
        }
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [fastingSession, stopFasting, t]);

  const formatTime = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((ms % (1000 * 60)) / 1000);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const getElapsedHours = () => {
    if (!fastingSession) return 0;
    const elapsed = (fastingSession.duration * 60 * 60 * 1000) - timeRemaining;
    return elapsed / (1000 * 60 * 60);
  };

  const progress = fastingSession 
    ? ((fastingSession.duration * 60 * 60 * 1000 - timeRemaining) / (fastingSession.duration * 60 * 60 * 1000)) * 100
    : 0;

  const getCurrentStage = () => {
    const elapsed = getElapsedHours();
    let currentStage = fastingStages[0];
    for (const stage of fastingStages) {
      if (elapsed >= stage.hours) {
        currentStage = stage;
      }
    }
    return currentStage;
  };

  const getNextStage = () => {
    const elapsed = getElapsedHours();
    for (const stage of fastingStages) {
      if (elapsed < stage.hours) {
        return stage;
      }
    }
    return null;
  };

  const getProgressColor = () => {
    if (progress < 50) return 'bg-primary';
    if (progress < 80) return 'bg-warning';
    return 'bg-destructive';
  };

  const currentStage = getCurrentStage();
  const nextStage = getNextStage();

  return (
    <div className="bg-card rounded-2xl p-4 card-shadow animate-fade-in">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Timer size={18} className="text-primary" />
          <h3 className="font-semibold text-foreground text-sm">{t('fasting')}</h3>
        </div>
        {fastingSession && (
          <span className="text-xs text-muted-foreground">
            {fastingSession.duration}h {t('fasting').toLowerCase()}
          </span>
        )}
      </div>

      {fastingSession ? (
        <div className="space-y-3">
          {/* Progress Bar */}
          <div className="relative">
            <div className="h-3 bg-muted rounded-full overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-1000 ${getProgressColor()}`}
                style={{ width: `${Math.min(progress, 100)}%` }}
              />
            </div>
            {/* Stage markers */}
            <div className="absolute top-0 left-0 right-0 h-3 flex items-center">
              {fastingStages.filter(s => s.hours <= fastingSession.duration && s.hours > 0).map((stage) => (
                <div
                  key={stage.hours}
                  className="absolute w-0.5 h-3 bg-foreground/30"
                  style={{ left: `${(stage.hours / fastingSession.duration) * 100}%` }}
                />
              ))}
            </div>
          </div>

          {/* Time and Stage Info */}
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-foreground">{formatTime(timeRemaining)}</p>
              <p className="text-xs text-muted-foreground">{language === 'ar' ? 'متبقي' : 'remaining'}</p>
            </div>
            <div className="text-end">
              <p className="text-sm font-medium text-primary">
                {language === 'ar' ? currentStage.nameAr : currentStage.name}
              </p>
              <p className="text-xs text-muted-foreground">
                {language === 'ar' ? currentStage.descriptionAr : currentStage.description}
              </p>
            </div>
          </div>

          {/* Next Stage */}
          {nextStage && (
            <div className="bg-muted/50 rounded-lg px-3 py-2">
              <p className="text-xs text-muted-foreground">
                {language === 'ar' ? 'المرحلة القادمة' : 'Next stage'}: {' '}
                <span className="font-medium text-foreground">
                  {language === 'ar' ? nextStage.nameAr : nextStage.name}
                </span>
                {' '}({language === 'ar' ? 'عند' : 'at'} {nextStage.hours}h)
              </p>
            </div>
          )}

          {/* Stop Button */}
          <button
            onClick={stopFasting}
            className="w-full flex items-center justify-center gap-2 bg-destructive/10 text-destructive py-2 rounded-xl text-sm font-medium hover:bg-destructive/20 transition-colors"
          >
            <Pause size={16} />
            {t('stopFasting')}
          </button>
        </div>
      ) : (
        <>
          {showDurationPicker ? (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground text-center">
                {language === 'ar' ? 'اختر مدة الصيام' : 'Choose fasting duration'}
              </p>
              <div className="flex flex-wrap gap-2 justify-center">
                {fastingOptions.map((hours) => (
                  <button
                    key={hours}
                    onClick={() => {
                      startFasting(hours);
                      setShowDurationPicker(false);
                    }}
                    className="px-4 py-2 bg-muted hover:bg-primary hover:text-primary-foreground rounded-xl text-sm font-medium transition-colors"
                  >
                    {hours}h
                  </button>
                ))}
              </div>
              <button
                onClick={() => setShowDurationPicker(false)}
                className="w-full text-sm text-muted-foreground hover:text-foreground"
              >
                {t('cancel')}
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowDurationPicker(true)}
              className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground py-2.5 rounded-xl font-semibold hover:opacity-90 transition-opacity"
            >
              <Play size={16} />
              {t('startFasting')}
            </button>
          )}
        </>
      )}
    </div>
  );
};
