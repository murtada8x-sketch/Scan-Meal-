import { Droplets } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';

export const WaterTracker = () => {
  const { language, waterIntake, addWater, profile } = useNutrition();
  const goal = profile.dailyWaterGoal;
  const progress = Math.min((waterIntake / goal) * 100, 100);

  return (
    <div className="bg-card rounded-2xl p-4 card-shadow animate-fade-in">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Droplets size={20} className="text-water" />
          <span className="font-semibold text-foreground">
            {language === 'ar' ? 'الماء' : 'Water'}
          </span>
        </div>
        <p className="text-water font-semibold">
          {waterIntake}ml / {goal}ml
        </p>
      </div>
      
      <div className="flex items-center gap-3">
        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
          <div 
            className="h-full bg-water rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <button 
          onClick={() => addWater(profile.waterCupSize)}
          className="bg-primary text-primary-foreground px-3 py-1.5 rounded-full text-xs font-semibold hover:opacity-90 transition-opacity"
        >
          +{profile.waterCupSize}ml
        </button>
      </div>
    </div>
  );
};
