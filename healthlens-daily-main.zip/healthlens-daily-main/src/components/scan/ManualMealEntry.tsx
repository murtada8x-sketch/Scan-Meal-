import { useState } from 'react';
import { X, Plus, Minus, Check, Search } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { Meal } from '@/types/nutrition';
import { foodCategories, defaultRecipes } from '@/data/nutrition-data';

interface ManualMealEntryProps {
  onClose: () => void;
  onMealAdded: (meal: Meal) => void;
}

export const ManualMealEntry = ({ onClose, onMealAdded }: ManualMealEntryProps) => {
  const { language, recipes } = useNutrition();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedFood, setSelectedFood] = useState<typeof defaultRecipes[0] | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');

  const allFoods = [...defaultRecipes, ...recipes];
  
  const filteredFoods = allFoods.filter(food => {
    const matchesSearch = searchQuery === '' || 
      food.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (food.nameAr && food.nameAr.includes(searchQuery));
    const matchesCategory = !selectedCategory || food.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const confirmMeal = () => {
    if (!selectedFood) return;

    const meal: Meal = {
      id: Date.now().toString(),
      name: selectedFood.name,
      nameAr: selectedFood.nameAr,
      image: selectedFood.image,
      calories: Math.round(selectedFood.calories * quantity),
      protein: Math.round(selectedFood.protein * quantity),
      carbs: Math.round(selectedFood.carbs * quantity),
      fat: Math.round(selectedFood.fat * quantity),
      vitamins: selectedFood.vitamins,
      minerals: selectedFood.minerals,
      aminoAcids: selectedFood.aminoAcids,
      quantity: 1,
      timestamp: new Date(),
      type: 'manual',
      servingSize: selectedFood.servingSize,
      servingGrams: selectedFood.servingGrams ? selectedFood.servingGrams * quantity : undefined,
    };

    onMealAdded(meal);
  };

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col safe-top safe-bottom">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-card border-b border-border">
        <button onClick={onClose} className="p-2">
          <X size={24} className="text-foreground" />
        </button>
        <h2 className="font-semibold text-foreground">
          {language === 'ar' ? 'إضافة وجبة' : 'Add Meal'}
        </h2>
        <div className="w-10" />
      </div>

      {/* Search */}
      <div className="p-4 bg-card border-b border-border">
        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'ar' ? 'ابحث عن طعام...' : 'Search food...'}
            className="w-full bg-muted border border-border rounded-xl pl-10 pr-4 py-3 text-foreground placeholder:text-muted-foreground"
          />
        </div>
      </div>

      {/* Categories */}
      <div className="px-4 py-3 bg-card border-b border-border overflow-x-auto hide-scrollbar">
        <div className="flex gap-2">
          <button
            onClick={() => setSelectedCategory(null)}
            className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
              !selectedCategory 
                ? 'bg-foreground text-background' 
                : 'bg-muted text-foreground'
            }`}
          >
            {language === 'ar' ? 'الكل' : 'All'}
          </button>
          {foodCategories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                selectedCategory === cat.id 
                  ? 'bg-foreground text-background' 
                  : 'bg-muted text-foreground'
              }`}
            >
              <span>{cat.icon}</span>
              {language === 'ar' ? cat.nameAr : cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Food List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {filteredFoods.map((food) => (
          <button
            key={food.id}
            onClick={() => setSelectedFood(food)}
            className={`w-full text-left bg-card rounded-2xl p-4 card-shadow transition-all ${
              selectedFood?.id === food.id ? 'ring-2 ring-primary' : ''
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 bg-muted rounded-xl flex items-center justify-center text-2xl">
                {food.image || '🍽️'}
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-foreground">
                  {language === 'ar' ? food.nameAr || food.name : food.name}
                </h4>
                <p className="text-sm text-muted-foreground">
                  {food.servingSize || `${food.servingGrams}g`} • {food.calories} kcal
                </p>
                <div className="flex gap-3 text-xs mt-1">
                  <span className="text-protein">P: {food.protein}g</span>
                  <span className="text-carbs">C: {food.carbs}g</span>
                  <span className="text-fats">F: {food.fat}g</span>
                </div>
              </div>
            </div>
          </button>
        ))}

        {filteredFoods.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            {language === 'ar' ? 'لا توجد نتائج' : 'No results found'}
          </div>
        )}
      </div>

      {/* Quantity & Confirm */}
      {selectedFood && (
        <div className="bg-card border-t border-border p-4 space-y-4 animate-slide-up">
          <div className="bg-muted rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-foreground">
                {language === 'ar' ? selectedFood.nameAr || selectedFood.name : selectedFood.name}
              </h3>
            </div>

            <div className="flex items-center justify-center gap-6 mb-4">
              <button
                onClick={() => setQuantity(Math.max(0.5, quantity - 0.5))}
                className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center"
              >
                <Minus size={18} className="text-foreground" />
              </button>
              <span className="text-2xl font-bold text-foreground w-16 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 0.5)}
                className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center"
              >
                <Plus size={18} />
              </button>
            </div>

            {/* Nutrition Summary */}
            <div className="grid grid-cols-4 gap-2 text-center text-sm">
              <div className="bg-card rounded-lg p-2">
                <p className="font-bold text-foreground">{Math.round(selectedFood.calories * quantity)}</p>
                <p className="text-xs text-muted-foreground">kcal</p>
              </div>
              <div className="bg-card rounded-lg p-2">
                <p className="font-bold text-protein">{Math.round(selectedFood.protein * quantity)}g</p>
                <p className="text-xs text-muted-foreground">P</p>
              </div>
              <div className="bg-card rounded-lg p-2">
                <p className="font-bold text-carbs">{Math.round(selectedFood.carbs * quantity)}g</p>
                <p className="text-xs text-muted-foreground">C</p>
              </div>
              <div className="bg-card rounded-lg p-2">
                <p className="font-bold text-fats">{Math.round(selectedFood.fat * quantity)}g</p>
                <p className="text-xs text-muted-foreground">F</p>
              </div>
            </div>
          </div>

          <button
            onClick={confirmMeal}
            className="w-full py-4 bg-primary text-primary-foreground rounded-2xl font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
          >
            <Plus size={20} />
            {language === 'ar' ? 'إضافة للسجل اليومي' : 'Add to Daily Log'}
          </button>
        </div>
      )}
    </div>
  );
};
