import { useState, useRef, useEffect } from 'react';
import { X, Check, Loader2, Upload, Edit2, Search, Heart, Minus, Plus, Sparkles, Image as ImageIcon } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { Meal } from '@/types/nutrition';
import { analyzeFood, FoodAnalysisResult } from '@/lib/gemini-api';
import { defaultRecipes } from '@/data/nutrition-data';

interface CameraScannerProps {
  onClose: () => void;
  onMealScanned: (meal: Meal) => void;
}

export const CameraScanner = ({ onClose, onMealScanned }: CameraScannerProps) => {
  const { language, t, addFavorite } = useNutrition();
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<FoodAnalysisResult | null>(null);
  const [servingCount, setServingCount] = useState(1);
  const [servingSize] = useState(80); // Default serving size in grams
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const startCamera = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (error) {
        console.error('Camera access denied:', error);
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const captureImage = () => {
    if (!videoRef.current) return;

    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      setCapturedImage(dataUrl);
      analyzeFoodImage(dataUrl);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const dataUrl = reader.result as string;
      setCapturedImage(dataUrl);
      analyzeFoodImage(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const analyzeFoodImage = async (imageData: string) => {
    setIsLoading(true);
    try {
      const result = await analyzeFood(imageData, language);
      setAnalysisResult(result);
      setEditedName(language === 'ar' ? result.nameAr || result.name : result.name);
    } catch (error) {
      console.error('Analysis failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const confirmMeal = () => {
    if (!analysisResult) return;

    const totalGrams = servingSize * servingCount;
    const multiplier = totalGrams / 100;
    const meal: Meal = {
      id: Date.now().toString(),
      name: isEditing ? editedName : analysisResult.name,
      nameAr: analysisResult.nameAr,
      image: '📸',
      customImage: capturedImage || undefined,
      calories: Math.round(analysisResult.calories * multiplier),
      protein: Math.round(analysisResult.protein * multiplier),
      carbs: Math.round(analysisResult.carbs * multiplier),
      fat: Math.round(analysisResult.fat * multiplier),
      fiber: analysisResult.fiber ? Math.round(analysisResult.fiber * multiplier) : undefined,
      sugar: analysisResult.sugar ? Math.round(analysisResult.sugar * multiplier) : undefined,
      salt: analysisResult.salt ? Math.round(analysisResult.salt * multiplier) : undefined,
      vitamins: analysisResult.vitamins,
      minerals: analysisResult.minerals,
      acids: analysisResult.acids,
      quantity: servingCount,
      timestamp: new Date(),
      type: 'camera',
      servingGrams: totalGrams,
      confidence: analysisResult.confidence,
      warnings: analysisResult.warnings,
    };

    onMealScanned(meal);
  };

  const retake = () => {
    setCapturedImage(null);
    setAnalysisResult(null);
    setServingCount(1);
    setIsEditing(false);
    setShowSearch(false);
  };

  const selectFromSearch = (recipe: typeof defaultRecipes[0]) => {
    setAnalysisResult({
      name: recipe.name,
      nameAr: recipe.nameAr,
      calories: recipe.calories,
      protein: recipe.protein,
      carbs: recipe.carbs,
      fat: recipe.fat,
      fiber: recipe.fiber,
      sugar: recipe.sugar,
      vitamins: recipe.vitamins || {},
      minerals: recipe.minerals || {},
      acids: {},
      confidence: 100,
    });
    setEditedName(language === 'ar' ? recipe.nameAr || recipe.name : recipe.name);
    setShowSearch(false);
  };

  const addToFavorites = () => {
    if (!analysisResult) return;
    addFavorite({
      id: Date.now().toString(),
      name: analysisResult.name,
      nameAr: analysisResult.nameAr,
      calories: analysisResult.calories,
      protein: analysisResult.protein,
      carbs: analysisResult.carbs,
      fat: analysisResult.fat,
      sugar: analysisResult.sugar,
      salt: analysisResult.salt,
    });
  };

  const filteredRecipes = defaultRecipes.filter(r => 
    r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.nameAr?.includes(searchQuery)
  );

  const totalGrams = servingSize * servingCount;
  const multiplier = totalGrams / 100;

  // Search Overlay
  if (showSearch) {
    return (
      <div className="fixed inset-0 bg-background z-50 flex flex-col safe-top safe-bottom">
        <div className="flex items-center justify-between p-4 bg-card border-b border-border">
          <button onClick={() => setShowSearch(false)} className="p-2">
            <X size={24} className="text-foreground" />
          </button>
          <h2 className="font-semibold text-foreground">{t('search')}</h2>
          <div className="w-10" />
        </div>
        <div className="p-4">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('search')}
            className="w-full bg-muted border border-border rounded-xl px-4 py-3 text-foreground"
            autoFocus
          />
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {filteredRecipes.map((recipe) => (
            <button
              key={recipe.id}
              onClick={() => selectFromSearch(recipe)}
              className="w-full bg-card rounded-xl p-3 flex items-center gap-3 text-start"
            >
              <span className="text-2xl">{recipe.image}</span>
              <div>
                <p className="font-medium text-foreground">
                  {language === 'ar' ? recipe.nameAr || recipe.name : recipe.name}
                </p>
                <p className="text-sm text-muted-foreground">{recipe.calories} kcal</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Camera View
  if (!capturedImage && !analysisResult) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex flex-col">
        {/* Camera Preview */}
        <div className="flex-1 relative">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
          
          {/* Top Controls */}
          <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between safe-top">
            <button 
              onClick={onClose} 
              className="w-12 h-12 rounded-full bg-foreground/20 backdrop-blur-sm flex items-center justify-center"
            >
              <X size={24} className="text-white" />
            </button>
            <div className="flex gap-3">
              <button className="w-12 h-12 rounded-full bg-foreground/20 backdrop-blur-sm flex items-center justify-center">
                <Sparkles size={24} className="text-white" />
              </button>
            </div>
          </div>

          {/* Scanning Frame */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-72 h-56 relative">
              {/* Corner brackets - yellow/orange color */}
              <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-amber-500 rounded-tl-2xl" />
              <div className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-amber-500 rounded-tr-2xl" />
              <div className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-amber-500 rounded-bl-2xl" />
              <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-amber-500 rounded-br-2xl" />
              
              {/* Center dot */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                <div className="w-4 h-4 rounded-full border-2 border-amber-500 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                </div>
              </div>
            </div>
          </div>

          {/* Instruction Text */}
          <div className="absolute bottom-32 left-0 right-0 text-center px-4">
            <p className="text-white/90 text-sm font-medium">
              {language === 'ar' 
                ? 'ضع الطعام داخل الإطار لمسح القيم الغذائية' 
                : 'Align food within the frame to scan nutritional value'}
            </p>
          </div>

          {/* Bottom Controls */}
          <div className="absolute bottom-0 left-0 right-0 p-6 safe-bottom">
            <div className="flex items-center justify-center gap-6">
              {/* Gallery Button */}
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="w-14 h-14 rounded-full bg-foreground/20 backdrop-blur-sm flex flex-col items-center justify-center"
              >
                <ImageIcon size={24} className="text-white" />
                <span className="text-white text-[10px] mt-0.5">
                  {language === 'ar' ? 'معرض' : 'Gallery'}
                </span>
              </button>
              
              {/* Capture Button */}
              <button
                onClick={captureImage}
                disabled={isLoading}
                className="w-20 h-20 rounded-full border-4 border-white flex items-center justify-center"
              >
                <div className="w-16 h-16 rounded-full bg-amber-500 hover:bg-amber-400 transition-colors" />
              </button>
              
              {/* Spacer */}
              <div className="w-14" />
            </div>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>

        {isLoading && (
          <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
            <div className="text-center">
              <Loader2 size={48} className="animate-spin text-primary mx-auto mb-4" />
              <p className="text-white font-medium">{t('analyzing')}</p>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Analysis Result View (Meal Details)
  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col safe-top safe-bottom overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-card border-b border-border sticky top-0 z-10">
        <button onClick={retake} className="p-2">
          <X size={24} className="text-foreground" />
        </button>
        <h2 className="font-semibold text-foreground">
          {language === 'ar' ? 'تفاصيل الوجبة' : 'Meal Details'}
        </h2>
        <button className="p-2">
          <Heart 
            size={24} 
            className="text-muted-foreground hover:text-destructive transition-colors"
            onClick={addToFavorites}
          />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Food Image */}
        <div className="bg-muted p-4">
          <div className="aspect-video bg-card rounded-xl overflow-hidden flex items-center justify-center">
            {capturedImage ? (
              <img src={capturedImage} alt="Food" className="w-full h-full object-cover" />
            ) : (
              <span className="text-6xl">{analysisResult?.name.includes('Unknown') ? '🍽️' : '📸'}</span>
            )}
          </div>
        </div>

        {/* Food Name */}
        <div className="px-4 py-4 text-center">
          {isEditing ? (
            <input
              type="text"
              value={editedName}
              onChange={(e) => setEditedName(e.target.value)}
              className="text-2xl font-bold text-foreground bg-card border border-border rounded-lg px-4 py-2 text-center w-full"
              autoFocus
              onBlur={() => setIsEditing(false)}
            />
          ) : (
            <h1 className="text-2xl font-bold text-foreground">
              {language === 'ar' ? analysisResult?.nameAr || analysisResult?.name : analysisResult?.name}
            </h1>
          )}
          
          {/* Confidence & Wrong Food */}
          <div className="flex items-center justify-center gap-3 mt-2">
            <span className={`text-sm font-medium ${
              (analysisResult?.confidence || 0) >= 90 
                ? 'text-primary' 
                : (analysisResult?.confidence || 0) >= 70 
                  ? 'text-amber-500' 
                  : 'text-destructive'
            }`}>
              ✓ {analysisResult?.confidence}% {language === 'ar' ? 'تطابق' : 'Match'}
            </span>
            <button 
              onClick={() => setShowSearch(true)}
              className="text-sm text-muted-foreground hover:text-foreground"
            >
              {language === 'ar' ? 'طعام خاطئ؟' : 'Wrong Food?'}
            </button>
            <button 
              onClick={() => setIsEditing(true)}
              className="text-sm text-primary flex items-center gap-1"
            >
              <Edit2 size={12} />
              {language === 'ar' ? 'تعديل' : 'Edit'}
            </button>
          </div>
        </div>

        {/* Serving Size */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'حجم الحصة' : 'Serving Size'}
                </p>
                <p className="text-foreground font-medium">
                  {language === 'ar' ? `قطعة (تقريباً ${servingSize}غ)` : `Slice (approx. ${servingSize}g)`}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setServingCount(Math.max(0.25, servingCount - 0.25))}
                  className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80"
                >
                  <Minus size={20} className="text-foreground" />
                </button>
                <span className="text-xl font-bold text-foreground w-8 text-center">{servingCount}</span>
                <button 
                  onClick={() => setServingCount(servingCount + 0.25)}
                  className="w-10 h-10 rounded-full bg-primary flex items-center justify-center hover:bg-primary/90"
                >
                  <Plus size={20} className="text-primary-foreground" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Calories Card */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-6 border border-border text-center">
            <p className="text-6xl font-bold text-foreground">
              {analysisResult ? Math.round(analysisResult.calories * multiplier) : 0}
              <span className="text-2xl font-normal text-muted-foreground ml-1">kcal</span>
            </p>
            <p className="text-muted-foreground uppercase text-sm tracking-wider mt-1">
              {language === 'ar' ? 'السعرات الحرارية' : 'CALORIES'}
            </p>
          </div>
        </div>

        {/* Macros */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-carbs">
                  {analysisResult ? Math.round(analysisResult.carbs * multiplier) : 0}g
                </p>
                <div className="w-full h-1 bg-muted rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-carbs rounded-full" style={{ width: '45%' }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'ar' ? 'كربوهيدرات' : 'Carbs'}
                </p>
              </div>
              <div>
                <p className="text-2xl font-bold text-protein">
                  {analysisResult ? Math.round(analysisResult.protein * multiplier) : 0}g
                </p>
                <div className="w-full h-1 bg-muted rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-protein rounded-full" style={{ width: '20%' }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'ar' ? 'بروتين' : 'Protein'}
                </p>
              </div>
              <div>
                <p className="text-2xl font-bold text-fats">
                  {analysisResult ? Math.round(analysisResult.fat * multiplier) : 0}g
                </p>
                <div className="w-full h-1 bg-muted rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-fats rounded-full" style={{ width: '35%' }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'ar' ? 'دهون' : 'Fat'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Fats & Other */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <h3 className="font-semibold text-foreground mb-3">
              {language === 'ar' ? 'الدهون وغيرها' : 'Fats & Other'}
            </h3>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary" />
                <span className="text-muted-foreground">{language === 'ar' ? 'دهون مشبعة' : 'Saturated Fat'}</span>
                <span className="ml-auto font-medium text-foreground">3g</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-destructive" />
                <span className="text-muted-foreground">{language === 'ar' ? 'دهون متحولة' : 'Trans Fat'}</span>
                <span className="ml-auto font-medium text-foreground">0g</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-fats" />
                <span className="text-muted-foreground">{language === 'ar' ? 'ألياف' : 'Fiber'}</span>
                <span className="ml-auto font-medium text-foreground">{analysisResult?.fiber || 4}g</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-muted-foreground">{language === 'ar' ? 'سكر' : 'Sugar'}</span>
                <span className="ml-auto font-medium text-foreground">{analysisResult?.sugar || 2}g</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-carbs" />
                <span className="text-muted-foreground">{language === 'ar' ? 'فيتامين E' : 'Vitamin E'}</span>
                <span className="ml-auto font-medium text-foreground">{analysisResult?.vitamins?.A || 5}%</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-protein" />
                <span className="text-muted-foreground">{language === 'ar' ? 'بوتاسيوم' : 'Potassium'}</span>
                <span className="ml-auto font-medium text-foreground">{analysisResult?.minerals?.magnesium || 12}mg</span>
              </div>
            </div>
          </div>
        </div>

        {/* Vitamins & Minerals */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <h3 className="font-semibold text-foreground mb-3">
              {language === 'ar' ? 'الفيتامينات والمعادن' : 'Vitamins & Minerals'}
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{language === 'ar' ? 'حديد' : 'Iron'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-destructive rounded-full" style={{ width: `${analysisResult?.minerals?.iron || 12}%` }} />
                  </div>
                  <span className="text-foreground font-medium text-sm">{analysisResult?.minerals?.iron || 12}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{language === 'ar' ? 'كالسيوم' : 'Calcium'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-fats rounded-full" style={{ width: `${analysisResult?.minerals?.calcium || 20}%` }} />
                  </div>
                  <span className="text-foreground font-medium text-sm">{analysisResult?.minerals?.calcium || 20}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{language === 'ar' ? 'زنك' : 'Zinc'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-muted-foreground rounded-full" style={{ width: '15%' }} />
                  </div>
                  <span className="text-foreground font-medium text-sm">15%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{language === 'ar' ? 'مغنيسيوم' : 'Magnesium'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: `${analysisResult?.minerals?.magnesium || 10}%` }} />
                  </div>
                  <span className="text-foreground font-medium text-sm">{analysisResult?.minerals?.magnesium || 10}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Amino Acids */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <h3 className="font-semibold text-foreground mb-3">
              {language === 'ar' ? 'الأحماض الأمينية' : 'Amino Acids'}
            </h3>
            <div className="space-y-3">
              {['Leucine', 'Isoleucine', 'Valine', 'Lysine', 'Methionine'].map((acid, i) => (
                <div key={acid} className="flex items-center justify-between">
                  <span className="text-muted-foreground">
                    {language === 'ar' 
                      ? ['ليوسين', 'آيزوليوسين', 'فالين', 'ليسين', 'ميثيونين'][i] 
                      : acid}
                  </span>
                  <div className="flex items-center gap-2">
                    <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary rounded-full" 
                        style={{ width: `${[80, 60, 60, 50, 30][i]}%` }} 
                      />
                    </div>
                    <span className="text-foreground font-medium text-sm">{[3, 2, 2, 2, 1][i]}g</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Health Warnings - Enhanced */}
        {analysisResult && (
          <>
            {/* High Sugar/Salt Warning */}
            {((analysisResult.sugar && analysisResult.sugar > 10) || (analysisResult.salt && analysisResult.salt > 1.5)) && (
              <div className="px-4 pb-4">
                <div className="bg-warning/10 rounded-2xl p-4 border border-warning/30">
                  <div className="flex items-start gap-3">
                    <span className="text-2xl">⚠️</span>
                    <div>
                      <p className="font-semibold text-warning">
                        {language === 'ar' ? 'تحذير صحي' : 'Health Warning'}
                      </p>
                      {analysisResult.sugar && analysisResult.sugar > 10 && (
                        <p className="text-sm text-warning/80">
                          {language === 'ar' 
                            ? `سكر عالي (${analysisResult.sugar}g) - قد يزيد من خطر السكري`
                            : `High sugar (${analysisResult.sugar}g) - may increase diabetes risk`}
                        </p>
                      )}
                      {analysisResult.salt && analysisResult.salt > 1.5 && (
                        <p className="text-sm text-warning/80">
                          {language === 'ar'
                            ? `ملح عالي (${analysisResult.salt}g) - قد يزيد ضغط الدم`
                            : `High sodium (${analysisResult.salt}g) - may increase blood pressure`}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Serious Health Warnings */}
            {analysisResult?.warnings && analysisResult.warnings.length > 0 && (
              <div className="px-4 pb-4">
                <div className="bg-destructive/10 rounded-2xl p-4 border border-destructive/30">
                  <div className="flex items-start gap-3">
                    <span className="text-2xl">🚨</span>
                    <div>
                      <p className="font-semibold text-destructive">
                        {language === 'ar' ? 'تحذيرات صحية مهمة' : 'Important Health Warnings'}
                      </p>
                      {analysisResult.warnings.map((warning, i) => (
                        <p key={i} className="text-sm text-destructive/80 mt-1">• {warning}</p>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Dietary Insight - Only show if no warnings */}
            {(!analysisResult.warnings || analysisResult.warnings.length === 0) && 
             (!analysisResult.sugar || analysisResult.sugar <= 10) && 
             (!analysisResult.salt || analysisResult.salt <= 1.5) && (
              <div className="px-4 pb-4">
                <div className="bg-primary/10 rounded-2xl p-4 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <Sparkles size={16} className="text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">
                      {language === 'ar' ? 'نصيحة غذائية' : 'Dietary Insight'}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {language === 'ar' 
                        ? 'هذه الوجبة متوازنة ومناسبة لنظامك الغذائي' 
                        : 'This meal is balanced and suitable for your diet'}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        {/* Spacer for fixed button */}
        <div className="h-24" />
      </div>

      {/* Fixed Add Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-card border-t border-border safe-bottom">
        <button
          onClick={confirmMeal}
          className="w-full py-4 bg-primary text-primary-foreground rounded-2xl font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
        >
          <Plus size={20} />
          {language === 'ar' ? 'أضف إلى السجل اليومي' : 'Add to Daily Log'}
        </button>
      </div>
    </div>
  );
};
