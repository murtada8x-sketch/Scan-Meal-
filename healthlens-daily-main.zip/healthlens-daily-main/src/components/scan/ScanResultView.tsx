import { useState } from 'react';
import { X, Heart, Minus, Plus, Edit2, Sparkles, Search } from 'lucide-react';
import { Meal } from '@/types/nutrition';
import { FoodAnalysisResult } from '@/lib/gemini-api';
import { defaultRecipes } from '@/data/nutrition-data';

interface ScanResultViewProps {
  result: FoodAnalysisResult;
  capturedImage: string | null;
  language: string;
  onConfirm: (meal: Meal) => void;
  onRetake: () => void;
  onSaveToFavorites: () => void;
}

export const ScanResultView = ({
  result,
  capturedImage,
  language,
  onConfirm,
  onRetake,
  onSaveToFavorites,
}: ScanResultViewProps) => {
  const [servingCount, setServingCount] = useState(1);
  const [servingSize] = useState(100);
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(language === 'ar' ? result.nameAr || result.name : result.name);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentResult, setCurrentResult] = useState(result);

  const totalGrams = servingSize * servingCount;
  const multiplier = totalGrams / 100;

  const confirmMeal = () => {
    const meal: Meal = {
      id: Date.now().toString(),
      name: isEditing ? editedName : currentResult.name,
      nameAr: currentResult.nameAr,
      image: '📸',
      customImage: capturedImage || undefined,
      calories: Math.round(currentResult.calories * multiplier),
      protein: Math.round(currentResult.protein * multiplier),
      carbs: Math.round(currentResult.carbs * multiplier),
      fat: Math.round(currentResult.fat * multiplier),
      fiber: currentResult.fiber ? Math.round(currentResult.fiber * multiplier) : undefined,
      sugar: currentResult.sugar ? Math.round(currentResult.sugar * multiplier) : undefined,
      salt: currentResult.salt ? Math.round(currentResult.salt * multiplier) : undefined,
      vitamins: currentResult.vitamins,
      minerals: currentResult.minerals,
      acids: currentResult.acids,
      quantity: servingCount,
      timestamp: new Date(),
      type: currentResult.isBarcode ? 'barcode' : 'camera',
      servingGrams: totalGrams,
      confidence: currentResult.confidence,
      warnings: currentResult.warnings,
    };
    onConfirm(meal);
  };

  const selectFromSearch = (recipe: typeof defaultRecipes[0]) => {
    setCurrentResult({
      name: recipe.name,
      nameAr: recipe.nameAr,
      calories: recipe.calories,
      protein: recipe.protein,
      carbs: recipe.carbs,
      fat: recipe.fat,
      fiber: recipe.fiber,
      sugar: recipe.sugar,
      vitamins: recipe.vitamins || {},
      minerals: recipe.minerals || {},
      acids: {},
      confidence: 100,
    });
    setEditedName(language === 'ar' ? recipe.nameAr || recipe.name : recipe.name);
    setShowSearch(false);
  };

  const filteredRecipes = defaultRecipes.filter(r => 
    r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.nameAr?.includes(searchQuery)
  );

  // Search Overlay
  if (showSearch) {
    return (
      <div className="fixed inset-0 bg-background z-50 flex flex-col safe-top safe-bottom">
        <div className="flex items-center justify-between p-4 bg-card border-b border-border">
          <button onClick={() => setShowSearch(false)} className="p-2">
            <X size={24} className="text-foreground" />
          </button>
          <h2 className="font-semibold text-foreground">
            {language === 'ar' ? 'بحث' : 'Search'}
          </h2>
          <div className="w-10" />
        </div>
        <div className="p-4">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'ar' ? 'ابحث...' : 'Search...'}
            className="w-full bg-muted border border-border rounded-xl px-4 py-3 text-foreground"
            autoFocus
          />
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {filteredRecipes.map((recipe) => (
            <button
              key={recipe.id}
              onClick={() => selectFromSearch(recipe)}
              className="w-full bg-card rounded-xl p-3 flex items-center gap-3 text-start"
            >
              <span className="text-2xl">{recipe.image}</span>
              <div>
                <p className="font-medium text-foreground">
                  {language === 'ar' ? recipe.nameAr || recipe.name : recipe.name}
                </p>
                <p className="text-sm text-muted-foreground">{recipe.calories} kcal</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col safe-top safe-bottom overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-card border-b border-border sticky top-0 z-10">
        <button onClick={onRetake} className="p-2">
          <X size={24} className="text-foreground" />
        </button>
        <h2 className="font-semibold text-foreground">
          {language === 'ar' ? 'تفاصيل الوجبة' : 'Meal Details'}
        </h2>
        <button onClick={onSaveToFavorites} className="p-2">
          <Heart size={24} className="text-muted-foreground hover:text-destructive transition-colors" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Food Image */}
        <div className="bg-muted p-4">
          <div className="aspect-video bg-card rounded-xl overflow-hidden flex items-center justify-center">
            {capturedImage ? (
              <img src={capturedImage} alt="Food" className="w-full h-full object-cover" />
            ) : (
              <span className="text-6xl">🍽️</span>
            )}
          </div>
        </div>

        {/* Food Name */}
        <div className="px-4 py-4 text-center">
          {isEditing ? (
            <input
              type="text"
              value={editedName}
              onChange={(e) => setEditedName(e.target.value)}
              className="text-2xl font-bold text-foreground bg-card border border-border rounded-lg px-4 py-2 text-center w-full"
              autoFocus
              onBlur={() => setIsEditing(false)}
            />
          ) : (
            <h1 className="text-2xl font-bold text-foreground">
              {language === 'ar' ? currentResult.nameAr || currentResult.name : currentResult.name}
            </h1>
          )}
          
          <div className="flex items-center justify-center gap-3 mt-2">
            <span className={`text-sm font-medium ${
              (currentResult.confidence || 0) >= 90 
                ? 'text-primary' 
                : (currentResult.confidence || 0) >= 70 
                  ? 'text-amber-500' 
                  : 'text-destructive'
            }`}>
              ✓ {currentResult.confidence}% {language === 'ar' ? 'تطابق' : 'Match'}
            </span>
            <button 
              onClick={() => setShowSearch(true)}
              className="text-sm text-muted-foreground hover:text-foreground"
            >
              {language === 'ar' ? 'طعام خاطئ؟' : 'Wrong Food?'}
            </button>
            <button 
              onClick={() => setIsEditing(true)}
              className="text-sm text-primary flex items-center gap-1"
            >
              <Edit2 size={12} />
              {language === 'ar' ? 'تعديل' : 'Edit'}
            </button>
          </div>
        </div>

        {/* Serving Size */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'حجم الحصة' : 'Serving Size'}
                </p>
                <p className="text-foreground font-medium">{servingSize}g</p>
              </div>
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setServingCount(Math.max(0.25, servingCount - 0.25))}
                  className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80"
                >
                  <Minus size={20} className="text-foreground" />
                </button>
                <span className="text-xl font-bold text-foreground w-12 text-center">{servingCount}</span>
                <button 
                  onClick={() => setServingCount(servingCount + 0.25)}
                  className="w-10 h-10 rounded-full bg-primary flex items-center justify-center hover:bg-primary/90"
                >
                  <Plus size={20} className="text-primary-foreground" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Calories Card */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-6 border border-border text-center">
            <p className="text-6xl font-bold text-foreground">
              {Math.round(currentResult.calories * multiplier)}
              <span className="text-2xl font-normal text-muted-foreground ml-1">kcal</span>
            </p>
            <p className="text-muted-foreground uppercase text-sm tracking-wider mt-1">
              {language === 'ar' ? 'السعرات الحرارية' : 'CALORIES'}
            </p>
          </div>
        </div>

        {/* Macros */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-carbs">
                  {Math.round(currentResult.carbs * multiplier)}g
                </p>
                <div className="w-full h-1 bg-muted rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-carbs rounded-full" style={{ width: '45%' }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'ar' ? 'كربوهيدرات' : 'Carbs'}
                </p>
              </div>
              <div>
                <p className="text-2xl font-bold text-protein">
                  {Math.round(currentResult.protein * multiplier)}g
                </p>
                <div className="w-full h-1 bg-muted rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-protein rounded-full" style={{ width: '20%' }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'ar' ? 'بروتين' : 'Protein'}
                </p>
              </div>
              <div>
                <p className="text-2xl font-bold text-fats">
                  {Math.round(currentResult.fat * multiplier)}g
                </p>
                <div className="w-full h-1 bg-muted rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-fats rounded-full" style={{ width: '35%' }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'ar' ? 'دهون' : 'Fat'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Fats & Other */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <h3 className="font-semibold text-foreground mb-3">
              {language === 'ar' ? 'الدهون وغيرها' : 'Fats & Other'}
            </h3>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-fats" />
                <span className="text-muted-foreground">{language === 'ar' ? 'ألياف' : 'Fiber'}</span>
                <span className="ml-auto font-medium text-foreground">{currentResult.fiber || 4}g</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-muted-foreground">{language === 'ar' ? 'سكر' : 'Sugar'}</span>
                <span className="ml-auto font-medium text-foreground">{currentResult.sugar || 2}g</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-muted-foreground" />
                <span className="text-muted-foreground">{language === 'ar' ? 'ملح' : 'Salt'}</span>
                <span className="ml-auto font-medium text-foreground">{currentResult.salt || 0.5}g</span>
              </div>
            </div>
          </div>
        </div>

        {/* Vitamins & Minerals */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <h3 className="font-semibold text-foreground mb-3">
              {language === 'ar' ? 'الفيتامينات والمعادن' : 'Vitamins & Minerals'}
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{language === 'ar' ? 'فيتامين A' : 'Vitamin A'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: `${currentResult.vitamins?.A || 10}%` }} />
                  </div>
                  <span className="text-foreground font-medium text-sm">{currentResult.vitamins?.A || 10}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{language === 'ar' ? 'فيتامين C' : 'Vitamin C'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-vitamins rounded-full" style={{ width: `${currentResult.vitamins?.C || 15}%` }} />
                  </div>
                  <span className="text-foreground font-medium text-sm">{currentResult.vitamins?.C || 15}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{language === 'ar' ? 'فيتامين D' : 'Vitamin D'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-warning rounded-full" style={{ width: `${currentResult.vitamins?.D || 5}%` }} />
                  </div>
                  <span className="text-foreground font-medium text-sm">{currentResult.vitamins?.D || 5}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{language === 'ar' ? 'حديد' : 'Iron'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-destructive rounded-full" style={{ width: `${currentResult.minerals?.iron || 12}%` }} />
                  </div>
                  <span className="text-foreground font-medium text-sm">{currentResult.minerals?.iron || 12}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{language === 'ar' ? 'كالسيوم' : 'Calcium'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-fats rounded-full" style={{ width: `${currentResult.minerals?.calcium || 20}%` }} />
                  </div>
                  <span className="text-foreground font-medium text-sm">{currentResult.minerals?.calcium || 20}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{language === 'ar' ? 'مغنيسيوم' : 'Magnesium'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: `${currentResult.minerals?.magnesium || 10}%` }} />
                  </div>
                  <span className="text-foreground font-medium text-sm">{currentResult.minerals?.magnesium || 10}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Amino Acids */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <h3 className="font-semibold text-foreground mb-3">
              {language === 'ar' ? 'الأحماض الأمينية' : 'Amino Acids'}
            </h3>
            <div className="space-y-3">
              {['Omega-3', 'Leucine', 'Isoleucine', 'Valine'].map((acid, i) => (
                <div key={acid} className="flex items-center justify-between">
                  <span className="text-muted-foreground">
                    {language === 'ar' 
                      ? ['أوميغا-3', 'ليوسين', 'آيزوليوسين', 'فالين'][i] 
                      : acid}
                  </span>
                  <div className="flex items-center gap-2">
                    <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary rounded-full" 
                        style={{ width: `${[30, 80, 60, 60][i]}%` }} 
                      />
                    </div>
                    <span className="text-foreground font-medium text-sm">
                      {i === 0 ? `${currentResult.acids?.omega3 || 50}mg` : `${[3, 2, 2][i-1]}g`}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Health Warnings */}
        {((currentResult.sugar && currentResult.sugar > 10) || (currentResult.salt && currentResult.salt > 1.5)) && (
          <div className="px-4 pb-4">
            <div className="bg-warning/10 rounded-2xl p-4 border border-warning/30">
              <div className="flex items-start gap-3">
                <span className="text-2xl">⚠️</span>
                <div>
                  <p className="font-semibold text-warning">
                    {language === 'ar' ? 'تحذير صحي' : 'Health Warning'}
                  </p>
                  {currentResult.sugar && currentResult.sugar > 10 && (
                    <p className="text-sm text-warning/80">
                      {language === 'ar' 
                        ? `سكر عالي (${currentResult.sugar}g) - قد يزيد من خطر السكري`
                        : `High sugar (${currentResult.sugar}g) - may increase diabetes risk`}
                    </p>
                  )}
                  {currentResult.salt && currentResult.salt > 1.5 && (
                    <p className="text-sm text-warning/80">
                      {language === 'ar'
                        ? `ملح عالي (${currentResult.salt}g) - قد يزيد ضغط الدم`
                        : `High sodium (${currentResult.salt}g) - may increase blood pressure`}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {currentResult?.warnings && currentResult.warnings.length > 0 && (
          <div className="px-4 pb-4">
            <div className="bg-destructive/10 rounded-2xl p-4 border border-destructive/30">
              <div className="flex items-start gap-3">
                <span className="text-2xl">🚨</span>
                <div>
                  <p className="font-semibold text-destructive">
                    {language === 'ar' ? 'تحذيرات صحية مهمة' : 'Important Health Warnings'}
                  </p>
                  {currentResult.warnings.map((warning, i) => (
                    <p key={i} className="text-sm text-destructive/80 mt-1">• {warning}</p>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Dietary Insight */}
        {(!currentResult.warnings || currentResult.warnings.length === 0) && 
         (!currentResult.sugar || currentResult.sugar <= 10) && 
         (!currentResult.salt || currentResult.salt <= 1.5) && (
          <div className="px-4 pb-4">
            <div className="bg-primary/10 rounded-2xl p-4 flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Sparkles size={16} className="text-primary" />
              </div>
              <div>
                <h4 className="font-semibold text-foreground">
                  {language === 'ar' ? 'نصيحة غذائية' : 'Dietary Insight'}
                </h4>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' 
                    ? 'هذه الوجبة متوازنة ومناسبة لنظامك الغذائي' 
                    : 'This meal is balanced and suitable for your diet'}
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="h-24" />
      </div>

      {/* Fixed Add Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-card border-t border-border safe-bottom">
        <button
          onClick={confirmMeal}
          className="w-full py-4 bg-primary text-primary-foreground rounded-2xl font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
        >
          <Plus size={20} />
          {language === 'ar' ? 'أضف إلى السجل اليومي' : 'Add to Daily Log'}
        </button>
      </div>
    </div>
  );
};
