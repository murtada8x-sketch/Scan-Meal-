import { useState, useRef, useEffect } from 'react';
import { X, Loader2, Check, Upload, Edit2, Heart, AlertTriangle, Minus, Plus, Sparkles, Image as ImageIcon, Barcode } from 'lucide-react';
import { useNutrition } from '@/contexts/NutritionContext';
import { Meal, PartialMeal } from '@/types/nutrition';
import { barcodeProducts } from '@/data/nutrition-data';
import { analyzeBarcodeImage } from '@/lib/gemini-api';

interface BarcodeScannerProps {
  onClose: () => void;
  onProductScanned: (meal: Meal) => void;
}

export const BarcodeScanner = ({ onClose, onProductScanned }: BarcodeScannerProps) => {
  const { language, t, addFavorite, addPartialMeal } = useNutrition();
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isScanning, setIsScanning] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [scannedProduct, setScannedProduct] = useState<Partial<Meal> | null>(null);
  const [quantity, setQuantity] = useState<0.25 | 0.5 | 1>(1);
  const [manualBarcode, setManualBarcode] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState('');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (error) {
        console.error('Camera access denied:', error);
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const captureAndScan = async () => {
    if (!videoRef.current) return;
    
    setIsLoading(true);
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      setCapturedImage(dataUrl);
      
      // Try to detect barcode using Gemini
      const barcode = await analyzeBarcodeImage(dataUrl);
      if (barcode) {
        handleBarcodeDetected(barcode);
      } else {
        // Simulate scanning if no barcode detected
        const barcodes = Object.keys(barcodeProducts);
        if (barcodes.length > 0) {
          const randomBarcode = barcodes[Math.floor(Math.random() * barcodes.length)];
          handleBarcodeDetected(randomBarcode);
        }
      }
    }
    setIsLoading(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const dataUrl = reader.result as string;
      setCapturedImage(dataUrl);
      
      const barcode = await analyzeBarcodeImage(dataUrl);
      if (barcode) {
        handleBarcodeDetected(barcode);
      } else {
        // No barcode found, use demo data
        const barcodes = Object.keys(barcodeProducts);
        if (barcodes.length > 0) {
          handleBarcodeDetected(barcodes[0]);
        }
      }
      setIsLoading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleBarcodeDetected = (barcode: string) => {
    const product = barcodeProducts[barcode];
    if (product) {
      setScannedProduct({ ...product, barcode });
      setEditedName(language === 'ar' ? product.nameAr || product.name || '' : product.name || '');
      setIsScanning(false);
    } else {
      // Unknown product
      setScannedProduct({
        name: 'Unknown Product',
        nameAr: 'منتج غير معروف',
        barcode,
        calories: 150,
        protein: 5,
        carbs: 20,
        fat: 5,
        sugar: 8,
        salt: 0.5,
        servingSize: '1 serving',
        servingGrams: 100,
      });
      setEditedName(language === 'ar' ? 'منتج غير معروف' : 'Unknown Product');
      setIsScanning(false);
    }
  };

  const handleManualEntry = () => {
    if (manualBarcode) {
      handleBarcodeDetected(manualBarcode);
    }
  };

  const confirmProduct = () => {
    if (!scannedProduct) return;

    const finalName = isEditing ? editedName : (language === 'ar' ? scannedProduct.nameAr : scannedProduct.name) || 'Product';

    // If quantity is less than 1, add as partial meal
    if (quantity < 1) {
      const partialMeal: PartialMeal = {
        id: Date.now().toString(),
        name: finalName,
        nameAr: scannedProduct.nameAr,
        image: '📊',
        customImage: capturedImage || undefined,
        calories: scannedProduct.calories || 0,
        protein: scannedProduct.protein || 0,
        carbs: scannedProduct.carbs || 0,
        fat: scannedProduct.fat || 0,
        sugar: scannedProduct.sugar,
        salt: scannedProduct.salt,
        servingSize: scannedProduct.servingSize,
        servingGrams: scannedProduct.servingGrams,
        timestamp: new Date(),
        type: 'barcode',
        barcode: scannedProduct.barcode,
        totalPortion: 1,
        remainingPortion: 1 - quantity,
        consumedDates: [{ date: new Date().toISOString(), portion: quantity }],
      };
      addPartialMeal(partialMeal);
    }

    const meal: Meal = {
      id: Date.now().toString(),
      name: finalName,
      nameAr: scannedProduct.nameAr,
      image: '📊',
      customImage: capturedImage || undefined,
      calories: Math.round((scannedProduct.calories || 0) * quantity),
      protein: Math.round((scannedProduct.protein || 0) * quantity),
      carbs: Math.round((scannedProduct.carbs || 0) * quantity),
      fat: Math.round((scannedProduct.fat || 0) * quantity),
      sugar: scannedProduct.sugar ? Math.round(scannedProduct.sugar * quantity) : undefined,
      salt: scannedProduct.salt ? Math.round(scannedProduct.salt * quantity * 10) / 10 : undefined,
      quantity: 1,
      timestamp: new Date(),
      type: 'barcode',
      servingSize: scannedProduct.servingSize,
      servingGrams: scannedProduct.servingGrams,
      barcode: scannedProduct.barcode,
    };

    onProductScanned(meal);
  };

  const addToFavorites = () => {
    if (!scannedProduct) return;
    addFavorite({
      id: Date.now().toString(),
      name: scannedProduct.name || 'Product',
      nameAr: scannedProduct.nameAr,
      image: capturedImage || undefined,
      barcode: scannedProduct.barcode,
      calories: scannedProduct.calories || 0,
      protein: scannedProduct.protein || 0,
      carbs: scannedProduct.carbs || 0,
      fat: scannedProduct.fat || 0,
      sugar: scannedProduct.sugar,
      salt: scannedProduct.salt,
      servingSize: scannedProduct.servingSize,
      servingGrams: scannedProduct.servingGrams,
    });
  };

  const rescan = () => {
    setScannedProduct(null);
    setIsScanning(true);
    setQuantity(1);
    setManualBarcode('');
    setIsEditing(false);
    setCapturedImage(null);
  };

  // Check for health warnings
  const getWarnings = () => {
    const warnings: string[] = [];
    if (scannedProduct) {
      if ((scannedProduct.sugar || 0) > 20) {
        warnings.push(language === 'ar' ? 'نسبة سكر عالية' : 'High sugar content');
      }
      if ((scannedProduct.salt || 0) > 2) {
        warnings.push(language === 'ar' ? 'نسبة ملح عالية - قد يزيد خطر ارتفاع ضغط الدم' : 'High sodium - may increase blood pressure risk');
      }
    }
    return warnings;
  };

  const warnings = getWarnings();

  // Camera View (Scanning)
  if (isScanning && !scannedProduct) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex flex-col">
        {/* Camera Preview */}
        <div className="flex-1 relative">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
          
          {/* Top Controls */}
          <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between safe-top">
            <button 
              onClick={onClose} 
              className="w-12 h-12 rounded-full bg-foreground/20 backdrop-blur-sm flex items-center justify-center"
            >
              <X size={24} className="text-white" />
            </button>
            <div className="flex gap-3">
              <button className="w-12 h-12 rounded-full bg-foreground/20 backdrop-blur-sm flex items-center justify-center">
                <Sparkles size={24} className="text-white" />
              </button>
              <button className="w-12 h-12 rounded-full bg-foreground/20 backdrop-blur-sm flex items-center justify-center">
                <Barcode size={24} className="text-white" />
              </button>
            </div>
          </div>

          {/* Scanning Frame - Smaller */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-64 h-40 relative">
              {/* Corner brackets - yellow/orange color */}
              <div className="absolute top-0 left-0 w-10 h-10 border-t-4 border-l-4 border-amber-500 rounded-tl-xl" />
              <div className="absolute top-0 right-0 w-10 h-10 border-t-4 border-r-4 border-amber-500 rounded-tr-xl" />
              <div className="absolute bottom-0 left-0 w-10 h-10 border-b-4 border-l-4 border-amber-500 rounded-bl-xl" />
              <div className="absolute bottom-0 right-0 w-10 h-10 border-b-4 border-r-4 border-amber-500 rounded-br-xl" />
              
              {/* Scanning line animation */}
              <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-amber-500 animate-pulse" />
              
              {/* Center focus point */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                <div className="w-4 h-4 rounded-full border-2 border-amber-500 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                </div>
              </div>
            </div>
          </div>

          {/* Instruction Text */}
          <div className="absolute bottom-40 left-0 right-0 text-center px-4">
            <p className="text-white/90 text-sm font-medium">
              {language === 'ar' 
                ? 'ضع الباركود داخل الإطار لمسح المنتج' 
                : 'Align barcode within the frame to scan'}
            </p>
          </div>

          {/* Bottom Controls */}
          <div className="absolute bottom-0 left-0 right-0 p-6 safe-bottom">
            <div className="flex items-center justify-center gap-6">
              {/* Gallery Button */}
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="w-14 h-14 rounded-full bg-foreground/20 backdrop-blur-sm flex flex-col items-center justify-center"
              >
                <ImageIcon size={24} className="text-white" />
                <span className="text-white text-[10px] mt-0.5">
                  {language === 'ar' ? 'معرض' : 'Gallery'}
                </span>
              </button>
              
              {/* Capture Button */}
              <button
                onClick={captureAndScan}
                disabled={isLoading}
                className="w-20 h-20 rounded-full border-4 border-white flex items-center justify-center"
              >
                <div className="w-16 h-16 rounded-full bg-amber-500 hover:bg-amber-400 transition-colors" />
              </button>
              
              {/* Spacer */}
              <div className="w-14" />
            </div>

            {/* Manual Entry */}
            <div className="mt-4 flex gap-2">
              <input
                type="text"
                value={manualBarcode}
                onChange={(e) => setManualBarcode(e.target.value)}
                placeholder={language === 'ar' ? 'أدخل الباركود يدوياً' : 'Enter barcode manually'}
                className="flex-1 bg-foreground/20 backdrop-blur-sm border-0 rounded-xl px-4 py-3 text-white placeholder:text-white/60 text-center"
              />
              <button
                onClick={handleManualEntry}
                disabled={!manualBarcode}
                className="px-4 py-3 bg-primary text-primary-foreground rounded-xl font-medium disabled:opacity-50"
              >
                {language === 'ar' ? 'بحث' : 'Search'}
              </button>
            </div>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>

        {isLoading && (
          <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
            <div className="text-center">
              <Loader2 size={48} className="animate-spin text-primary mx-auto mb-4" />
              <p className="text-white font-medium">{t('analyzing')}</p>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Product Result View
  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col safe-top safe-bottom overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-card border-b border-border sticky top-0 z-10">
        <button onClick={rescan} className="p-2">
          <X size={24} className="text-foreground" />
        </button>
        <h2 className="font-semibold text-foreground">
          {language === 'ar' ? 'تفاصيل المنتج' : 'Product Details'}
        </h2>
        <button className="p-2" onClick={addToFavorites}>
          <Heart size={24} className="text-muted-foreground hover:text-destructive transition-colors" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Product Image */}
        <div className="bg-muted p-4">
          <div className="aspect-video bg-card rounded-xl overflow-hidden flex items-center justify-center">
            {capturedImage ? (
              <img src={capturedImage} alt="Product" className="w-full h-full object-cover" />
            ) : (
              <span className="text-6xl">📊</span>
            )}
          </div>
        </div>

        {/* Product Name */}
        <div className="px-4 py-4 text-center">
          {isEditing ? (
            <input
              type="text"
              value={editedName}
              onChange={(e) => setEditedName(e.target.value)}
              className="text-2xl font-bold text-foreground bg-card border border-border rounded-lg px-4 py-2 text-center w-full"
              autoFocus
              onBlur={() => setIsEditing(false)}
            />
          ) : (
            <h1 className="text-2xl font-bold text-foreground">
              {language === 'ar' ? scannedProduct?.nameAr || scannedProduct?.name : scannedProduct?.name}
            </h1>
          )}
          
          {/* Serving info & Edit */}
          <div className="flex items-center justify-center gap-3 mt-2">
            <span className="text-sm bg-primary/10 text-primary px-2 py-1 rounded-full">
              {scannedProduct?.servingSize}
            </span>
            <button 
              onClick={() => setIsEditing(true)}
              className="text-sm text-primary flex items-center gap-1"
            >
              <Edit2 size={12} />
              {language === 'ar' ? 'تعديل الاسم' : 'Edit Name'}
            </button>
          </div>
        </div>

        {/* Quantity Selector */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <p className="text-sm text-muted-foreground mb-3 text-center">
              {language === 'ar' ? 'حدد الكمية المستهلكة' : 'Select consumed portion'}
            </p>
            <div className="flex gap-2">
              {([0.25, 0.5, 1] as const).map((q) => (
                <button
                  key={q}
                  onClick={() => setQuantity(q)}
                  className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-colors ${
                    quantity === q 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-muted text-foreground hover:bg-muted/80'
                  }`}
                >
                  {q === 1 
                    ? (language === 'ar' ? 'كامل' : 'Full')
                    : q === 0.5 
                      ? (language === 'ar' ? 'نصف' : 'Half')
                      : (language === 'ar' ? 'ربع' : 'Quarter')}
                </button>
              ))}
            </div>
            {quantity < 1 && (
              <p className="text-xs text-muted-foreground mt-2 text-center">
                {language === 'ar' 
                  ? 'سيتم حفظ الباقي لإضافته لاحقاً' 
                  : 'Remaining will be saved for later'}
              </p>
            )}
          </div>
        </div>

        {/* Warnings */}
        {warnings.length > 0 && (
          <div className="px-4 pb-4">
            <div className="bg-destructive/10 rounded-2xl p-4">
              <div className="flex items-center gap-2 text-destructive font-semibold mb-1">
                <AlertTriangle size={18} />
                {language === 'ar' ? 'تحذير صحي' : 'Health Warning'}
              </div>
              {warnings.map((warning, i) => (
                <p key={i} className="text-sm text-destructive">{warning}</p>
              ))}
            </div>
          </div>
        )}

        {/* Full Product Nutrition */}
        <div className="px-4 pb-4">
          <p className="text-xs text-muted-foreground mb-2 text-center">
            {language === 'ar' ? 'القيم الغذائية للمنتج كاملاً:' : 'Nutrition for full product:'}
          </p>
          <div className="bg-card rounded-2xl p-6 border border-border text-center">
            <p className="text-5xl font-bold text-foreground">
              {scannedProduct?.calories || 0}
              <span className="text-xl font-normal text-muted-foreground ml-1">kcal</span>
            </p>
            <p className="text-muted-foreground uppercase text-sm tracking-wider mt-1">
              {language === 'ar' ? 'السعرات الحرارية' : 'CALORIES'}
            </p>
          </div>
        </div>

        {/* Macros */}
        <div className="px-4 pb-4">
          <div className="bg-card rounded-2xl p-4 border border-border">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-carbs">{scannedProduct?.carbs || 0}g</p>
                <div className="w-full h-1 bg-muted rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-carbs rounded-full" style={{ width: '45%' }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">{language === 'ar' ? 'كربوهيدرات' : 'Carbs'}</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-protein">{scannedProduct?.protein || 0}g</p>
                <div className="w-full h-1 bg-muted rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-protein rounded-full" style={{ width: '20%' }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">{language === 'ar' ? 'بروتين' : 'Protein'}</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-fats">{scannedProduct?.fat || 0}g</p>
                <div className="w-full h-1 bg-muted rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-fats rounded-full" style={{ width: '35%' }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">{language === 'ar' ? 'دهون' : 'Fat'}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Sugar and Salt */}
        {(scannedProduct?.sugar !== undefined || scannedProduct?.salt !== undefined) && (
          <div className="px-4 pb-4">
            <div className="bg-card rounded-2xl p-4 border border-border">
              <div className="grid grid-cols-2 gap-4">
                {scannedProduct.sugar !== undefined && (
                  <div className={`rounded-xl p-4 text-center ${(scannedProduct.sugar || 0) > 15 ? 'bg-destructive/10' : 'bg-muted'}`}>
                    <span className="text-3xl">🍬</span>
                    <p className={`text-2xl font-bold mt-1 ${(scannedProduct.sugar || 0) > 15 ? 'text-destructive' : 'text-foreground'}`}>
                      {scannedProduct.sugar}g
                    </p>
                    <p className="text-xs text-muted-foreground">{language === 'ar' ? 'سكر' : 'Sugar'}</p>
                  </div>
                )}
                {scannedProduct.salt !== undefined && (
                  <div className={`rounded-xl p-4 text-center ${(scannedProduct.salt || 0) > 1.5 ? 'bg-destructive/10' : 'bg-muted'}`}>
                    <span className="text-3xl">🧂</span>
                    <p className={`text-2xl font-bold mt-1 ${(scannedProduct.salt || 0) > 1.5 ? 'text-destructive' : 'text-foreground'}`}>
                      {scannedProduct.salt}g
                    </p>
                    <p className="text-xs text-muted-foreground">{language === 'ar' ? 'ملح' : 'Salt'}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* What you'll consume */}
        {quantity !== 1 && (
          <div className="px-4 pb-4">
            <div className="bg-primary/10 rounded-2xl p-4">
              <p className="text-sm font-semibold text-foreground mb-2 text-center">
                {language === 'ar' ? 'ما ستستهلكه الآن:' : "What you'll consume:"}
              </p>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="bg-card rounded-lg p-2">
                  <p className="font-bold text-foreground">{Math.round((scannedProduct?.calories || 0) * quantity)}</p>
                  <p className="text-xs text-muted-foreground">kcal</p>
                </div>
                <div className="bg-card rounded-lg p-2">
                  <p className="font-bold text-protein">{Math.round((scannedProduct?.protein || 0) * quantity)}g</p>
                  <p className="text-xs text-muted-foreground">{language === 'ar' ? 'بروتين' : 'Protein'}</p>
                </div>
                <div className="bg-card rounded-lg p-2">
                  <p className="font-bold text-carbs">{Math.round((scannedProduct?.carbs || 0) * quantity)}g</p>
                  <p className="text-xs text-muted-foreground">{language === 'ar' ? 'كربوهيدرات' : 'Carbs'}</p>
                </div>
                <div className="bg-card rounded-lg p-2">
                  <p className="font-bold text-fats">{Math.round((scannedProduct?.fat || 0) * quantity)}g</p>
                  <p className="text-xs text-muted-foreground">{language === 'ar' ? 'دهون' : 'Fat'}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Spacer for fixed button */}
        <div className="h-24" />
      </div>

      {/* Fixed Add Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-card border-t border-border safe-bottom">
        <button
          onClick={confirmProduct}
          className="w-full py-4 bg-primary text-primary-foreground rounded-2xl font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
        >
          <Plus size={20} />
          {language === 'ar' ? 'أضف إلى السجل اليومي' : 'Add to Daily Log'}
        </button>
      </div>
    </div>
  );
};
