import { X, Crown, Camera, Bot, BarChart3, Utensils, MessageCircle, FileDown } from 'lucide-react';

interface PremiumPageProps {
  language: string;
  onClose: () => void;
}

export const PremiumPage = ({ language, onClose }: PremiumPageProps) => {
  const isArabic = language === 'ar';
  
  const features = [
    { icon: Camera, label: isArabic ? 'مسح غير محدود للوجبات' : 'Unlimited meal scans' },
    { icon: Bot, label: isArabic ? 'تعرف متقدم على الطعام بالذكاء الاصطناعي' : 'Advanced AI food recognition' },
    { icon: BarChart3, label: isArabic ? 'تقارير تغذية مفصلة' : 'Detailed nutrition reports' },
    { icon: Utensils, label: isArabic ? 'خطط وجبات مخصصة' : 'Custom meal plans' },
    { icon: MessageCircle, label: isArabic ? 'دعم ذو أولوية' : 'Priority support' },
    { icon: FileDown, label: isArabic ? 'تصدير البيانات والتقارير' : 'Export data & reports' },
  ];

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col safe-top safe-bottom overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-card border-b border-border">
        <button onClick={onClose} className="p-2">
          <X size={24} className="text-foreground" />
        </button>
        <h2 className="font-semibold text-foreground">Premium</h2>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        {/* Crown Icon */}
        <div className="flex justify-center mb-6">
          <div className="w-24 h-24 rounded-3xl bg-primary flex items-center justify-center">
            <Crown size={48} className="text-primary-foreground" />
          </div>
        </div>

        {/* Title */}
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-foreground mb-2">
            {isArabic ? 'ترقية إلى بريميوم' : 'Upgrade to Premium'}
          </h1>
          <p className="text-muted-foreground">
            {isArabic ? 'افتح جميع الميزات وحقق أهدافك' : 'Unlock all features and achieve your goals'}
          </p>
        </div>

        {/* Pricing Options */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <button className="bg-card border-2 border-border rounded-2xl p-4 text-center hover:border-muted-foreground transition-colors">
            <p className="text-sm text-muted-foreground mb-1">
              {isArabic ? 'شهري' : 'Monthly'}
            </p>
            <p className="text-3xl font-bold text-foreground">$7</p>
            <p className="text-xs text-muted-foreground">/{isArabic ? 'شهر' : 'month'}</p>
          </button>
          
          <button className="bg-card border-2 border-primary rounded-2xl p-4 text-center relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs px-3 py-1 rounded-full font-medium flex items-center gap-1">
              ✨ {isArabic ? 'وفر 5%' : 'Save 5%'}
            </div>
            <p className="text-sm text-muted-foreground mb-1">
              {isArabic ? 'سنوي' : 'Yearly'}
            </p>
            <p className="text-3xl font-bold text-foreground">$80</p>
            <p className="text-xs text-muted-foreground">/{isArabic ? 'سنة' : 'year'}</p>
          </button>
        </div>

        {/* Features List */}
        <div className="bg-card rounded-2xl p-5 card-shadow mb-8">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-primary">⚡</span>
            <h3 className="font-semibold text-foreground">
              {isArabic ? 'ميزات بريميوم' : 'Premium Features'}
            </h3>
          </div>
          
          <div className="space-y-4">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                  <feature.icon size={20} className="text-foreground" />
                </div>
                <span className="text-foreground">{feature.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Subscribe Button */}
      <div className="p-4 bg-card border-t border-border safe-bottom">
        <button className="w-full py-4 bg-primary text-primary-foreground rounded-2xl font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
          <Crown size={20} />
          {isArabic ? 'اشترك مقابل $80/سنة' : 'Subscribe for $80/year'}
        </button>
        <p className="text-center text-xs text-muted-foreground mt-3">
          {isArabic ? 'إلغاء في أي وقت. لا يوجد التزام.' : 'Cancel anytime. No commitment required.'}
        </p>
      </div>
    </div>
  );
};
