export interface Meal {
  id: string;
  name: string;
  nameAr?: string;
  image?: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber?: number;
  sugar?: number;
  salt?: number;
  vitamins?: {
    A?: number;
    B1?: number;
    B2?: number;
    B3?: number;
    B6?: number;
    B12?: number;
    C?: number;
    D?: number;
    E?: number;
    K?: number;
  };
  minerals?: {
    iron?: number;
    calcium?: number;
    zinc?: number;
    magnesium?: number;
    potassium?: number;
  };
  aminoAcids?: {
    leucine?: number;
    isoleucine?: number;
    valine?: number;
    lysine?: number;
    methionine?: number;
    phenylalanine?: number;
    threonine?: number;
    tryptophan?: number;
    histidine?: number;
  };
  acids?: {
    omega3?: number;
    omega6?: number;
  };
  servingSize?: string;
  servingGrams?: number;
  quantity: number;
  timestamp: Date;
  type: 'camera' | 'barcode' | 'manual' | 'recipe';
  barcode?: string;
  confidence?: number;
  warnings?: string[];
  customImage?: string;
}

export interface PartialMeal extends Omit<Meal, 'quantity'> {
  totalPortion: number;
  remainingPortion: number;
  consumedDates: { date: string; portion: number }[];
}

export interface FavoriteProduct {
  id: string;
  name: string;
  nameAr?: string;
  image?: string;
  barcode?: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  sugar?: number;
  salt?: number;
  servingSize?: string;
  servingGrams?: number;
}

export interface Recipe {
  id: string;
  name: string;
  nameAr?: string;
  image?: string;
  ingredients: string[];
  ingredientsAr?: string[];
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber?: number;
  sugar?: number;
  vitamins?: Meal['vitamins'];
  minerals?: Meal['minerals'];
  aminoAcids?: Meal['aminoAcids'];
  servingSize?: string;
  servingGrams?: number;
  instructions?: string[];
  instructionsAr?: string[];
  prepTime?: number;
  cookTime?: number;
  category?: string;
}

export interface UserProfile {
  name: string;
  weight: number; // kg
  height: number; // cm
  age: number;
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'veryActive';
  gender: 'male' | 'female';
  dailyCalorieGoal: number;
  dailyWaterGoal: number; // ml
  waterCupSize: number; // ml
  sleepStart: string; // HH:mm format
  sleepEnd: string; // HH:mm format
  customFastingHours?: number;
  dailySugarLimit?: number; // grams
  dailySaltLimit?: number; // grams
}

export interface DailyLog {
  date: string;
  meals: Meal[];
  waterIntake: number; // ml
  steps: number;
  caloriesBurned: number;
  complianceScore?: number;
}

export interface FastingSession {
  id: string;
  startTime: Date;
  duration: number; // hours
  endTime: Date;
  isActive: boolean;
}

export interface WaterReminder {
  id: string;
  time: string;
  enabled: boolean;
}

export interface FastingStage {
  hours: number;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  icon: string;
}

export type TabType = 'home' | 'reports' | 'scan' | 'recipes' | 'profile';
export type ReportTab = 'overview' | 'protein' | 'carbs' | 'fats' | 'vitamins' | 'amino' | 'hydration' | 'compliance';
