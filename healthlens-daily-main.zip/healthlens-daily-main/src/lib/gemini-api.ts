// Gemini API Integration for Food Recognition

const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || 'AIzaSyBhL9b_Nckz-AzEjCTfULS2k8T0VVwBA3Q';
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

export interface FoodAnalysisResult {
  name: string;
  nameAr?: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber?: number;
  sugar?: number;
  salt?: number;
  vitamins: {
    A?: number;
    C?: number;
    D?: number;
    B12?: number;
  };
  minerals: {
    calcium?: number;
    iron?: number;
    magnesium?: number;
  };
  acids: {
    omega3?: number;
  };
  confidence: number;
  warnings?: string[];
  isBarcode?: boolean;
  barcode?: string;
  brand?: string;
  productionDate?: string;
  expirationDate?: string;
  labels?: string[];
  healthRating?: number;
}

const SYSTEM_PROMPT = `You are a nutrition analysis AI. Analyze the food product image (or barcode) with precision to extract:

1. Product name and brand
2. Production date (P) and expiration date (E) if visible
3. Complete nutritional values per 100g:
   - Calories, protein, carbohydrates, fat, fiber, sugar, salt
   - Saturated fat, trans fat
4. Ingredients analysis: clearly identify any hydrogenated oils, preservatives, or excessively high sugar content
5. Labels: halal, vegan, gluten-free, organic if applicable
6. Overall health rating from 1-10

Return ONLY a valid JSON object with this structure:
{
  "name": "Food name in English",
  "nameAr": "اسم الطعام بالعربية",
  "brand": "Brand name if visible",
  "calories": number (per 100g),
  "protein": number (grams per 100g),
  "carbs": number (grams per 100g),
  "fat": number (grams per 100g),
  "fiber": number (grams per 100g),
  "sugar": number (grams per 100g),
  "salt": number (grams per 100g),
  "saturatedFat": number (grams per 100g),
  "transFat": number (grams per 100g),
  "vitamins": {
    "A": number (% daily value),
    "C": number (% daily value),
    "D": number (% daily value),
    "B12": number (% daily value)
  },
  "minerals": {
    "calcium": number (% daily value),
    "iron": number (% daily value),
    "magnesium": number (% daily value)
  },
  "acids": {
    "omega3": number (mg per 100g)
  },
  "confidence": number (0-100, your confidence in the identification),
  "warnings": ["array of health warnings based on medical guidelines"],
  "isBarcode": boolean (true if image contains a barcode),
  "barcode": "barcode number if detected",
  "productionDate": "production date if visible",
  "expirationDate": "expiration date if visible",
  "labels": ["halal", "vegan", "gluten-free", etc.],
  "healthRating": number (1-10 overall health score)
}

CRITICAL HEALTH WARNINGS - Include these warnings when applicable:
- If sugar > 10g/100g: "High sugar content - may increase diabetes risk"
- If salt/sodium > 1.5g/100g: "High sodium - may increase blood pressure and heart disease risk"
- If saturatedFat > 5g/100g: "High saturated fat - may increase cholesterol levels"
- If transFat > 0g: "Contains trans fats - associated with heart disease and cancer risk"
- If the food is highly processed (fast food, chips, candy, sugary drinks): "Ultra-processed food - linked to obesity, diabetes, and cancer"
- If contains artificial colors/preservatives: "Contains artificial additives - may have adverse health effects"
- If high calorie but low nutrition: "High calorie, low nutrient density"
- If contains hydrogenated oils: "Contains hydrogenated oils - linked to cardiovascular disease"
- If contains high fructose corn syrup: "Contains high fructose corn syrup - linked to metabolic disorders"

Be accurate with nutritional values. If you detect a barcode, set isBarcode to true and include the barcode number.
Return ONLY the JSON object, no markdown formatting or explanations.`;

export async function analyzeFood(imageBase64: string, language: string = 'en'): Promise<FoodAnalysisResult> {
  try {
    const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: SYSTEM_PROMPT + (language !== 'en' ? `\n\nProvide the name in ${language === 'ar' ? 'Arabic' : language === 'es' ? 'Spanish' : language === 'de' ? 'German' : 'French'} as well.` : ''),
              },
              {
                inline_data: {
                  mime_type: 'image/jpeg',
                  data: imageBase64.replace(/^data:image\/[a-z]+;base64,/, ''),
                },
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.1,
          topK: 32,
          topP: 1,
          maxOutputTokens: 1024,
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    const textContent = data.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!textContent) {
      throw new Error('No response from API');
    }

    // Clean up the response - remove markdown code blocks if present
    let cleanedText = textContent.trim();
    if (cleanedText.startsWith('```json')) {
      cleanedText = cleanedText.slice(7);
    }
    if (cleanedText.startsWith('```')) {
      cleanedText = cleanedText.slice(3);
    }
    if (cleanedText.endsWith('```')) {
      cleanedText = cleanedText.slice(0, -3);
    }
    cleanedText = cleanedText.trim();

    const result: FoodAnalysisResult = JSON.parse(cleanedText);
    return result;
  } catch (error) {
    console.error('Gemini API error:', error);
    // Return a fallback result
    return {
      name: 'Unknown Food',
      nameAr: 'طعام غير معروف',
      calories: 150,
      protein: 5,
      carbs: 20,
      fat: 5,
      fiber: 2,
      sugar: 5,
      salt: 0.5,
      vitamins: { A: 10, C: 15, D: 5, B12: 10 },
      minerals: { calcium: 8, iron: 10, magnesium: 12 },
      acids: { omega3: 50 },
      confidence: 50,
      warnings: [],
    };
  }
}

export async function analyzeBarcodeImage(imageBase64: string): Promise<string | null> {
  try {
    const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: 'Extract the barcode number from this image. Return ONLY the barcode number as plain text, nothing else. If no barcode is found, return "NONE".',
              },
              {
                inline_data: {
                  mime_type: 'image/jpeg',
                  data: imageBase64.replace(/^data:image\/[a-z]+;base64,/, ''),
                },
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0,
          maxOutputTokens: 50,
        },
      }),
    });

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    const textContent = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

    if (!textContent || textContent === 'NONE') {
      return null;
    }

    return textContent;
  } catch (error) {
    console.error('Barcode detection error:', error);
    return null;
  }
}
